=== PoliMorf ===
Contributors: PoliMorfic
Requires at least: WordPress 4.7
Tested up to: WordPress 4.9
Version: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: widgets, custom-functions, cloud compatibility, simple design

== Description ==

PoliMorf allows you to create individual page and post templates by employing a schematic language rather than using custom fields in the WordPress admin section. You can also store these schematics remotely on Amazon Web Services and access them through simple commands.
The theme allows you to leverage the Cloud within your hosting platform and ease design and maintenance of your site.

For more information about PoliMorf please go to https://polimorfic.com/polimorf-theme.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Click the 'Upload New' button.
3. Upload the zip file for PoliMorf that you downloaded from the vendor site.
4. Click on the 'Activate' button to use your new theme right away.
5. Refer to the PoliMorf_User_Guide.pdf link on https://polimorfic.com/polimorf-theme for how to customize this theme.
6. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Copyright ==

PoliMorf WordPress Theme, Copyright 2018 PoliMorfic.com
PoliMorf is distributed under the terms of the GNU GPL as it is a
WordPress theme.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

See the GNU General Public License for more details.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

PoliMorf bundles the following third-party resources:

normalize.css, Copyright 2012-2016 Nicolas Gallagher and Jonathan Neal
License: MIT
Source: https://necolas.github.io/normalize.css/

Font Awesome icons, Copyright Dave Gandy
License: SIL Open Font License, version 4.7.
Source: http://fontawesome.io/

Faustina Font
Copyright 2016 The Faustina Project Authors (omnibus.type@gmail.com)
Source: https://github.com/Omnibus-Type/Faustina


== Changelog ==

Initial release
