<?php
//
// ----
// post meta functions used for inserting meta by schematic
// as well as post listing
//
//
function polimorf_header_and_title() {
//
// process schematics
polimorf_determine_schematic_reference();
// process effects and font insertions
polimorf_process_wp_head_additions();
//
?>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php // wp_title(); ?>
<link rel="shortcut icon" type"image/x-icon" href="<?php echo $GLOBALS['$blog_template']; ?>/images/favicon.ico" />
<link rel="stylesheet" href="<?php echo $GLOBALS['$theme_url']; ?>/extras/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- meta -->
<meta id="viewport-tag" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.5">
<meta name="pm_blog_url" id="pm-blog-url" content="<?php echo $GLOBALS['$blog_url'] ; ?>">
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<!-- wp generated header -->
<?php wp_head(); ?>
<!-- end wp generated header -->
<!-- -->
</head>
<?php
//
}
//
function polimorf_open_main_wrap(){
	echo constant('pmschematics::PM_MAIN_WRAP_OPEN');
}
function polimorf_open_main_inner_outer(){
  pcom_open_placement_class(null,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
}
//
function polimorf_close_main_wrap(){
	echo constant('pmschematics::PM_MAIN_WRAP_CLOSE');
}
function polimorf_close_main_inner_outer() {
  pcom_close_placement_class(constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
}
//
function polimorf_add_class_for_page_type($type){
// returns a value for page type post lists
// i.e. archive = pm-archive
$page_class = '';
if ( is_author() ) $page_class = constant('pmschematics::PM_AUTHOR_POST_LIST_CLASS');
if ( is_archive() ) $page_class = constant('pmschematics::PM_ARCHIVE_POST_LIST_CLASS');
if ( is_category() ) $page_class = constant('pmschematics::PM_CATEGORY_POST_LIST_CLASS');
if ( is_tag() ) $page_class = constant('pmschematics::PM_TAG_POST_LIST_CLASS');
//
return $page_class;
}
//
function polimorf_open_close_main_classes($type){
// adds opening schematics for post lists depending on type
// source sidebar global
$sidebar_found = $GLOBALS['$sidebar_found'];
$custom_class = polimorf_add_class_for_page_type($type);
//
	switch ($type) {
//
  case constant('pmschematics::PM_MAIN_POST_LIST_INDEX_OPEN') :
  //
  	if ($sidebar_found == true) {
  		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
  	}
  	echo constant('pmschematics::PM_POST_LIST_OPEN');
  //
  break;
//
	case constant('pmschematics::PM_MAIN_POST_LIST_OPEN') :
//
		if ($sidebar_found == true) {
			echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
		}
		pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_POST_LIST_CUSTOM_OPEN'));
//
	break;
//
	case constant('pmschematics::PM_MAIN_POST_LIST_CLOSE') :
//
		echo constant('pmschematics::PM_POST_LIST_CLOSE');
		if ($sidebar_found == true) {
			echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE');
		}
//
	break;
//
	default:
	// add nothing
	break;
//
	}
}
//
//
//
function polimorf_post_author_date_insert($show_author,$show_date) {
//
global $post;
$id = $post->ID;
$type = $post->post_type;
$date_insert = get_the_date(get_option('date_format'),$post);
$archive_year  = get_the_time('Y');
$archive_month = get_the_time('m');
$month_archive_date = get_month_link( $archive_year, $archive_month );
//
  if ( ( $show_author == true ) || ( $show_date == true ) ) {
    echo constant('pmschematics::PM_POST_AUTHOR_DATE_META_OPEN');
    // only add links if post
    if ( $type == 'post' ) {
      if ($show_author == true) {
        ?>
        <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a>
      <?php
      }
      //
      if ($show_date == true) {
        if ($show_author == true) echo ' - ';
        echo '<a href="' . $month_archive_date . '">' . $date_insert . '</a>';
      }
    //
    } else {
    //
      if ($show_author == true) {
        echo get_the_author_meta( 'user_nicename' );
      }
      if ($show_date == true) {
        if ($show_author == true) echo ' - ';
        echo $date_insert;
      }
    }
    echo constant('pmschematics::PM_POST_AUTHOR_DATE_META_CLOSE');
  } // end if
//
}
//
function polimorf_insert_author_archive_meta(){
	// called within the loop
	global $authordata;
	echo '<h1>' . esc_attr($GLOBALS['PM_AUTHOR_ARCHIVES']) . ': ';
	echo '<a href="' . esc_attr($authordata->user_url) . '" title="' . esc_attr($authordata->display_name) . '" rel="me">' . esc_attr($authordata->display_name) . '</a></h1>';
	//
	$authordesc = esc_attr($authordata->user_description);
	if ( !empty($authordesc) ) echo apply_filters( 'archive_meta', '<div class="pm-category-meta">' . $authordesc . '</div>' );
	//
}
//
function polimorf_post_title_insert($post,$show_title) {
// insets the title
  if ($show_title == true) {
    echo constant('pmschematics::PM_POST_TITLE_OPEN');
    echo '<h1>' . esc_attr($post->post_title) . '</h1>';
    echo constant('pmschematics::PM_POST_TITLE_CLOSE');
  }
//
}
//
function polimorf_post_category_insert($show_cat) {
// inserts category based on $post
global $post;
  if ($show_cat == true ) {
    $post_detail = get_post($post);
    	if ($post_detail->post_type == 'post'){
    		echo constant('pmschematics::PM_POST_CATEGORY_META_OPEN');
        echo constant('pmschematics::PM_CATEGORY_ICON');
    		?>&nbsp;&nbsp;<?php the_category(', ','multiple',$post->ID);
    		echo constant('pmschematics::PM_POST_CATEGORY_META_CLOSE');
    	}
  }
//
}
//
function polimorf_post_comments_insert($post) {
// insert link to comments
$post_detail = get_post($post);
?>
<div id="pm-post-comment-link">
<a href="<?php echo get_permalink($post->ID); ?>#comments">
<?php echo esc_attr($GLOBALS['PM_COMMENTS']);?>:&nbsp;
<?php echo esc_attr($post_detail->comment_count) ; ?></a>
</div>
<?php
}
//
//
function polimorf_insert_tag_title() {
// called in the locale_accept_from_http
echo '<h1 class="page-title">';
echo esc_attr($GLOBALS['PM_TAG_ARCHIVES']); ?>&nbsp;:&nbsp;<span>
<?php single_tag_title(); ?></span></h1>
<?php
}
//
function polimorf_post_tag_insert($post,$show_tag) {
// called in the Loop
$post_tags = get_the_tags();
//
  if ( ( $post_tags ) && ( $show_tag == true ) ) {
    $tag_list = constant('pmschematics::PM_TAG_ICON') . '&nbsp;&nbsp;';
    //
    echo constant('pmschematics::PM_POST_TAG_META_OPEN');
      foreach( $post_tags as $tag ) {
        $tag_link = '<a href="' . $GLOBALS['$blog_url'] . '/tag/' . $tag->slug . '">' .
            esc_attr($tag->name) . '</a>';
        $tag_list = $tag_list . $tag_link . ', ';
      }
    // trim end
    $tag_list = substr($tag_list,0,-2);
    echo $tag_list;
    echo constant('pmschematics::PM_POST_TAG_META_CLOSE');
  }
//
}
//
function polimorf_insert_archive_title(){
// called in the loop
	$h1_start = '<h1>';
	$space_span_start = ':&nbsp;<span>';
	$end_h1_span = '</span></h1>';
	$h1_end = '</h1>';
	//
	if ( is_day() ) :
					echo $h1_start . esc_attr($GLOBALS['PM_DAILY_ARCHIVES']) .
					$space_span_start; ?><?php echo the_time(get_option('date_format')) . $end_h1_span;
	elseif ( is_month() ) :
					echo $h1_start . esc_attr($GLOBALS['PM_MONTHLY_ARCHIVES']) .
					$space_span_start; ?><?php echo the_time('F Y') . $end_h1_span;
	elseif ( is_year() ) :
					echo $h1_start . esc_attr($GLOBALS['PM_YEARLY_ARCHIVES']) .
					$space_span_start; ?><?php echo the_time('Y') . $end_h1_span;
	elseif ( isset($_GET['paged']) && !empty($_GET['paged']) ) :
			 		echo $h1_start . esc_attr($GLOBALS['PM_BLOG_ARCHIVES']) . $h1_end;
	endif;
//
}
//
function polimorf_insert_category_title(){
?>
<h1 class="page-title"><?php echo esc_attr($GLOBALS['PM_POSTS_FOR']); ?>:  <span><?php single_cat_title() ?></span></h1>
<?php
}
//
// post pagination - called in the loop
function polimorf_insert_post_pagination(){
	//
	echo constant('pmschematics::PM_POST_NAV_OPEN');
	if ( !empty(get_next_post_link()) ) {
		if ( empty(get_previous_post_link()) ) {
			$format = '<div id="single-post-link">' . constant('pmschematics::PM_PAGINATION_FORMAT_NEXT_LINK');
		} else {
			$format = '<div id="next-post-link">' . constant('pmschematics::PM_PAGINATION_FORMAT_NEXT_LINK');
		}
    next_post_link($format);
//
	}
	//
	if ( !empty(get_previous_post_link()) ) {
		if ( empty(get_next_post_link()) ) {
			$format = '<div id="single-post-link">' . constant('pmschematics::PM_PAGINATION_FORMAT_PREV_LINK');
		} else {
			$format = '<div id="prev-post-link">' . constant('pmschematics::PM_PAGINATION_FORMAT_PREV_LINK');
		}
    previous_post_link($format);
//
	}
	echo constant('pmschematics::PM_POST_NAV_CLOSE');
}
//
// -- create post entry using default image and post
// --
function polimorf_post_list_entry($post,$default_image) {
//
	$id = $post->ID;
	$post_detail = get_post($post);
	$main_image = trim(esc_url($post_detail->_pm_main_img_meta));
  $main_image = pcom_site_constants_replacement($main_image);
  $processed_main_image = pcom_process_custom_meta_for_commands($main_image,constant('pcom_commands::PCOM_CUSTOM_META_IMAGE'));
	$post_title = esc_attr($post_detail->post_title);
  $excerpt = get_the_excerpt($post);
	$thumbnail_array = wp_get_attachment_image_src( get_post_thumbnail_id($id),'large');
	$thumbnail = $thumbnail_array[0];
  $processed_excerpt = pcom_process_custom_meta_for_commands($excerpt,constant('pcom_commands::PCOM_CUSTOM_META_EXCERPT'));
  //
  // process execert for text or schematic commands
  //
	echo '<div class="pm-post-content clearfix-small">' . "\r\n";
	echo '<div class="pm-post-image">' . "\r\n";
	//
	// set image out
  if (!empty($main_image)) {
		$image_out = $main_image;
	} else {
		$image_out = esc_url($default_image);
	}
  // check for processed - overrides other settings
  if ($processed_main_image['data_valid'] == true) {
    $image_out = $processed_main_image['data'];
  }
	// use the post thumbnail if WordPress featured image present
	// for post use get_the_post_thumbnail
	// otherwise get the src and echo
	echo '<a href="' . get_permalink($id) .'" rel="bookmark">';
	if (!empty($thumbnail)) {
		if ( $post_detail->post_type != 'post' ) {
			echo get_the_post_thumbnail($id);
		} else {
			the_post_thumbnail();
		}
	} else {
		echo '<img src="' . $image_out . '" alt="' . $post_title . '"  />';
	}
	echo '</a></div><!-- end of .pm-post-image -->' . "\r\n";
	//
	if (is_sticky( $id )) {
		echo '<div class="pm-blog-entry sticky">' . "\r\n";
	} else {
		echo '<div class="pm-blog-entry">' . "\r\n";
	}
	echo '<h2><a href="' . get_permalink($id) . '">' . $post_title . '</a></h2>' . "\r\n";
	//
  if ($post_detail->post_type != 'page') {
	   polimorf_post_author_date_insert(true, true);
	   polimorf_post_category_insert(true);
  }
	// echo the excerpt
  if ( $excerpt ) {
    if ( $processed_excerpt['data_valid'] == true ) {
      echo $processed_excerpt['data'];
    } else {
      echo '<p>' . $excerpt . '</p>' . "\r\n";
    }
  } else {
    // default function
    the_excerpt();
  }
	//
	echo '</div><!-- end of .pm-blog_entry -->' . "\r\n";
	echo '</div><!-- end of .pm-post-content -->' . "\r\n";
//
}
//
/**
 * Adds links for pagination on all archive pages
 * and index. Called in the Loop.
 *
 * @param global $wp_query
 *
 * @return none
 *
 * @since 1.0.0
 */
function polimorf_add_pagination_links(){
//
global $wp_query;
$total_pages =$wp_query->max_num_pages;
//
// default format for pagination url is /../
// except if plain permalinks are selected
// then it is ?paged=number
$format = '/page/%#%';
if ( get_option('permalink_structure') == '' )  {
	if ( is_archive() ) {
		// for plain permalinks add the paged onto the base
		$format = '&paged=%#%';
	} else {
		$format = '?paged=%#%';
	}
}
//
	if ($total_pages > 1){
	 $current_page = max(1, get_query_var('paged'));
	 echo constant('pmschematics::PM_PAGE_NAV_OPEN');
	 echo paginate_links(array(
				 'base' => get_pagenum_link(1) . '%_%',
				 'format' => $format,
				 'current' => $current_page,
				 'total' => $total_pages,
				 'prev_text' => constant('pmschematics::PM_PAGINATION_PREV_ICON'),
				 'next_text' => constant('pmschematics::PM_PAGINATION_NEXT_ICON')
			));
	 echo constant('pmschematics::PM_PAGE_NAV_CLOSE');
	}
}
// called in the loop
function polimorf_present_posts($page_type){
	// condition input
	if ($page_type == null) $page_type = 'other';
	//
	if ($page_type == 'index'){
		echo constant('pmschematics::PM_20PX_SPACER');
	} else {
		echo constant('pmschematics::PM_10PX_SPACER');
	}
	//
	rewind_posts();
	//
	// get default image url
	$def_img_1 = polimorf_get_default_post_thumb();
	//
	if (have_posts()) {
		while (have_posts()) : the_post();
			polimorf_post_list_entry($post, $def_img_1);
		endwhile;
	// add in pagination links
		polimorf_add_pagination_links();
	// close loop condition
	}
	// reset post query
	wp_reset_query();
}
//
function polimorf_insert_responsive_icon(){
// inserts responsive menu icon
echo constant('pmschematics::PM_NAV_RESP_ICON_OPEN');
?>
	<i class="fa fa-bars fa-x" aria-hidden="true"></i>
<?php
echo '</div></div>';
//
}
//
// -----
//
function polimorf_add_footer_attribution_strip(){
// adds attribution
pcom_open_placement_class(null,constant('pcom_commands::PCOM_FOOTER_PLACEMENT'));
?>
<div id="footer-bottom-strip">
	<div id="footer-attrib">
		<span>
			<?php echo esc_attr($GLOBALS['PM_THEME']);?>:&nbsp;<a href="http://polimorfic.com/polimorf-theme" target="_new"><?php echo esc_attr($GLOBALS['PM_THEME_NAME']);?></a>&nbsp;-&nbsp;
			<?php echo esc_attr($GLOBALS['PM_POWERED_BY']);?>&nbsp;<a href="http://wordpress.org">
			<?php echo esc_attr($GLOBALS['PM_WORDPRESS']);?></a>.
		</span>
	</div>
</div><!-- end of bottom strip --><?php
pcom_close_placement_class(constant('pcom_commands::PCOM_FOOTER_PLACEMENT'));
//
}
//
// NOTHING FOUND HERE - generic text
function polimorf_nothing_found_here() {
// adds generic text at bottom of page/post using constant strings:
	echo constant('pmschematics::PM_MAIN_WRAP_OPEN');
	echo constant('pmschematics::PM_POST_OPEN_ONLY');
	//
  echo '<h2>' . esc_attr($GLOBALS['PM_NOTHING_HERE']) .'!</h2>' . "\r\n";
	echo '<p>' . esc_attr($GLOBALS['PM_SORRY_LOOKING_FOR']) . '.</p>' . "\r\n";
	echo '<p><a href="' . home_url() . '">' . esc_attr($GLOBALS['PM_BACK_TO_HOME']) . '</a></p>' . "\r\n";
	//
	echo constant('pmschematics::PM_POST_CLOSE');
	echo constant('pmschematics::PM_MAIN_WRAP_CLOSE');
}
//
//
function polimorf_display_attachment(){
	global $post;
	$excerpt = $post->post_excerpt;
// displays attachment if in post or page and is linked
	echo '<h1 class="page-title">' . "\r\n";
	echo '<a href="' . get_permalink($post->post_parent) . '" rev="attachment">';
	echo '<span class="meta-nav">&laquo; </span>' . get_the_title($post->post_parent) . '</a></h1>' . "\r\n";
	echo '<h2 class="entry-title">' . get_the_title($post->id)  . '</h2>' . "\r\n";
	echo constant('pmschematics::PM_20PX_SPACER');
	//
	echo '<div class="entry-attachment">' . "\r\n";
	//
	if ( wp_attachment_is_image( $post->id ) ) {
		$att_image = wp_get_attachment_image_src( $post->id, "full");
		echo '<p class="attachment"><a href="' .
		wp_get_attachment_url($post->id) . '" title="' . get_the_title($post->id) . '" rel="attachment">' . "\r\n";
		//
		echo '<img src="' . $att_image[0] . '" width="' . $att_image[1] . '" height="' . $att_image[2] .
		'" class="attachment-medium" alt="' . esc_html( get_the_title($post->ID), 1 ) . '" />' . "\r\n";
		echo '</a></p>' . "\r\n";
		//
	} else {
		echo '<a href="' . wp_get_attachment_url($post->ID)  . '" title="' .
		esc_html( get_the_title($post->ID), 1 ) . '" rel="attachment">' . "\r\n";
		//
		echo basename($post->guid) . '</a>' . "\r\n";
	}
	echo '</div><!-- end entry-attachment -->' . "\r\n";
}
// ==============
// SEARCH QUERY
// ==============
function polimorf_search_query(){
// character representations of open and close html
// or script tags - prevents producing error page for server
// get default image url
$def_img_1 = polimorf_get_default_post_thumb();
	// copy wp query to temp and create a new one for search using s from form
$page_list_count = get_option('posts_per_page'); //  posts per page
//
global $search_term;
$s = $search_term; // get_search_query();
//
$allowed_tags = array();
$s = wp_kses($s,$allowed_tags);
//
$s = esc_attr($s);
//
$temp = $wp_query;
//
$search_query_args = array(
	'post_type' => array( 'post', 'page'),
	's' => $s,
	'posts_per_page' => $page_list_count,
	'paged' => ''
);
// get paged and check for home
if (is_home()) {
	$search_query_args['paged'] = get_query_var( 'page' ) ? get_query_var( 'page' ) : 1;
} else {
	$search_query_args['paged'] = get_query_var( 'paged' ) ? get_query_var('paged') : 1;
}
//
$wp_query = null;
$wp_query = new WP_Query( $search_query_args );
//
	if ( $wp_query->have_posts() ) {
		//
	  echo '<h1>' . esc_attr($GLOBALS['PM_SEARCH_RESULTS']) .
		'&nbsp;:&nbsp;<span>' . get_search_query() . '</span></h1>' . "\r\n";
		//
		while ( $wp_query->have_posts() ) {
			$searched_post = $wp_query->the_post();
			polimorf_post_list_entry($searched_post, $def_img_1);
		}
		// default format for pagination url is /../
		// except if plain permalinks are selected
		// then it is ?paged=number
		//
		$format = '/page/%#%';
		if ( get_option('permalink_structure') == '' )  $format = '?paged=%#%';
		//
		// add in pagination links
		$total_pages =  $wp_query->found_posts / $page_list_count;
		// echo $total_pages;
		if ($total_pages > 1){
 			 $current_page = max(1, get_query_var('paged'));
 			 echo '<div class="page_nav">';
 			 echo paginate_links(array(
     				 'base' => get_pagenum_link(1) . '%_%',
     				 'format' => $format,
     				 'current' => $current_page,
     				 'total' => $total_pages,
						 'prev_text' => constant('pmschematics::PM_PAGINATION_PREV_ICON'),
						 'next_text' => constant('pmschematics::PM_PAGINATION_NEXT_ICON')
    			));
 			 echo '</div>';
		}

	}	else {
			echo '<h1>' . esc_attr($GLOBALS['PM_SEARCH_RESULTS']) .
			'&nbsp;:&nbsp;<span>' . get_search_query() . '</span></h1>' . "\r\n";
			//
			echo '<h2>' . esc_attr($GLOBALS['PM_NOTHING_FOUND']) . '</h2>' . "\r\n";
			echo '<div>';
			echo '<p>' . esc_attr($GLOBALS['PM_SORRY_SEARCH']) . '</p>' . "\r\n";
			echo '</div><!-- .entry-content -->' . "\r\n";
			$html_out = polimorf_insert_searchbar();
			echo $html_out;
	//
	}
	// Reset Post Data
	// close loop condition
	// restore original query
	$wp_query = null;
	$wp_query = $temp;
	wp_reset_postdata();
	//
}
//
function polimorf_404_message(){
	echo '<h1>' . esc_attr($GLOBALS['PM_404_NOT_FOUND'])  .'</h1>' . "\r\n";
	echo '<p>' . esc_attr($GLOBALS['PM_404_APOLOGIES']) . '</p>' . "\r\n";
}
//
function polimorf_get_calendar_for_archive() {
//
echo constant('pmschematics::PM_CALENDAR_WRAP_FOR_ARCHIVE_OPEN');
get_calendar();
echo constant('pmschematics::PM_CALENDAR_WRAP_FOR_ARCHIVE_CLOSE');
//
}
//
//
function polimorf_add_copyright($syntax,$custom_class,$placement){
//adds copyright statement
pcom_open_placement_class($custom_class,$placement);
pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_GENERAL_CONTENT_WRAP_OPEN'));
?>
<p>&copy; <?php echo date('Y') ; ?>&nbsp;<?php echo esc_attr($GLOBALS['PM_ALL_RIGHTS_RESERVED']); ?>.</p><?php
echo constant('pmschematics::PM_GENERAL_CONTENT_WRAP_CLOSE');
pcom_close_placement_class($placement);
}
//
