<?php
// schematic_reader function
// ---
/**
 * This function determines page setup
 * Is called on each page or post
 * index i.e. blog, uses a different function
 * Sets format globals
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_determine_schematic_reference()
 {
  //
  global $post;
  //
  // DEFAULT COMMAND - use theme settings for header main and footer
  $default = $GLOBALS['PM_DEFAULT_COMMAND'];
  $sidebar_found = false;
  //
  $styling_options = get_option('polimorf_styling_options');
  //
  $header_schematic = $styling_options['header_format'];
  $footer_schematic = $styling_options['footer_format'];
  $main_schematic = is_page() ? $styling_options['page_format'] : $styling_options['post_format'];
  $sidebar_schematic = $styling_options['sidebar_format'];
  $before_schematic = $styling_options['before_main_format'];
  $after_schematic = $styling_options['after_main_format'];
  //
  if (!empty($sidebar_schematic)) $sidebar_found = true;
  if (!empty($before_schematic)) $before_found = true;
  if (!empty($after_schematic)) $after_found = true;
  //
  // check for in page formats
  $inpage_format = "";
  if ( $GLOBALS['query_active'] != 1 ) {
    $inpage_format = get_post_meta($post->ID,'_pm_inpage_format', TRUE);
  }
  //
    if ( (!empty($inpage_format)) ) {
  // check for remote schematic command
  // output of successful remote call will replace $inpage_format
    $inpage_format = pcom_process_remote_schematic_tag($inpage_format);
  //
      $inpage_schematics = pcom_get_schematic_tags($inpage_format);
      $sidebar_found = $inpage_schematics['sidebar_found'];
      $before_found = $inpage_schematics['before_found'];
      $after_found = $inpage_schematics['after_found'];
      // check for default command
      //HEADER
      $first_command = pcom_get_first_command($inpage_schematics['header'],$args);
      if ($first_command['command'] != $default ) {
        $header_schematic = $inpage_schematics['header'];
      }
      //MAIN
      $first_command = pcom_get_first_command($inpage_schematics['main'],$args);
      if ($first_command['command'] != $default ) {
        $main_schematic = $inpage_schematics['main'];
      }
      //SIDEBAR
      $first_command = pcom_get_first_command($inpage_schematics['sidebar'],$args);
      if ($first_command['command'] != $default ) {
        $sidebar_schematic = $inpage_schematics['sidebar'];
      }
      //FOOTER
      $first_command = pcom_get_first_command($inpage_schematics['footer'],$args);
      if ($first_command['command'] != $default ) {
        $footer_schematic = $inpage_schematics['footer'];
      }
      //BEFORE
      $first_command = pcom_get_first_command($inpage_schematics['before'],$args);
      if ($first_command['command'] != $default ) {
        $before_schematic = $inpage_schematics['before'];
      }
      //AFTER
      $first_command = pcom_get_first_command($inpage_schematics['after'],$args);
      if ($first_command['command'] != $default ) {
        $after_schematic = $inpage_schematics['after'];
      }
    //
    }
    // check if empty - use schematic defaults - do not include sidebar or before and after
    if (empty(trim($header_schematic))) $header_schematic = constant('pmschematics::PM_HEADER_SCHEMATIC');
    if (empty(trim($main_schematic))) {
      $main_schematic = is_page() ? constant('pmschematics::PM_PAGE_SCHEMATIC') : constant('pmschematics::PM_POST_SCHEMATIC');
    }
    if (empty(trim($footer_schematic))) $footer_schematic = constant('pmschematics::PM_FOOTER_SCHEMATIC');
    //
    // set globals
    $GLOBALS['header_schematic'] = $header_schematic;
    $GLOBALS['main_schematic'] = $main_schematic;
    $GLOBALS['footer_schematic'] = $footer_schematic;
    $GLOBALS['sidebar_schematic'] = $sidebar_schematic;
    $GLOBALS['before_schematic'] = $before_schematic;
    $GLOBALS['after_schematic'] = $after_schematic;
    $GLOBALS['sidebar_found'] = $sidebar_found;
    $GLOBALS['before_found'] = $before_found;
    $GLOBALS['after_found'] = $after_found;
  //
 }
// ----------------
// ----------------
//
// -----------------
// HEADER ADDITIONS - to be added to wp_head
// ------------------
/**
 * Process additions list in header
 * Calls format global
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_process_wp_head_additions()
 {
  //
  $header_schematic = $GLOBALS['header_schematic'];
  //
  polimorf_process_addition($header_schematic,constant('pcom_commands::PCOM_HEADER_PLACEMENT'));
 }
// ----------------
// HEADER SCHEMATIC
// ----------------
/**
 * Process command list for header section
 * Calls format global
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_header_schematic_parser()
 {
  // call header schematic
  $header_schematic = $GLOBALS['header_schematic'];
  // output header schematic text
  polimorf_process_schematic($header_schematic,constant('pcom_commands::PCOM_HEADER_PLACEMENT'));
  //
 }
//
// --------------
// MAIN SCHEMATIC
// --------------
/**
 * Process command list for main section
 * Includes sidebar data if found
 * Calls format global
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_main_schematic_parser()
 {
  // process before, main, sidebar and after
  $main_schematic = $GLOBALS['main_schematic'];
  $sidebar_found = $GLOBALS['sidebar_found'];
  //
    if ($sidebar_found != true) {
      // output before main, after main, and main schematic text
      polimorf_process_schematic($main_schematic, constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
    } else {
      // open the main outer and inner classes
      pcom_open_placement_class(null,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
      // open main div
      echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
      polimorf_process_schematic($main_schematic,constant('pcom_commands::PCOM_MAIN_WITH_SIDEBAR_PLACEMENT'));
      echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE');
      // open sidebar
      polimorf_sidebar_schematic_parser();
      //
      pcom_close_placement_class(constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
      // after
    }
  //
 }
// ------------------
// SIDEBAR SCHEMATIC
// -----------------
//
/**
 * Sidebar schematic processor for elements that do not use main_schematic_parser
 * Calls format global
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_sidebar_schematic_parser()
 {
  // get sidebar globals
  $sidebar_schematic = $GLOBALS['sidebar_schematic'];
  //
  echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_OPEN');
  polimorf_process_schematic($sidebar_schematic,constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT'));
  echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_CLOSE');
  //
 }
// ----------------
// BEFORE SCHEMATIC
// ----------------
/**
 * Before main format schematic parser
 * Calls format global
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_before_main_schematic_parser()
 {
  // get sidebar globals
  $before_schematic = $GLOBALS['before_schematic'];
  $before_found = $GLOBALS['before_found'];
  //
    if ($before_found == true) {
      polimorf_process_schematic($before_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
    }
  //
 }
// ---------------
// AFTER SCHEMATIC
// ---------------
/**
 * After main format schematic parser
 * Calls format global
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_after_main_schematic_parser()
 {
  // get sidebar globals
  $after_schematic = $GLOBALS['after_schematic'];
  $after_found = $GLOBALS['after_found'];
  //
    if ($after_found == true) {
      polimorf_process_schematic($after_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
    }
  //
 }
// ----------------
// FOOTER SCHEMATIC
// ----------------
//
/**
 * Footer format schematic parser
 * Calls format global
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_footer_schematic_parser() {
  // call footer schematic
  $footer_schematic = $GLOBALS['footer_schematic'];
  // output footer schematic text
  polimorf_process_schematic($footer_schematic, constant('pcom_commands::PCOM_FOOTER_PLACEMENT'));
  //
 }
// ---
//
//
//
/**
 * General schematic command loop
 * Uses global list of commands for reference
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_process_schematic($schematic,$placement)
 {
  //
    while ( $schematic_commands['command'] != constant('pcom_commands::PCOM_NO_ENTRY') ) {
      $schematic_commands = pcom_get_first_command($schematic,$args); // $args is null here
      pcom_command_selection($schematic_commands['command'],$schematic_commands['command_syntax'],$placement);
      $schematic = $schematic_commands['next_command'];
    }
 }
//
//
//
/**
 * General schematic additions loop
 * Uses global list of additions for reference
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_process_addition($schematic,$placement)
 {
  //
    while ( $schematic_commands['command'] != constant('pcom_commands::PCOM_NO_ENTRY') ) {
      $schematic_commands = pcom_get_first_command($schematic,$args); // $args is null here
      pcom_addition_selection($schematic_commands['command'],$schematic_commands['command_syntax'],$placement);
      $schematic = $schematic_commands['next_command'];
    }
 }
//
//
