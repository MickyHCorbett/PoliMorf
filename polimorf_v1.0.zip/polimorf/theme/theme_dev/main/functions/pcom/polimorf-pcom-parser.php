<?php
//
// parser for polimorf local shorthand - polimorf commands (pcom)
// ==============
//
// PCOM commands
// ----- -----
//
// ======================================
//
$GLOBALS['content_insert'] = false; // default for content insert filter i.e. do nothing
$GLOBALS['content_with_inserts'] = array(); // actual content to be inserted
//
//
function pcom_command_selection($schematic_command,$command_syntax,$placement){
// command selector - chooses appropriate command parser from standard commands
  $main_pcom_commands = $GLOBALS['command_functions_list'];
  $n_box_root = $GLOBALS['PM_BOX_COMMAND_ROOT'];
  //
  $command_custom = pcom_process_custom_command($schematic_command);
  //process basic commands
  //
  if ( array_key_exists($command_custom['command'],$main_pcom_commands)) {
    //set function call
    $func = $main_pcom_commands[$command_custom['command']];
    call_user_func_array($func, array($command_syntax,$command_custom['custom_class'],$placement));
  }
  //
  // process for n_box
  $n_box_test = pcom_get_strings_syntax_separator($command_custom['command'],$n_box_root,true);
  if ($n_box_test['command_found'] == true) {
    $no_boxes = (int) $n_box_test['syntax_before'];
    pcom_process_n_box_command($command_syntax,$command_custom['custom_class'],$placement,$no_boxes);
  }
//
//
//
}
//
//=========
//
function pcom_addition_selection($schematic_command,$command_syntax,$placement){
// addition selector - chooses appropriate command parser from standard commands
  $main_pcom_commands = $GLOBALS['addition_functions_list'];
  //
  $command_custom = pcom_process_custom_command($schematic_command);
  //process basic commands
  //
  if ( array_key_exists($command_custom['command'],$main_pcom_commands)) {
    //set function call
    $func = $main_pcom_commands[$command_custom['command']];
    call_user_func_array($func, array($command_syntax,$command_custom['custom_class'],$placement));
  }
}
//
//=========
//
//
// ----- -----
// Separate header, main and footer schematics
function pcom_get_schematic_tags($format){
// function returns header, main and schematic as an array of strings
$header_tag = $GLOBALS['PM_HEADER_SCHEMATIC_TAG'];
$main_tag = $GLOBALS['PM_MAIN_SCHEMATIC_TAG'];
$footer_tag = $GLOBALS['PM_FOOTER_SCHEMATIC_TAG'];
$sidebar_tag = $GLOBALS['PM_SIDEBAR_SCHEMATIC_TAG'];
$before_tag = $GLOBALS['PM_BEFORE_MAIN_SCHEMATIC_TAG'];
$after_tag = $GLOBALS['PM_AFTER_MAIN_SCHEMATIC_TAG'];
//
$header_tag_offset = strlen($header_tag);
$main_tag_offset = strlen($main_tag);
$footer_tag_offset = strlen($footer_tag);
// set up array for output - defaults are empty
$out_formats = array(
  'header'=> "",
  'main' => "",
  'sidebar' => "",
  'footer' => "",
  'before' => "",
  'after' => "",
  'sidebar_found' => false,
  'before_found' => false,
  'after_found' => false
);
//
// search for first ///
$header_tag_pos = strpos($format,$header_tag);
$main_tag_pos = strpos($format,$main_tag);
$footer_tag_pos = strpos($format,$footer_tag);
//
// all main tags must be in order otherwise nothing is returned
if ( ( $footer_tag_pos > $main_tag_pos) && ( $main_tag_pos > $header_tag_pos) ) {
  $out_formats['header'] = substr($format,$header_tag_pos+$header_tag_offset,$main_tag_pos - $header_tag_pos-$header_tag_offset);
  $out_formats['main'] = substr($format,$main_tag_pos+$main_tag_offset,$footer_tag_pos - $main_tag_pos-$main_tag_offset);
  $out_formats['footer'] = substr($format,$footer_tag_pos+$footer_tag_offset);
}
// ================
// CONDITIONAL tags
// ================
// process header to see if there is a BEFORE tag
$before_search = pcom_get_strings_syntax_separator($out_formats['header'],$before_tag,true);
if ( $before_search['command_found'] == true ) {
  $out_formats['before_found'] = true;
  $out_formats['header'] = $before_search['syntax_before'];
  $out_formats['before'] = $before_search['syntax_after'];
}
// process main to see if there is a SIDEBAR tag
$sidebar_search = pcom_get_strings_syntax_separator($out_formats['main'],$sidebar_tag,true);
//
if ( $sidebar_search['command_found'] == true ) {
  $out_formats['sidebar_found'] = true;
  $out_formats['main'] = $sidebar_search['syntax_before'];
  $out_formats['sidebar'] = $sidebar_search['syntax_after'];
  // process SIDEBAR for AFTER tag
  $after_search = pcom_get_strings_syntax_separator($out_formats['sidebar'],$after_tag,true);
  if ( $after_search['command_found'] == true ) {
    $out_formats['after_found'] = true;
    $out_formats['sidebar'] = $after_search['syntax_before'];
    $out_formats['after'] = $after_search['syntax_after'];
  }
//
} else {
// process for AFTER tag
  $after_search = pcom_get_strings_syntax_separator($out_formats['main'],$after_tag,true);
  if ( $after_search['command_found'] == true ) {
    $out_formats['after_found'] = true;
    $out_formats['main'] = $after_search['syntax_before'];
    $out_formats['after'] = $after_search['syntax_after'];
  }
}
//
return $out_formats;
//
}
//
function pcom_process_remote_schematic_tag($format) {
// searches for ///REMOTE:
$out_format = $format;
$remote = $GLOBALS['PM_REMOTE_SCHEMATIC_TAG'];
//
$remote_search = pcom_get_strings_syntax_separator($format,$remote,true);
if ( $remote_search['command_found'] == true ) {
  //
  $args = array(
    'open' => constant('pcom_commands::PCOM_SCHEMATIC_COMMAND_OPEN'),
    'close' => constant('pcom_commands::PCOM_SCHEMATIC_COMMAND_CLOSE')
  );
  // process syntax after for %%REMOTE_SCHEMATIC_AWS:: command
  $remote_command = pcom_process_command_open_close_syntax($remote_search['syntax_after'],$args);
  //
  if ($remote_command['command_found'] == true) {
    $out_format = pcom_fetch_remote_schematic_from_file($remote_command['syntax_after'],null,null);
  }
  //
}
//
return $out_format;
}
//
// ----- -----
// get first command - returns array of command and command syntax
function pcom_get_first_command($format,$args) {
// check args - default is schematic commands
// can be used for inserts as well
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
$args_used = array(
'open' => constant('pcom_commands::PCOM_SCHEMATIC_COMMAND_OPEN'),
'close' => constant('pcom_commands::PCOM_SCHEMATIC_COMMAND_CLOSE')
);
// condition input
if ($args == null) $args = array();
//
$args_used = array_replace($args_used,$args);
//
$current_command = $no_entry ;
$current_syntax = $no_entry ;
$next_string = $no_entry ;
//
// only execute for non empty format
if ( !empty($format) ) {
  // search for command end
  $command_close = pcom_get_strings_syntax_separator($format,$args_used['close'],true);
  if ($command_close['command_found'] == true) {
  // search for command open
    $command_open = pcom_get_strings_syntax_separator($command_close['syntax_before'],$args_used['open'],true);
    if ($command_open['command_found'] == true) {
      $current_command = $command_open['syntax_after'];
      // retrieve syntax - search for next command open
      $get_syntax = pcom_get_strings_syntax_separator($command_close['syntax_after'],$args_used['open'],true);
      $current_syntax = $get_syntax['syntax_before'];
      // if next command found - add open schematic to syntax after
      // so it will be recognised on the next call of the function
      if ($get_syntax['command_found'] == true) {
        $next_string = $args_used['open'] . $get_syntax['syntax_after'];
      }
    }
  }
//
}
//
$out_array = array(
  'command' => $current_command,
  'command_syntax' => $current_syntax,
  'next_command' => $next_string
);
//
return $out_array;
//
}
// ---------
// REMOTE_SCHEMATIC_AWS
function pcom_process_remote_schematic_command($syntax,$custom_class,$placement) {
//
$data_retrieved = '';
$custom_remote_attributes = $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES'];
// replace custom keys
$syntax = pcom_replace_custom_attributes($syntax,$custom_remote_attributes);
//
$args_in = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
// ----------
  // only one command - SCHEMATIC=[]:
  $data = pcom_process_command_open_close_syntax($syntax,null);
  //
  switch ( $data['command'] ) {
  // fetch data
  case $GLOBALS['PM_REMOTE_SCHEMATIC_AWS_SUBCOMMAND'] :
  // process syntax
    $args_in = pcom_process_keyword_args($data['command_syntax'],$args_in);
    $data_retrieved = pcom_get_object_aws($args_in,$GLOBALS['PM_REMOTE_SCHEMATIC_AWS_SUBCOMMAND']);
    // process schematic data from file
    polimorf_process_schematic($data_retrieved,$placement);
  //
  break;
//
  }
//
}
// -----------
// REMOTE_ADDITION_AWS
function pcom_process_remote_addition_command($syntax,$custom_class,$placement) {
//
$data_retrieved = '';
$custom_remote_attributes = $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES'];
// replace custom keys
$syntax = pcom_replace_custom_attributes($syntax,$custom_remote_attributes);
//
$args_in = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
// ----------
  // only one command - SCHEMATIC=[]:
  $data = pcom_process_command_open_close_syntax($syntax,null);
  //
  switch ( $data['command'] ) {
  // fetch data
  case $GLOBALS['PM_REMOTE_SCHEMATIC_AWS_SUBCOMMAND'] :
  // process syntax
    $args_in = pcom_process_keyword_args($data['command_syntax'],$args_in);
    $data_retrieved = pcom_get_object_aws($args_in,$GLOBALS['PM_REMOTE_SCHEMATIC_AWS_SUBCOMMAND']);
    // process schematic data from file
    polimorf_process_addition($data_retrieved,$placement);
  //
  break;
//
  }
//
}
//
function pcom_fetch_remote_schematic_from_file($syntax,$custom_class,$placement) {
// used in remote schematic call
$data_retrieved = '';
$custom_remote_attributes = $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES'];
// replace custom keys
$syntax = pcom_replace_custom_attributes($syntax,$custom_remote_attributes);
//
$args_in = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
// ----------
  // only one command - SCHEMATIC=[]:
  $data = pcom_process_command_open_close_syntax($syntax,null);
  //
  if ( $data['command'] == $GLOBALS['PM_REMOTE_SCHEMATIC_AWS_SUBCOMMAND'] ) {
  // process syntax
    $args_in = pcom_process_keyword_args($data['command_syntax'],$args_in);
    // use SCHEMATIC keyword as it retrives data
    $data_retrieved = pcom_get_object_aws($args_in,$GLOBALS['PM_REMOTE_SCHEMATIC_AWS_SUBCOMMAND']);
    //
  }
//
return $data_retrieved;
}
//
//
//
// -----------
function pcom_get_remote_presigned_link($syntax,$custom_class,$placement) {
//
$presigned_src = '';
//
$custom_remote_attributes = $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES'];
// replace custom keys
$syntax = pcom_replace_custom_attributes($syntax,$custom_remote_attributes);
//
$args_in = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
// ----------
  // only one command - IMAGE=[]:
  $data = pcom_process_command_open_close_syntax($syntax,null);
  //
  if ( $data['command'] == constant('pcom_commands::PCOM_REMOTE_IMAGE_SUBCOMMAND') ) {
  // process syntax
    $args_in = pcom_process_keyword_args($data['command_syntax'],$args_in);
    //
    $presigned_src = pcom_get_object_aws($args_in,constant('pcom_commands::PCOM_REMOTE_IMAGE_SUBCOMMAND'));
    //
  }
//
return $presigned_src;
}
//
function pcom_process_custom_command($command) {
  // parse command for custom keyword to pass onto class in html
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $command_custom = array('command'=> $no_entry,'custom_class' => $no_entry);
  $process_custom = pcom_get_strings_syntax_separator($command,$GLOBALS['PM_CUSTOM_CLASS_DECLARATION'],true);
  $command_custom['command'] = $process_custom['syntax_before'];
  $command_custom['custom_class'] = $process_custom['syntax_after'];
  //
  return $command_custom;
//
}
//
// ---------
//
function pcom_get_strings_syntax_separator($syntax,$separator,$trim) {
// returns commands before separator and after
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
$out_array = array(
'command_found' => false,
'syntax_before' => $no_entry,
'syntax_after' => $no_entry
);
// set command found
$find_separator = strpos($syntax,$separator);
if ($find_separator !== false ) {
  $out_array['command_found'] = true;
  // get data
  $split_array = explode($separator,$syntax,2); // splits into before and after
  // set out array
  if ($trim == true) {
    $out_array['syntax_before'] = trim($split_array[0]);
    $out_array['syntax_after'] = trim($split_array[1]);
  } else {
    $out_array['syntax_before'] = $split_array[0];
    $out_array['syntax_after'] = $split_array[1];
  }
} else {
  $out_array['syntax_before'] = $syntax;
}
//
return $out_array;
//
}
//
function pcom_process_command_open_close_syntax($syntax,$args){
// used with a series of commands
//
// define args
// default are SUB_COMMAND
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
$args_used = array(
'open' => constant('pcom_commands::PCOM_SUB_COMMAND_OPEN'),
'close' => constant('pcom_commands::PCOM_SUB_COMMAND_CLOSE')
);
// condition input
if ($args == null) $args = array();
//
$args_used = array_replace($args_used,$args);
//
// initialise array - command found, command, command syntax, syntax after
$out_array = array(
  'command_found' => false,
  'command' => $no_entry,
  'command_syntax' => $no_entry,
  'syntax_after' => $no_entry
);
// find command start
$commands = pcom_get_strings_syntax_separator($syntax,$args_used['close'],true);
// if command end found
  if ( $commands['command_found'] != false ) {
    // set output string as remaining keyword commands
    $temp_after = $commands['syntax_after'];
    // process syntax before command end
    $commands = pcom_get_strings_syntax_separator($commands['syntax_before'],$args_used['open'],true);
    if ( $commands['command_found'] != false ) {
     $out_array['command_found'] = true;
     $out_array['command'] = $commands['syntax_before'];
     $out_array['command_syntax'] = $commands['syntax_after'];
     $out_array['syntax_after'] = $temp_after;
   }
  }
//
return $out_array;
}
//
function pcom_process_keyword_args($command_string,$allowed_args){
// goes through keyword syntax matching against arguments
// returns an array of argument tags with content
// search for first argument
//
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
$arg_start = constant('pcom_commands::PCOM_ATTRIBUTE_OPEN');
$arg_end = constant('pcom_commands::PCOM_ATTRIBUTE_CLOSE');
$clean_array = array();
//
  while ($found_args['syntax_after'] != $no_entry) {
    $found_args = pcom_get_strings_syntax_separator($command_string,$arg_start,true);
    // set argument keyword
    $arg_keyword = $found_args['syntax_before'];
    $command_string = $found_args['syntax_after'];
    // find argument end
    $end_args = pcom_get_strings_syntax_separator($command_string,$arg_end,true);
    $arg_detail = $end_args['syntax_before'];
    $command_string = $end_args['syntax_after'];
    //
    // check if in list of allowed_args
    if (array_key_exists($arg_keyword,$allowed_args)) {
      // santizes argument
      $allowed_args[$arg_keyword] = wp_kses($arg_detail,$clean_array);
    }
  }
return $allowed_args;
}
//
function pcom_open_custom_class_div($custom_class,$opening_html) {
// uses the opening html to add in a custom class call if needed
// --
// requires the opening html have the class variable last
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
//
  if ( ( $custom_class != $no_entry ) && ( $custom_class != null ) ) {
    // insert custom class into div - sanitize class
    echo $opening_html . ' ' . esc_attr($custom_class) . constant('pmschematics::PM_CLOSE_DIV_WITH_COMMAS');
  } else {
    // no custom class
    echo $opening_html . constant('pmschematics::PM_CLOSE_DIV_WITH_COMMAS');
  }
}
// return version
//
function pcom_return_open_custom_class_div($custom_class,$opening_html) {
// uses the opening html to add in a custom class call if needed
// --
// requires the opening html have the class variable last
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
//
  if ( ( $custom_class != $no_entry ) && ( $custom_class != null ) ) {
    // insert custom class into div - sanitize class
    $out =  $opening_html . ' ' . esc_attr($custom_class) . constant('pmschematics::PM_CLOSE_DIV_WITH_COMMAS');
  } else {
    // no custom class
    $out = $opening_html . constant('pmschematics::PM_CLOSE_DIV_WITH_COMMAS');
  }
//
return $out;
}
// ====
//
function pcom_process_content_inserts($syntax) {
//
$inserts = array();
// process insert keys and syntax using text command functions.
// TEXT=[]: syntax is currently used
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
$insert_start = constant('pcom_commands::PCOM_INSERTS_OPEN');
$insert_close = constant('pcom_commands::PCOM_INSERTS_CLOSE');
//
$args = array(
'open' => $insert_start,
'close' => $insert_close
);
//
  if ( !empty($syntax) ){
    while ( $text_inserts['command'] != $no_entry ) {
      $text_inserts = pcom_get_first_command($syntax,$args);
      $key = $insert_start . $text_inserts['command'] . $insert_close;
      // add key and value to inserts array
      if ( $text_inserts['command'] != $no_entry ){
//
        $val = pcom_process_insert_subcommands($text_inserts['command_syntax'],$placement);
        if ($val != $no_entry ) {
          $inserts[$key] = $val;
        } else {
          $inserts[$key] = null;
        }
      }
      //
      $syntax = $text_inserts['next_command'];
    }
  }
//
return $inserts;
}
//
function pcom_process_insert_subcommands($syntax,$placement) {
// processes text content inserts
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
//
  if ( !empty($syntax) ){
      //
      $commands = pcom_process_command_open_close_syntax($syntax,null); // default sub commands
  //
      if ($commands['command_found'] != false ) {
  //
        switch ($commands['command']) {
          //
          case $GLOBALS['PM_TEXT_COMMAND'] :
            $html_out = pcom_process_text_command($commands['command_syntax']);
          break;
          //
          default:
          // do nothing
          break;
        }
        // update syntax
        if ( $commands['syntax_after'] != $no_entry ) {
          $syntax = $html_out . $commands['syntax_after'];
        } else {
          $syntax = $html_out;
        }
//
      }
//
  }
//
return $syntax;
}
//
// PROCESSING OF TEXT COMMANDS TO HTML
// --------
/**
 * Process syntax for text, links, captions, image and links
 * then return html string for output
 *
 * @param string $syntax
 * @return string $html_out
 *
 * @since 1.0.0
 */
function pcom_process_text_command($syntax){
//
// clean tags - no html allowed
//
$syntax = wp_kses($syntax,array());
//
$html_out = pcom_process_post_text($syntax);
// process img_link
$html_out = pcom_process_attribute_syntax($html_out,$GLOBALS['PM_TEXT_IMG_LINK_KEYWORD']);
// process link
$html_out = pcom_process_attribute_syntax($html_out,$GLOBALS['PM_TEXT_LINK_KEYWORD']);
// process img
$html_out = pcom_process_attribute_syntax($html_out,$GLOBALS['PM_TEXT_IMG_KEYWORD']);
//
return $html_out;
}
//
function pcom_process_post_text($syntax){
// process site constants first
$processed = pcom_site_constants_replacement($processed);
// process text for pcom commands and convert
$conversions = $GLOBALS['PM_TEXT_HTML_CONVERSIONS'];
$processed = str_replace(array_keys($conversions), $conversions, $syntax);
//
return $processed;
}
//
//
function pcom_process_attribute_syntax($syntax,$type){
//
// check type - img, img_link or link
$img_keyword = $GLOBALS['PM_TEXT_IMG_KEYWORD'];
$img_link_keyword = $GLOBALS['PM_TEXT_IMG_LINK_KEYWORD'];
$link_keyword = $GLOBALS['PM_TEXT_LINK_KEYWORD'];
//
  if ( ($type == $img_keyword) || ($type == $link_keyword) || ($type == $img_link_keyword) ) {
    $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
    $close_keyword = constant('pcom_commands::PCOM_KEYWORD_CLOSE');
    $attr_start = constant('pcom_commands::PCOM_KEYWORD_OPEN');

    // create link keyword with opener depending on type
    switch ($type) {
      case $link_keyword :
        $open_keyword = $link_keyword;
      break;
      //
      case $img_keyword :
        $open_keyword = $img_keyword;
      break;
      //
      case $img_link_keyword :
        $open_keyword = $img_link_keyword;
      break;
    }
    $open_keyword = $open_keyword . $attr_start;
    //
    while ( $attributes['syntax_after'] != $no_entry ) {
      // search for opening command and preserve text before i.e. no trim
      $attributes = pcom_get_strings_syntax_separator($syntax,$open_keyword,false);
      // check keyword was found else exit with no change
      if ( $attributes['syntax_after'] != $no_entry ) {
        //
        $syntax_before = $attributes['syntax_before'];
        // search for links end
        $attributes = pcom_get_strings_syntax_separator($attributes['syntax_after'],$close_keyword,false);
        $to_process = $attributes['syntax_before'];
        // check for end of keyword - else exit with no change
        if ( $attributes['syntax_after'] != $no_entry ) {
          $syntax_after = $attributes['syntax_after'];
          // process attributes
          switch ($type) {
            //
            case $link_keyword :
              $processed_html = pcom_process_link_syntax($to_process);
            break;
            //
            case $img_keyword :
              $processed_html = pcom_process_img_syntax($to_process);
            break;
            //
            case $img_link_keyword :
              $processed_html = pcom_process_img_link_syntax($to_process);
            break;
          }
          // add to original syntax but check that $syntax_after is not $no_entry
          if ($syntax_after != $no_entry ){
            $syntax = $syntax_before . trim($processed_html) . $syntax_after;
          }
//
        } // exit with no change to syntax - keyword end not found
//
      } // exit with no change to syntax - keyword start not found
//
    }
//
  }
//
return $syntax;
}
//
function pcom_process_img_syntax($syntax){
  $img_attributes = $GLOBALS['PM_IMG_ATTRIBUTES'];
  $general_attributes = $GLOBALS['PM_HTML_GLOBAL_ATTRIBUTES'];
  $remote_attributes = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
  //
  // replace custom attributes
  $custom_img_attributes = $GLOBALS['PM_CUSTOM_IMAGE_ATTRIBUTES'];
  $custom_general_attributes = $GLOBALS['PM_CUSTOM_HTML_ATTRIBUTES'];
  $custom_remote_attributes = $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES'];
  //
  $syntax = pcom_replace_custom_attributes($syntax,$custom_img_attributes);
  $syntax = pcom_replace_custom_attributes($syntax,$custom_general_attributes);
  $syntax = pcom_replace_custom_attributes($syntax,$custom_remote_attributes);
  //
  //
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $arg_start = constant('pcom_commands::PCOM_ATTRIBUTE_OPEN');
  $arg_end = constant('pcom_commands::PCOM_ATTRIBUTE_CLOSE');
  // get attribute allocations
  $img_attributes = pcom_process_keyword_args($syntax,$img_attributes);
  $general_attributes = pcom_process_keyword_args($syntax,$general_attributes);
  $remote_attributes = pcom_process_keyword_args($syntax,$remote_attributes);
  // process for remote attributes - if not present process shortcuts
  $img_attributes['src'] = pcom_process_remote_url_syntax($img_attributes['src'],$remote_attributes);
  //
  $img_string = "";
  // process general attributes first
    foreach($general_attributes as $key => $val){
      if ( $val != $no_entry ) {
        // sanitize value
        $val = pcom_esc_output_functions($val,$key);
        $img_string = $img_string . $key . $arg_start . $val . $arg_end . ' ';
      }
    }
    // trim last space if any
    $img_string = trim($img_string);
    //
    // process img attributes
    foreach($img_attributes as $key => $val){
      if ( ( $val != $no_entry ) && ( $img_attributes['src'] != $no_entry ) &&
      ( $key != $GLOBALS['PM_FA_ATTRIBUTE'] ) ) {
        $val = pcom_esc_output_functions($val,$key);
        $img_string = $img_string . $key . $arg_start . $val . $arg_end . ' ';
      }
    }
    // trim last space if any and output if not empty
    $img_string = trim($img_string);
    if (!empty($img_string)) {
      $out_string = '<img ' . $img_string . ' />' . "\r\n";
    }
    //
    // append icon if present
    if ($img_attributes[$GLOBALS['PM_FA_ATTRIBUTE']] != $no_entry ) {
      $fa = $img_attributes[$GLOBALS['PM_FA_ATTRIBUTE']];
      $fa = pcom_esc_output_functions($fa,'fa');
      // create icon - append to src
      $out_string = $out_string . constant('pmschematics::PM_FA_ICON_OPEN') . $fa .
      constant('pmschematics::PM_FA_ICON_CLOSE');
    }
//
return $out_string;
}
//
function pcom_process_remote_url_syntax($url,$remote_args) {
// if remote args - filename, bucketname and region are non-zero then
// use these to form a presigned url
// otherwise - check url for shortcuts
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  if ( ( $remote_args['filename'] != $no_entry ) && ( $remote_args['bucketname'] != $no_entry )
  && ( $remote_args['region'] != $no_entry ) ) {
    $url = pcom_get_object_aws($remote_args,constant('pcom_commands::PCOM_REMOTE_IMAGE_SUBCOMMAND'));
  } else {
    $url = pcom_site_constants_replacement($url);
  }
//
return $url;
}
//
function pcom_process_remote_url_syntax_remote_image_link($url,$remote_args_in,$type) {
// if remote args - filename, bucketname and region are non-zero then
// use these to form a presigned url
// otherwise - check url for shortcuts
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
$remote_args = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
//
switch ($type) {
//
  case constant('pcom_commands::PCOM_REMOTE_IMAGE_LINK_TYPE_LINK') :
//
  if ( ( $remote_args_in['link_filename'] != $no_entry ) && ( $remote_args_in['link_bucketname'] != $no_entry )
  && ( $remote_args_in['link_region'] != $no_entry ) ) {
    // map attributes
    $remote_args = pcom_map_remote($remote_args_in,$remote_args,$type);
    //
    $url = pcom_get_object_aws($remote_args,constant('pcom_commands::PCOM_REMOTE_IMAGE_SUBCOMMAND')); // REMOTE_IMAGE also covers links
  } else {
    $url = pcom_site_constants_replacement($url);
  }
//
  break;
//
  case constant('pcom_commands::PCOM_REMOTE_IMAGE_LINK_TYPE_IMAGE') :
//
  if ( ( $remote_args_in['image_filename'] != $no_entry ) && ( $remote_args_in['image_bucketname'] != $no_entry )
  && ( $remote_args_in['image_region'] != $no_entry ) ) {
    // map attributes
    $remote_args = pcom_map_remote($remote_args_in,$remote_args,$type);
    //
    $url = pcom_get_object_aws($remote_args,constant('pcom_commands::PCOM_REMOTE_IMAGE_SUBCOMMAND'));
  } else {
    $url = pcom_site_constants_replacement($url);
  }
//
  break;
//
}
//
return $url;
}
//
function pcom_map_remote($args_in,$remote_args,$type) {
// maps link and image arguments to remote args
switch ($type) {
//
  case constant('pcom_commands::PCOM_REMOTE_IMAGE_LINK_TYPE_LINK') :
    //
      $remote_args['filename'] = $args_in['link_filename'];
      $remote_args['region'] = $args_in['link_region'];
      $remote_args['timeout'] = $args_in['link_timeout'];
      $remote_args['bucketname'] = $args_in['link_bucketname'];
//
  break;
//
  case constant('pcom_commands::PCOM_REMOTE_IMAGE_LINK_TYPE_IMAGE') :
//
      $remote_args['filename'] = $args_in['image_filename'];
      $remote_args['region'] = $args_in['image_region'];
      $remote_args['timeout'] = $args_in['image_timeout'];
      $remote_args['bucketname'] = $args_in['image_bucketname'];
//
  break;
//
}
return $remote_args;
}
//
// =============
//
function pcom_process_img_link_syntax($syntax){
  // set link array
  $link_attributes = $GLOBALS['PM_LINK_ATTRIBUTES'];
  // set image array
  $img_attributes = $GLOBALS['PM_IMG_ATTRIBUTES'];
  $general_attributes = $GLOBALS['PM_HTML_GLOBAL_ATTRIBUTES'];
  // remote link attributes
  $remote_link_attributes = $GLOBALS['PM_REMOTE_ATTRIBUTES_REMOTE_LINK'];
  // remote image attributes
  $remote_image_attributes = $GLOBALS['PM_REMOTE_ATTRIBUTES_REMOTE_IMAGE'];
  //
  // --
  //
  // replace custom attributes
  $custom_link_attributes = $GLOBALS['PM_CUSTOM_LINK_ATTRIBUTES'];
  $custom_img_attributes = $GLOBALS['PM_CUSTOM_IMAGE_ATTRIBUTES'];
  $custom_general_attributes = $GLOBALS['PM_CUSTOM_HTML_ATTRIBUTES'];
  $custom_remote_link_attributes = $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES_REMOTE_LINK'];
  $custom_remote_img_attributes = $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES_REMOTE_IMAGE'];
  //
  $syntax = pcom_replace_custom_attributes($syntax,$custom_link_attributes);
  $syntax = pcom_replace_custom_attributes($syntax,$custom_img_attributes);
  $syntax = pcom_replace_custom_attributes($syntax,$custom_general_attributes);
  $syntax = pcom_replace_custom_attributes($syntax,$custom_remote_link_attributes);
  $syntax = pcom_replace_custom_attributes($syntax,$custom_remote_img_attributes);
  //
  // --
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $arg_start = constant('pcom_commands::PCOM_ATTRIBUTE_OPEN');
  $arg_end = constant('pcom_commands::PCOM_ATTRIBUTE_CLOSE');
  $type_link = constant('pcom_commands::PCOM_REMOTE_IMAGE_LINK_TYPE_LINK');
  $type_image = constant('pcom_commands::PCOM_REMOTE_IMAGE_LINK_TYPE_IMAGE');
  // get attribute allocations
  $link_attributes = pcom_process_keyword_args($syntax,$link_attributes);
  $img_attributes = pcom_process_keyword_args($syntax,$img_attributes);
  $general_attributes = pcom_process_keyword_args($syntax,$general_attributes);
  $remote_link_attributes = pcom_process_keyword_args($syntax,$remote_link_attributes);
  $remote_image_attributes = pcom_process_keyword_args($syntax,$remote_image_attributes);
  // process for remote attributes - if not present process shortcuts - function performs santization
  $link_attributes['href'] = pcom_process_remote_url_syntax_remote_image_link($link_attributes['href'],$remote_link_attributes,$type_link);
  $img_attributes['src'] = pcom_process_remote_url_syntax_remote_image_link($img_attributes['src'],$remote_image_attributes,$type_image);
  //
  // ==========
  // PROCESS LINK
  $link_string = "";
  // process general attributes first
  // these will be applied to the link rather than the image
  foreach($general_attributes as $key => $val){
    if ( $val != $no_entry ) {
      // sanitize value
      $val = pcom_esc_output_functions($val,$key);
      $link_string = $link_string . $key . $arg_start . $val . $arg_end . ' ';
    }
  }
  // trim last space if any
  $link_string = trim($link_string);
  //
  // process link attributes - apart from text
  foreach($link_attributes as $key => $val){
    if ( ( $val != $no_entry ) && ( $val != $GLOBALS['PM_TEXT_ATTRIBUTE'] ) ) {
      $val = pcom_esc_output_functions($val,$key);
      $link_string = $link_string . $key . $arg_start . $val . $arg_end . ' ';
    }
  }
  // trim last space if any
  $link_string = trim($link_string);
  //
  // ==============
  // PROCESS IMG
  $img_string = "";
  foreach($img_attributes as $key => $val){
    if ( ( $val != $no_entry ) && ( $img_attributes['src'] != $no_entry ) &&
    ( $key != $GLOBALS['PM_FA_ATTRIBUTE'] ) ) {
      $val = pcom_esc_output_functions($val,$key);
      $img_string = $img_string . $key . $arg_start . $val . $arg_end . ' ';
    }
  }
  // trim last space if any
  $img_string = trim($img_string);
  //
  if (!empty($img_string) ) {
    $img_string = '<img ' . $img_string . ' />' . "\r\n";
  }
  // append icon if present
  if ($img_attributes[$GLOBALS['PM_FA_ATTRIBUTE']] != $no_entry ) {
    $fa = $img_attributes[$GLOBALS['PM_FA_ATTRIBUTE']];
    $fa = pcom_esc_output_functions($fa,'fa');
    // create icon - append to src
    $img_string = $img_string . constant('pmschematics::PM_FA_ICON_OPEN') . $fa .
    constant('pmschematics::PM_FA_ICON_CLOSE');
  }
  //
  // create string if text is not no_entry
  $out_string = '<a ' . $link_string . '>' . $img_string . '</a>' . "\r\n";
  //
return $out_string;
//
}
//
function pcom_process_link_syntax($syntax){
// set link array
$link_attributes = $GLOBALS['PM_LINK_ATTRIBUTES'];
$general_attributes = $GLOBALS['PM_HTML_GLOBAL_ATTRIBUTES'];
$remote_attributes = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
//
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
$arg_start = constant('pcom_commands::PCOM_ATTRIBUTE_OPEN');
$arg_end = constant('pcom_commands::PCOM_ATTRIBUTE_CLOSE');
// replace custom attributes
$custom_link_attributes = $GLOBALS['PM_CUSTOM_LINK_ATTRIBUTES'];
$custom_general_attributes = $GLOBALS['PM_CUSTOM_HTML_ATTRIBUTES'];
$custom_remote_attributes = $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES'];
//
$syntax = pcom_replace_custom_attributes($syntax,$custom_link_attributes);
$syntax = pcom_replace_custom_attributes($syntax,$custom_general_attributes);
$syntax = pcom_replace_custom_attributes($syntax,$custom_remote_attributes);
//
// get attribute allocations
$link_attributes = pcom_process_keyword_args($syntax,$link_attributes);
$general_attributes = pcom_process_keyword_args($syntax,$general_attributes);
$remote_attributes = pcom_process_keyword_args($syntax,$remote_attributes);
// process for remote attributes - if not present process shortcuts
$link_attributes['href'] = pcom_process_remote_url_syntax($link_attributes['href'],$remote_attributes);
//
$link_string = "";
// process general attributes first
  foreach($general_attributes as $key => $val){
    if ( $val != $no_entry ) {
      // sanitize value
      $val = pcom_esc_output_functions($val,$key);
      $link_string = $link_string . $key . $arg_start . $val . $arg_end . ' ';
    }
  }
  // trim last space if any
  $link_string = trim($link_string);
  //
  // process link attributes - apart from text
  foreach($link_attributes as $key => $val){
    if ( ( $val != $no_entry ) && ( $key != $GLOBALS['PM_TEXT_ATTRIBUTE'] ) ) {
      $val = pcom_esc_output_functions($val,$key);
      $link_string = $link_string . $key . $arg_start . $val . $arg_end . ' ';
    }
  }
  // trim last space if any
  $link_string = trim($link_string);
  //
  // create string if text is not no_entry
  if ( $link_attributes[$GLOBALS['PM_TEXT_ATTRIBUTE']] != $no_entry ) {
    $out_string = '<a ' . $link_string . '>' .
    $link_attributes[$GLOBALS['PM_TEXT_ATTRIBUTE']] . '</a>' . "\r\n";
  }
//
return $out_string;
}
// =====
// SITE HOME
// -----
function pcom_site_constants_replacement($content) {
// replaces SITE_HOME with blog url
// replaces IMAGES with template_url & /images
// used for link commands in both text and html link
$site_ref_constants = array(
constant('pcom_commands::PCOM_SITE_HOME') => esc_url($GLOBALS['$blog_url']),
constant('pcom_commands::PCOM_IMAGES') => esc_url($GLOBALS['$blog_template']) . '/images',
constant('pcom_commands::PCOM_UPLOADS') => esc_url($GLOBALS['$blog_url']) . '/wp-content/uploads'
);
$custom_constants = $GLOBALS['PM_CUSTOM_SITE_REPLACEMENTS'];
// check for customised keys
$content_update = str_replace(array_keys($custom_constants), $custom_constants, $content);
// replace with paths
$content_update = str_replace(array_keys($site_ref_constants), $site_ref_constants, $content_update);
//
return $content_update;
}
// ESCAPE FUNCTIONS
function pcom_esc_output_functions($val,$type){
// esc_url for href, hreflang and src
// esc_attr for other attributes
  switch($type){
    case 'href' :
      $val = esc_url($val);
    break;
    //
    case 'hreflang' :
      $val = esc_url($val);
    break;
    //
    case 'src' :
      $val = esc_url($val);
    break;
    //
    default :
      $val = esc_attr($val);
    break;
  }
//
return $val;
}
//
function pcom_remove_http($string){
// remove http:// or https:// from string
// as well as backslash versions
$args = array(
  'http://' => '',
  'https://' => '',
  'http:\\' => '',
  'https:\\' => ''
);
$string =  str_replace(array_keys($args),$args,$string);
//
return $string;
}
//
function pcom_denasty_string($string){
// removes SELECT, UNION, DROP, DROP TABLE
$nasties = constant('pcom_commands::PCOM_NASTY_REPLACE');
$denastied = str_replace(array_keys($nasties),$nasties,$string);
//
return $denastied;
//
}
//
function pcom_check_cloud_parameter($parameter){
  // denasty
  $parameter = pcom_denasty_string($parameter);
  // remove http https
  $parameter = pcom_remove_http($parameter);
  // clean other stuff
  $parameter = wp_kses($parameter,array());
  // esc
  $parameter = esc_attr($parameter);
  // set no entry if null or empty
  $parameter = pcom_check_no_entry($parameter);
//
return $parameter;
}
// create placeholder
function pcom_create_placeholder($string){
// replaces string characters with bullet
$replaced = ''; // empty
$count = 0;
//
  while ($count < strlen($string)) {
    $replaced = $replaced . '&bull;';
    $count = $count + 1;
  }
return $replaced;
}
//
//
function pcom_check_no_entry($string){
// sets empty or null string to no_entry
// can be used to have a tangible negation
$no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
//
if ( ($string == null) || empty($string) ) { $string = $no_entry; }
return $string;
}
//
//
function pcom_replace_custom_attributes($syntax,$custom_keys) {
// replace custom attributes with mandated ones
$syntax = str_replace(array_keys($custom_keys), $custom_keys, $syntax);
return $syntax;
}
//
// end of file
