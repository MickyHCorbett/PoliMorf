<?php
//
//
/**
 * Adds scroll reveal content to page head and footer.
 * Function will hook to wp_head
 * and wp_footer with customised priority
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - not processed
 * @param string $placement - string denoting code only processed in header
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_javascript_effect($syntax,$custom_class,$placement)
 {
  // placement - must be called in header
  // function will hook to wp_head with priority 500
  // and wp_footer with 500
  //
  // this is so it will be fired after everything else
  //
  // custom class is not processed
  // syntax uses keywords
  //
  $args = array(
    'open' => constant('pcom_commands::PCOM_KEYWORD_OPEN'),
    'close' => constant('pcom_commands::PCOM_KEYWORD_CLOSE'),
  );
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  //
  if ($placement == constant('pcom_commands::PCOM_HEADER_PLACEMENT')) {
    // replace custom attributes
    $syntax = pcom_replace_custom_attributes($syntax,$GLOBALS['PM_CUSTOM_REVEAL_EFFECTS_ATTRIBUTES']);
    // loop over syntax entries
      while ($commands['syntax_after'] != $no_entry) {
        $commands = pcom_process_command_open_close_syntax($syntax,$args);
    //
        if ($commands['command_found'] == true){
    //
          switch($commands['command']) {
    //
          case $GLOBALS['PM_REVEAL_EFFECT_KEYWORD'] :
            pcom_process_reveal_effect($commands['command_syntax']);
          break;
    //
          }
        // - end if
        }
        $syntax = $commands['syntax_after'];
      // - end while
      }
    // - end $placement
  }
  // hook into footer
  add_action('wp_footer', 'pcom_hook_reveal_to_footer', $GLOBALS['PM_EFFECT_PRIORITY']);
  // end function
  //
 }
//
/**
 * Looks for class and settings in attributes
 * to set up scroll reveal js effect
 *
 * @param string $syntax - command syntax
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_process_reveal_effect($syntax)
 {
  //
  $args = $GLOBALS['PM_REVEAL_EFFECT_ATTRIBUTES'];
  $out_script = '';
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  //
  // process syntax for keywords
  $args = pcom_process_keyword_args($syntax,$args);
  // check if class is not no entry
    if ($args['class'] != $no_entry) {
      // hook initialisation to wp_head
      add_action('wp_head', 'pcom_add_reveal_to_head',$GLOBALS['PM_EFFECT_PRIORITY']);
      // create style statement in header
      ?><style><!-- <?php echo esc_attr($args['class']); ?> { visibility: hidden; } --></style><?php
      //
      // create footer data
      $out_array['class'] = $args['class'];
      if ($args['settings'] != $no_entry) {
        // remove ; characters
        $args['settings'] = str_replace(';','',$args['settings']);
        $out_array['settings'] = ', { ' . $args['settings'] .' }';
      }
      // increment count
      $GLOBALS['pm_footer_script_count'] = $GLOBALS['pm_footer_script_count'] + 1;
      // add to global footer script
      $GLOBALS['pm_footer_script_data'][$GLOBALS['pm_footer_script_count'] - 1] = $out_array;
  //
    }
  //
 }
//
// ==
//
/**
 * Adds sr as a function to head
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_reveal_to_head()
 {
  echo constant('pmschematics::PM_SCROLL_REVEAL_SOURCE_INCLUDE');
  ?>
  <!-- load and instantiate ScrollReveal first -->
  <script>window.sr = ScrollReveal();</script>
  <?php
 }
//
//
/**
 * Adds footer script to wp_footer
 * Function is called for wp_footer hook in pcom_add_javascript_effect
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_hook_reveal_to_footer()
 {
  //
  $data = $GLOBALS['pm_footer_script_data'];
  $count = $GLOBALS['pm_footer_script_count'];
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  //
    if ($count > 0) {
      foreach($data as $entry){
        if ($entry['class'] != $no_entry) {
          if ($entry['settings'] != $no_entry) {
            ?><script>sr.reveal('<?php echo esc_attr($entry['class']); ?>'<?php echo esc_attr($entry['settings']); ?>);</script><?php
          } else {
            ?><script>sr.reveal('<?php echo esc_attr($entry['class']); ?>');</script><?php
          }
        }
      }
    }
  // set back to default when done
  $GLOBALS['pm_footer_script_data'] = array();
  $GLOBALS['pm_footer_script_count'] = 0;
  //
 }
//
