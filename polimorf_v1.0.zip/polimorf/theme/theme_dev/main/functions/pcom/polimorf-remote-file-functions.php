<?php
//
//
// =================
//
/**
 * Processes attributes and returns either a text string
 * containing schematic data to be processed, or a formatted url
 * $type determines what gets returned
 *
 * @param array $args_in - remote attributes
 * @param string $type - link or retrieve data
 *
 * @return string $data - schematic data or url
 *
 * @since 1.0.0
 */
 function pcom_get_object_aws($args_in,$type)
 {
  //
  $def_exp = (int) $GLOBALS['PM_REMOTE_DEFAULT_EXPIRY'];
  $cloud_options = get_option('polimorf_cloud_options');
  $privatekey = pcom_check_cloud_parameter($cloud_options['cloud_private_key']);
  $publickey = pcom_check_cloud_parameter($cloud_options['cloud_public_key']);
  $data = ''; // placeholder for return
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $args =  array(
  'filename' => $no_entry,
  'region' => $no_entry,
  'timeout' => $def_exp,
  'bucketname' => $no_entry,
  'privatekey' => $privatekey,
  'publickey' => $publickey
  );
    // args in does not include keys
    foreach($args_in as $key => $val){
      // $args and $args in are the same format with the same keys
      // only update parameters that are not NO_ENTRY
      if ($val != $no_entry ) {
        $args[$key] = pcom_check_cloud_parameter($val);
      }
    }
  // check arguments - if no filename, region, bucketname, publickey or privatekey = no entry then do
  // no execute - return no url
    if ( ( $args['filename'] == $no_entry ) || ( $args['region'] == $no_entry ) || ( $args['bucketname'] == $no_entry ) || ( $args['publickey'] == $no_entry ) || ( $args['privatekey'] == $no_entry ) ) {
      //
      $data = constant('pcom_commands::PCOM_NO_URL');
      //
    } else {
  //
      switch ($type) {
      //
        case $GLOBALS['PM_REMOTE_SCHEMATIC_AWS_SUBCOMMAND'] :
        //
          //
          $aws_url = pcom_create_aws_remote_url($args);
          //
          $response = wp_remote_get($aws_url);
          $code = wp_remote_retrieve_response_code( $response );
          if ( $code == 200 ) {
            $data = wp_remote_retrieve_body( $response );
          } else {
            constant('pmschematics::PM_AWS_ERROR_START') . $code .
            constant('pmschematics::PM_AWS_ERROR_END');
          }
      //
        break;
  //
        case constant('pcom_commands::PCOM_REMOTE_IMAGE_SUBCOMMAND') :
        //
          $data = pcom_create_aws_remote_url($args);
        //
        break;
  //
      }
  //
    }
  //
  return $data;
 }
// ----
//
//
/**
 * Limits time in seconds to min and max values
 *
 * @param string $time - seconds
 *
 * @return string $time - seconds
 *
 * @since 1.0.0
 */
 function pcom_remote_limit_timestamp($time)
 {
  //
  $unit_string = ' seconds';
  // set to integer
  $time = (int) $time;
  if ( $time < $GLOBALS['PM_REMOTE_TIMEOUT_MIN'] ) {
    $time = $GLOBALS['PM_REMOTE_TIMEOUT_MIN'];
  }
  if ( $time > $GLOBALS['PM_REMOTE_TIMEOUT_MAX'] ) {
    $time = $GLOBALS['PM_REMOTE_TIMEOUT_MAX'];
  }
  // cast string to timestamp and return
  return (string) $time;
  //
 }
//
//
/**
 * Creates the aws presigned link according to AWS SDK
 * Only called it remote attributes are correct
 *
 * @param array $args - remote attributes
 *
 * @return string $url
 *
 * @since 1.0.0
 */
 function pcom_create_aws_remote_url($args)
 {
  // creates the payload link according to AWS SDK
  //
  $filename = $args['filename'];
  $bucketname = $args['bucketname'];
  $region = $args['region'];
  $timeout = pcom_remote_limit_timestamp($args['timeout']);
  $privatekey = $args['privatekey'];
  $publickey = $args['publickey'];
  //
  // set reference time to GMT
  date_default_timezone_set('UTC');
  $date = date('Ymd');
  $time = date('His');
  //
  $host = ($region == 'us-east-1') ? "$bucketname.s3.amazonaws.com" : "$bucketname.s3-$region.amazonaws.com";
  // fixed constants
  $rawslash = '%2F';
  //
  // create canonical request first then string to sign
  //
  // CANONICAL REQUEST
  // ---
  $canonical_request_body =
  'X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential='.$publickey.$rawslash.
  $date.$rawslash.$region.$rawslash.'s3'.$rawslash.'aws4_request&X-Amz-Date='.$date.'T'.$time.'Z'.'&X-Amz-Expires='.$timeout.
  '&X-Amz-SignedHeaders=host';
  //
  $encoded_uri = str_replace('%2F', '/', rawurlencode($filename));
  //
  $canonical_request =
  'GET'."\n".'/'.$encoded_uri."\n".
  $canonical_request_body."\n".
  'host:'.$host."\n"."\n".
  'host'."\n".
  "UNSIGNED-PAYLOAD";
  //
  // STRING TO SIGN
  // ---
  $hash_canonical_request = hash('sha256',$canonical_request);
  $string_to_sign =
  'AWS4-HMAC-SHA256'."\n".
  $date.'T'.$time.'Z'."\n".
  $date.'/'.$region.'/s3/aws4_request'."\n".
  $hash_canonical_request;
  //
  // SIGNING KEY
  // ---
  // hash date using AWS4 and privatekey
  $hashKey = 'AWS4'.$privatekey;
  $dateKey = hash_hmac('sha256',$date,$hashKey,true);
  // hash region using dateKey
  $dateRegionKey = hash_hmac('sha256',$region,$dateKey,true);
  // hash service using dateRegionKey
  $dateRegionServiceKey = hash_hmac('sha256','s3',$dateRegionKey,true);
  // hash aws4_request using dateRegionServiceKey to get signingKey
  $signingKey = hash_hmac('sha256','aws4_request',$dateRegionServiceKey,true);
  //
  // SIGNATURE
  // ---------
  // create signiture
  $signature = hash_hmac('sha256',$string_to_sign,$signingKey);
  //
  //
  // CREATE URL
  // ---
  $url_request_body =
  '?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential='.$publickey.$rawslash.
  $date.$rawslash.$region.$rawslash.'s3'.$rawslash.'aws4_request&X-Amz-Date='.$date.'T'.$time.'Z'.
  '&X-Amz-SignedHeaders=host&X-Amz-Expires='.$timeout;
  //
  $url = 'https://'.$host.'/'.$encoded_uri.$url_request_body.'&X-Amz-Signature='.$signature;
  //
  return (string) $url;
  //
 }
//
// ----
// end of file
//
