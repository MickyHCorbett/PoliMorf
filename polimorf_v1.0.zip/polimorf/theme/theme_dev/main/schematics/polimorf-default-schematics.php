<?php
// default schematics for header, main (post) and footer
// also includes basic html calls
class pmschematics {
//
const PM_HEADER_SCHEMATIC = '
%%NAV::
mlk={href="SITE_HOME" name="Home" src="IMAGES/home_icon.png"}:
searchbar={}:';
const PM_HEADER_MENU_SCHEMATIC_HTML = '
%%NAV::<br/>
wpmenu={}:<br/>
searchbar={}:';
//
const PM_POST_SCHEMATIC = '
///HEADER:
%%DEFAULT::
///MAIN:
%%CONTENT_META::
%%CONTENT_DEFAULT::
%%PAGINATION::
%%COMMENTS::
///FOOTER:
%%DEFAULT::
';
const PM_POST_SCHEMATIC_HTML = '
///HEADER:<br/>
%%DEFAULT::<br/>
///MAIN:<br/>
%%CONTENT_META::<br/>
%%CONTENT_DEFAULT::<br/>
%%PAGINATION::<br/>
%%COMMENTS::<br/>
///FOOTER:<br/>
%%DEFAULT::
';
const PM_PAGE_SCHEMATIC = '
///HEADER:
%%DEFAULT::
///MAIN:
%%CONTENT_META::
%%CONTENT_DEFAULT::
%%COMMENTS::
///FOOTER:
%%DEFAULT::
';
const PM_PAGE_SCHEMATIC_HTML = '
///HEADER:<br/>
%%DEFAULT::<br/>
///MAIN:<br/>
%%CONTENT_META::<br/>
%%CONTENT_DEFAULT::<br/>
%%COMMENTS::<br/>
///FOOTER:<br/>
%%DEFAULT::
';
const PM_FOOTER_SCHEMATIC = '
%%MENU::
mlk={href="SITE_HOME" name="Home" src="IMAGES/home_icon.png" class="home-ref"}:
%%SEARCHBAR::
';
const PM_FOOTER_WIDGET_SCHEMATIC_HTML = '
%%WIDGETS::
';
//
const PM_AWS_ERROR_START = '%%CONTENT:: TEXT=[ [p]';
const PM_AWS_ERROR_END = '[/p] ]:';
//
const PM_CLOUD_PRIVATE_KEY_SUB = '&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;'; // 10 bullets
const PM_THEME_ROOT = '/theme/theme_dev/main';
const PM_DEFAULT_THUMBNAIL_IMAGE_LINK = '/images/Polimorf-shapes-background.jpg';
const PM_SEARCH_ICON_LINK = '/images/search-icon-small.png';
const PM_COMMENT_ICON = '<i class="fa fa-comments" aria-hidden="true"></i>';
const PM_CATEGORY_ICON = '<i class="fa fa-list" aria-hidden="true"></i>';
const PM_TAG_ICON = '<i class="fa fa-tags" aria-hidden="true"></i>';
//
// CLASS IDENTIFIERS
// -------------
const PM_MAIN_POST_LIST_OPEN = 'MAIN_POST_LIST_OPEN';
const PM_MAIN_POST_LIST_INDEX_OPEN = 'MAIN_POST_LIST_INDEX_OPEN';
const PM_MAIN_POST_LIST_CLOSE = 'MAIN_POST_LIST_CLOSE';
const PM_FOOTER_DIVS_OPEN = 'FOOTER_DIVS_OPEN';
const PM_FOOTER_DIVS_BODY_HTML_CLOSE = 'FOOTER_DIVS_BODY_HTML_CLOSE';
//
// HTML
// -------------
const PM_DEFAULT_MENU_LINK_COLOR = "#000000";
const PM_EXCERPT_LENGTH = 30;
const PM_ALL_CLEAR = '<div class="aclear clearfix"></div>';
const PM_ALL_CLEAR_SPAN = '<span class="aclear"></span>';
const PM_10PX_SPACER = '<div class="pm-10px-spacer clearfix"></div>';
const PM_20PX_SPACER = '<div class="pm-20px-spacer clearfix"></div>';
const PM_50PX_SPACER = '<div class="pm-50px-spacer clearfix"></div>';
const PM_NAV_SPACER = '<div id="pm-nav-spacer">&nbsp;</div>'; // nav menu is fixed
//
const PM_PAGINATION_FORMAT_NEXT_LINK = '<span class="post-link-text"><i class="fa fa-arrow-right" aria-hidden="true"></i>&nbsp;&nbsp;%link</span></div>';
const PM_PAGINATION_FORMAT_PREV_LINK = '<span class="post-link-text"><i class="fa fa-arrow-left" aria-hidden="true"></i>&nbsp;&nbsp;%link</span></div>';
const PM_PAGINATION_NEXT_ICON = '<i class="fa fa-arrow-right" aria-hidden="true"></i>';
const PM_PAGINATION_PREV_ICON = '<i class="fa fa-arrow-left" aria-hidden="true"></i>';
//
const PM_HEADER_WRAP_OPEN = '<div id="header-fixed">'."\r\n";
const PM_HEADER_WRAP_CLOSE = '</div><!-- end of #header-fixed -->'."\r\n";
const PM_HEADER_OUTER_OPEN = '<div class="header-outer clearfix-small';
const PM_HEADER_OUTER_CLOSE = '</div><!-- end of .header-outer -->'."\r\n";
const PM_HEADER_INNER_OPEN = '<div class="header-inner clearfix-small';
const PM_HEADER_INNER_CLOSE = '</div><!-- end of .header-inner -->'."\r\n";
const PM_MAIN_WRAP_OPEN = '<div id="main-wrap">'."\r\n";
const PM_MAIN_WRAP_CLOSE = '</div><!-- end of main-wrap -->'."\r\n";
//
const PM_MAIN_OUTER_OPEN = '<div class="main-outer clearfix-small';
const PM_MAIN_OUTER_CLOSE = '</div><!-- end of .main-outer -->'."\r\n";
const PM_MAIN_INNER_OPEN = '<div class="main-inner clearfix-small';
const PM_MAIN_INNER_CLOSE = '</div><!-- end of .main-inner -->'."\r\n";
const PM_MAIN_DIVS_OPEN = '<div class="main-outer clearfix-small"><div class="main-inner">'."\r\n";
const PM_MAIN_DIVS_CLOSE = '</div></div><!-- end of .main-inner and .main-outer -->'."\r\n";
//
const PM_FOOTER_WRAP_OPEN = '<div id="footer-wrap">'."\r\n";
const PM_FOOTER_WRAP_CLOSE = '</div><!-- end of footer-wrap -->'."\r\n";
const PM_FOOTER_OUTER_OPEN = '<div class="footer-outer clearfix-small';
const PM_FOOTER_OUTER_CLOSE = '</div><!-- end of .footer-outer -->'."\r\n";
const PM_FOOTER_INNER_OPEN = '<div class="footer-inner clearfix-small';
const PM_FOOTER_INNER_CLOSE = '</div><!-- end of .footer-inner -->'."\r\n";
const PM_FOOTER_DIVS_CLOSE = '</div></div><!-- end of .footer-inner and .footer-outer -->'."\r\n";
//
const PM_MAIN_WITH_SIDEBAR_MAIN_OPEN = '<div class="pm-main-with-sidebar-main clearfix-small">'."\r\n";
const PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE = '</div><!-- end of .pm-main-with-sidebar-main" -->'."\r\n";
const PM_MAIN_WITH_SIDEBAR_SIDEBAR_OPEN = '<div class="pm-main-with-sidebar-sidebar clearfix-small">'."\r\n";
const PM_MAIN_WITH_SIDEBAR_SIDEBAR_CLOSE = '</div><!-- end of .pm-main-with-sidebar-sidebar" -->'."\r\n";
// =======
const PM_POST_LIST_OPEN = '<div class="pm-post-list clearfix-small">'."\r\n";
const PM_POST_LIST_CUSTOM_OPEN = '<div class="pm-post-list-custom clearfix-small';
const PM_POST_LIST_CLOSE = '</div><!-- end of .pm-post-list -->'."\r\n";
//
const PM_AUTHOR_POST_LIST_CLASS = 'pm-author';
const PM_ARCHIVE_POST_LIST_CLASS = 'pm-archive';
const PM_CATEGORY_POST_LIST_CLASS = 'pm-category';
const PM_TAG_POST_LIST_CLASS = 'pm-tag';
//
const PM_META_OPEN = '<div class="pm-post-meta clearfix-small';
const PM_META_CLOSE = '</div><!-- end of .pm-post-meta -->'."\r\n";
const PM_POST_TITLE_OPEN = '<div class="pm-post-title">'."\r\n";
const PM_POST_TITLE_CLOSE = '</div><!-- end of .pm-post-title -->'."\r\n";
const PM_POST_AUTHOR_DATE_META_OPEN = '<div class="pm-author-date-meta">'."\r\n";
const PM_POST_AUTHOR_DATE_META_CLOSE = '</div><!-- end of .pm-author-date-meta -->'."\r\n";
const PM_POST_CATEGORY_META_OPEN = '<div class="pm-category-meta">'."\r\n";
const PM_POST_CATEGORY_META_CLOSE = '</div><!-- end of .pm-category-meta -->'."\r\n";
const PM_POST_TAG_META_OPEN = '<div class="pm-tag-meta">'."\r\n";
const PM_POST_TAG_META_CLOSE = '</div><!-- end of .pm-tag-meta -->'."\r\n";
//
const PM_PAGE_NAV_OPEN = '<div class="page-nav">'."\r\n";
const PM_PAGE_NAV_CLOSE = '</div><!-- end of .page-nav-->'."\r\n";
//
const PM_NEXTPAGE_NAV_OPEN = '<div class="page-nav nextpage">'."\r\n";
const PM_NEXTPAGE_NAV_CLOSE = '</div><!-- end of .page-nav .nextpage -->'."\r\n";
//
const PM_POST_NAV_OPEN = '<div id="post-nav">'."\r\n";
const PM_POST_NAV_CLOSE = '</div><!-- end of #post-nav-->'."\r\n";
//
const PM_WIDGET_DIV_OPEN = '<div class="pm-after-content-widget-area clearfix-small';
const PM_WIDGET_DIV_CLOSE = '</div><!-- end of widget area -->'."\r\n";
const PM_WIDGET_DIV_N_BOX_OPEN = '<div class="pm-after-content-widget-area widget-n-box clearfix-small';
const PM_WIDGET_DIV_N_BOX_CLOSE = '</div><!-- end of widget area -->'."\r\n";
const PM_FOOTER_WIDGET_DIV_OPEN = '<div class="pm-footer-widget-area clearfix-small';
const PM_FOOTER_WIDGET_DIV_CLOSE = '</div><!-- end of widget area -->'."\r\n";
//
const PM_POST_OPEN = '<div class="post';
const PM_POST_OPEN_ONLY = '<div class="post">'."\r\n";
const PM_POST_CLOSE = '</div><!-- end of .post -->'."\r\n";
//
const PM_QUOTE_OPEN = '<div class="post pm-quote clearfix-small';
const PM_QUOTE_CLOSE = '</div><!-- end of .pm-quote -->'."\r\n";
const PM_QUOTATION_MARKS = '<span class="pm-quotation-marks"><i class="fa fa-quote-left fa-3x fa-pull-left" aria-hidden="true"></i></span>'."\r\n";
const PM_QUOTE_REF_OPEN = '<span class="pm-quote-ref">'."\r\n";
const PM_QUOTE_REF_CLOSE = '</span><!-- end of .pm-quote-ref -->'."\r\n";
//
const PM_FA_ICON_OPEN = '<i class="';
const PM_FA_ICON_CLOSE = '" aria-hidden="true"></i>'."\r\n";
//
const PM_GENERAL_CONTENT_WRAP_OPEN = '<div class="post pm-general-content clearfix-small';
const PM_GENERAL_CONTENT_WRAP_CLOSE = '</div><!-- end of .pm-general-content -->'."\r\n";
//
const PM_SIDEBAR_CONTENT_OPEN = '<div class="pm-sidebar-content clearfix-small';
const PM_SIDEBAR_CONTENT_CLOSE = '</div><!-- end of .pm-sidebar-content -->'."\r\n";
//
const PM_AFTER_POST_OPEN = '<div class="post clearfix">'."\r\n";
const PM_AFTER_POST_CLOSE = '</div><!-- end of .post with clearfix -->'."\r\n";
//
const PM_COMMENT_INFO_OPEN = '<div class="pm-comment-info clearfix-small">'."\r\n";
const PM_COMMENT_INFO_CLOSE = '</div><!-- end of .pm-comment-info -->'."\r\n";
//
const PM_CLOSE_DIV_WITH_COMMAS = '">'."\r\n"; // for adding classes to first div
//
const PM_CLOSE_BODY_TAG = '</body>'."\r\n";
const PM_CLOSE_HTML_TAG = '</html>'."\r\n";
const PM_LINE_BR = '<br/>';
//
// -------------
// NAV MENU html defaults
// -------------
const PM_NAV_OPEN = '<div class="pm-nav clearfix-small';
const PM_NAV_CLOSE = '</div><!-- end of .pm-nav -->'."\r\n";
const PM_GENERAL_MENU_OPEN = '<div class="pm-general-menu clearfix-small';
const PM_GENERAL_MENU_CLOSE = '</div><!-- end of .pm-general-menu -->'."\r\n";
const PM_NAV_MENU_CLASS = 'pm-nav-menu clearfix-small'; // used for wordpress menus
const PM_NAV_MENU_CLASS_WITH_LOGO = 'pm-nav-menu nav-with-logo clearfix-small'; // used for wordpress menus with logo
const PM_NAV_MENU_OPEN = '<div class="pm-nav-menu clearfix-small"><ul>'."\r\n";
const PM_NAV_MENU_OPEN_WITH_LOGO = '<div class="pm-nav-menu nav-with-logo clearfix-small"><ul>'."\r\n";
const PM_NAV_MENU_CLOSE = '</ul></div><!-- end of NAV menu -->'."\r\n";
const PM_NAV_RESP_ICON_OPEN = '<div class="pm-responsive-icon"><div class="pm-resp-icon">'."\r\n";
const PM_NAV_MENU_SEARCH_OPEN = '<div class="pm-nav-menu-search clearfix-small">'."\r\n";
const PM_NAV_MENU_SEARCH_WITH_LOGO_OPEN = '<div class="pm-nav-menu-search with-logo clearfix-small">'."\r\n";
const PM_NAV_MENU_SEARCH_CLOSE = '</div><!-- end of .pm-nav-menu-search -->'."\r\n";
const PM_NAV_SEARCHBAR_OPEN = '<div id="pm-nav-searchbar" class="clearfix-small">'."\r\n";
const PM_NAV_SEARCHBAR_CLOSE = '</div><!-- end of #pm-nav-searchbar-->'."\r\n";
const PM_SEARCHBAR_OPEN = '<div id="pm-searchbar-general" class="clearfix-small">'."\r\n";
const PM_SEARCHBAR_CLOSE = '</div><!-- end of #pm-searchbar-general -->'."\r\n";
const PM_NAV_MENU_LINK_HTML_1 = '<a href="';
const PM_NAV_MENU_LINK_HTML_2 = '" name="';
const PM_NAV_MENU_LINK_HTML_3 = '">';
const PM_NAV_MENU_LINK_HTML_4 = '</a></li>'."\r\n";
const PM_NAV_MENU_IMG_LINK_HTML_1 = '<img src="';
const PM_NAV_MENU_IMG_LINK_HTML_2 = '" alt="';
const PM_NAV_MENU_IMG_LINK_HTML_3 = '" />'."\r\n";
const PM_NAV_LOGO_DIV_OPEN = '<div class="pm-nav-logo">'."\r\n";
const PM_NAV_LOGO_DIV_CLOSE = '</div><!-- end of logo -->'."\r\n";
//
// N BOX (TWO, THREE, FOUR) html defaults
// ---------------
const PM_N_BOX_OPEN = '<div class="pm-n-box clearfix-small';
const PM_N_BOX_CLOSE = '</div><!-- end of .pm-n-box -->'."\r\n";
//
const PM_N_BOX_BOX_OPEN = '<div class="clearfix-small pm-n-box-box pm-box-';
//
const PM_BOX_BOX_CLOSE = '</div><!-- end of .pm-n-box-box -->'."\r\n";
//
// TITLE
// -----
const PM_TITLE_NAV_DIV_OPEN = '<div class="pm-title-nav">'."\r\n";
const PM_TITLE_NAV_DIV_CLOSE = '</div><!-- end of .pm-title-nav -->'."\r\n";
//
const PM_TITLE_LIST_DIV_OPEN = '<div class="pm-title-list">'."\r\n";
const PM_TITLE_LIST_DIV_CLOSE = '</div><!-- end of .pm-title-list -->'."\r\n";
//
// SECTION add class
const PM_ADD_SECTION_CLASS = ' class="pm-section';
//
// CALENDAR WRAP for ARCHIVE PAGE
const PM_CALENDAR_WRAP_FOR_ARCHIVE_OPEN = '<div class="pm-archive-calendar clearfix-small">'."\r\n";
const PM_CALENDAR_WRAP_FOR_ARCHIVE_CLOSE = '</div><!-- end of .pm-archive-calendar -->'."\r\n";
//
// =====
// EFFECTS
// -----
const PM_SCROLL_REVEAL_SOURCE_INCLUDE = '<script src="https://unpkg.com/scrollreveal/dist/scrollreveal.min.js"></script>'."\r\n";
//
// HIDE AND DISPLAY IMAGES
const PM_HIDE_IMAGES = '<style>body img { visibility: hidden };</style>';
const PM_DISPLAY_IMAGES = '<style>body img { visibility: visible };</style>';
//
//
// ===============
// end of class
}
//
$GLOBALS['$PM_CUSTOMIZER_FORMAT_SECTIONS'] = array(
  'header' =>
    array(
      'section' => 'pm_theme_header_format',
      'title' => $GLOBALS['PM_CUSTOMIZER_HEADER_FORMAT'],
      'desc' => $GLOBALS['PM_CUSTOMIZER_HEADER_FORMAT_DESCRIPTION'] . '<br/><br/>' .
      constant('pmschematics::PM_HEADER_MENU_SCHEMATIC_HTML'),
      'option' => 'polimorf_styling_options[header_format]',
      'textarea' => 'pm_header_format_textarea',
      'label' => $GLOBALS['PM_STYLING_HEADER_FORMAT'],
    ),
  'before' =>
    array(
      'section' => 'pm_theme_before_format',
      'title' => $GLOBALS['PM_CUSTOMIZER_BEFORE_FORMAT'],
      'desc' => $GLOBALS['PM_CUSTOMIZER_BEFORE_FORMAT_DESCRIPTION'],
      'option' => 'polimorf_styling_options[before_main_format]',
      'textarea' => 'pm_before_format_textarea',
      'label' => $GLOBALS['PM_STYLING_BEFORE_MAIN_FORMAT'],
    ),
  'post' =>
    array(
      'section' => 'pm_theme_post_format',
      'title' => $GLOBALS['PM_CUSTOMIZER_POST_FORMAT'],
      'desc' => $GLOBALS['PM_CUSTOMIZER_POST_FORMAT_DESCRIPTION'] . '<br/><br/>' .
      constant('pmschematics::PM_POST_SCHEMATIC_HTML'),
      'option' => 'polimorf_styling_options[post_format]',
      'textarea' => 'pm_post_format_textarea',
      'label' => $GLOBALS['PM_STYLING_POST_FORMAT'],
    ),
  'page' =>
    array(
      'section' => 'pm_theme_page_format',
      'title' => $GLOBALS['PM_CUSTOMIZER_PAGE_FORMAT'],
      'desc' => $GLOBALS['PM_CUSTOMIZER_PAGE_FORMAT_DESCRIPTION'] . '<br/><br/>' .
      constant('pmschematics::PM_PAGE_SCHEMATIC_HTML'),
      'option' => 'polimorf_styling_options[page_format]',
      'textarea' => 'pm_page_format_textarea',
      'label' => $GLOBALS['PM_STYLING_PAGE_FORMAT'],
    ),
  'sidebar' =>
    array(
      'section' => 'pm_theme_sidebar_format',
      'title' => $GLOBALS['PM_CUSTOMIZER_SIDEBAR_FORMAT'],
      'desc' => $GLOBALS['PM_CUSTOMIZER_SIDEBAR_FORMAT_DESCRIPTION'],
      'option' => 'polimorf_styling_options[sidebar_format]',
      'textarea' => 'pm_sidebar_format_textarea',
      'label' => $GLOBALS['PM_STYLING_SIDEBAR_FORMAT'],
    ),
  'after' =>
    array(
      'section' => 'pm_theme_after_format',
      'title' => $GLOBALS['PM_CUSTOMIZER_AFTER_FORMAT'],
      'desc' => $GLOBALS['PM_CUSTOMIZER_AFTER_FORMAT_DESCRIPTION'],
      'option' => 'polimorf_styling_options[after_main_format]',
      'textarea' => 'pm_after_format_textarea',
      'label' => $GLOBALS['PM_STYLING_AFTER_MAIN_FORMAT'],
    ),
  'footer' =>
  array(
    'section' => 'pm_theme_footer_format',
    'title' => $GLOBALS['PM_CUSTOMIZER_FOOTER_FORMAT'],
    'desc' => $GLOBALS['PM_CUSTOMIZER_FOOTER_FORMAT_DESCRIPTION'] . '<br/><br/>' .
    constant('pmschematics::PM_FOOTER_WIDGET_SCHEMATIC_HTML'),
    'option' => 'polimorf_styling_options[footer_format]',
    'textarea' => 'pm_footer_format_textarea',
    'label' => $GLOBALS['PM_STYLING_FOOTER_FORMAT'],
  ),
);
//
$GLOBALS['LINK_PAGE_PAGINATION_DEFAULTS'] = array(
  'before'           => constant('pmschematics::PM_NEXTPAGE_NAV_OPEN'),
  'after'            => constant('pmschematics::PM_NEXTPAGE_NAV_CLOSE'),
  'link_before'      => '<span class="page-numbers">',
  'link_after'       => '</span>',
  'next_or_number'   => 'next',
  'separator'        => ' ',
  'nextpagelink'     => constant('pmschematics::PM_PAGINATION_NEXT_ICON'),
  'previouspagelink' => constant('pmschematics::PM_PAGINATION_PREV_ICON'),
  'pagelink'         => '%',
  'echo'             => 1,
);
//
