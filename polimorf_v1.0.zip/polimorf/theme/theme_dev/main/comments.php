<?php
// IMPORTANT - DO NOT DELETE
	if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ($GLOBALS['PM_DIE_LOAD']);
	if (post_password_required() ) { ?>
		<p class="nocomments"><?php echo esc_attr($GLOBALS['PM_COMMENTS_PASSWORD_PROTECTED']);?>.</p>
	<?php
		return;
	}
	// call post
	global $post;
	//
	//  comment intro and social buttons
	?>
			<div class="comments-box clearfix">
			<?php // show social sharing buttons at bottom of post
				?>
				<div id="comments" class="clearfix-small">
				<?php
				// show only if there are comments or they are open
				if (comments_open() && ($post->comment_count > 0) ) {
					echo constant('pmschematics::PM_COMMENT_INFO_OPEN');
					echo '<a href="#comments">' . constant('pmschematics::PM_COMMENT_ICON') . '</a>';
					echo '<span class="pm-comment-count">&nbsp;'. $post->comment_count . '</span>';
					echo constant('pmschematics::PM_COMMENT_INFO_CLOSE');
				}
		// this bit will show if comments are open
		if (comments_open() )
		{
		// set fields for form
		$commenter = wp_get_current_commenter();
		//
		$def_fields = array(
			'author' =>
				'<p><input id="author" class="text_input" type="text" aria-required="true" tabindex="1" value="' . esc_attr( $commenter['comment_author'] )  . '" name="author">
				<label for="author">&nbsp;' . esc_attr($GLOBALS['PM_NAME']) .
				'<span class="required" title="Required">*</span></label></p>',
			'email' =>
				'<p><input id="email" class="text_input" type="text" aria-required="true" tabindex="2" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" name="email">
				<label for="email">&nbsp;' . esc_attr($GLOBALS['PM_EMAIL']) .
				'<span class="required" title="Required">*</span></label></p>',
			'url' =>
				'<p><input id="url" class="text_input" type="text" tabindex="3" value="' . esc_attr( $commenter['comment_author_url'] ) . '" name="url">
				<label for="url">&nbsp' . esc_attr($GLOBALS['PM_WEBSITE']) . '</label></p>'
		);
		$comment_field =
		'<p class="comment_box">
		<textarea id="comment" rows="8" tabindex="4" name="comment"></textarea>
		</p>';
		//
		$args = array(
			'id_form'           => 'commentform!',
			'class_submit'      => 'commentsubmit',
			'name_submit'       => 'commentsubmit',
			'title_reply'       => '',
			'cancel_reply_link' => esc_attr($GLOBALS['PM_CANCEL_REPLY']),
			'label_submit'      => esc_attr($GLOBALS['PM_POST_COMMENT']),
			'format'            => 'xhtml',
			'fields' => apply_filters( 'comment_form_default_fields', $def_fields ),
			'comment_field' =>  $comment_field
		);
		//
		?>
				<div id="respond-outer" class="clearfix-small">
					<h2><?php echo esc_attr($GLOBALS['PM_LEAVE_COMMENT']); ?></h2>
					<?php
					//
					comment_form($args, $post->ID);
					//
					?>
				</div>
		<?php
		} else {
		?>
					<!--    <h3>Comments are now closed.</h3>  -->
		<?php
		}
		// show comments regardless of if they are closed
		if ( $post->comment_count > 0 )
		{
			$max_comments_per_page = get_option('comments_per_page');
			$comment_args = array(
				'avatar_size' => 48,
				'type' => 'comment'
			);
		//
		?>
				<ol class="commentlist">
					<?php wp_list_comments($comment_args); ?>
				</ol>
		<?php
				echo constant('pmschematics::PM_PAGE_NAV_OPEN');
				paginate_comments_links( array(
					'prev_text' => constant('pmschematics::PM_COMMENT_ICON') . ' ' . constant('pmschematics::PM_PAGINATION_PREV_ICON'),
					'next_text' => constant('pmschematics::PM_PAGINATION_NEXT_ICON') . ' ' . constant('pmschematics::PM_COMMENT_ICON')
				) );
				echo constant('pmschematics::PM_PAGE_NAV_CLOSE');
		}
echo '</div><!-- end of comments -->';
echo '</div><!-- end of comments box -->';
//
