<?php
// customizer functions
/**
 * Adds the individual sections, settings, and controls to the theme customizer
 */
function pm_customizer( $wp_customize ) {
	 /**
	  * Adds textarea support to the theme customizer
	  */
	class Polimorf_Customize_Textarea_Control extends WP_Customize_Control {
		public $type = 'textarea';
		public function render_content() {
			// adds in text box with a 20px top padding
			?>
				<div style="height: 20px;"></div>
				<label>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<textarea rows="15" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
				</label>
			<?php
		}
	}
	//
	class Polimorf_Customize_Textarea_Control_Long extends WP_Customize_Control {
		public $type = 'textarea';
		public function render_content() {
			// adds in text box with a 20px top padding
			?>
				<div style="height: 20px;"></div>
				<label>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<textarea rows="30" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
				</label>
			<?php
		}
	}
	// STYLING
	// =======
 $wp_customize->add_section(
      'pm_theme_styling_settings',
      array(
          'title' => $GLOBALS['PM_CUSTOMIZER_STYLING_SETTINGS'],
          'description' => $GLOBALS['PM_CUSTOMIZER_STYLING_SETTINGS_DESCRIPTION'],
          'priority' => 35,
      )
  );
//
	// Define sections to be added
	$schematic_tabs = $GLOBALS['$PM_CUSTOMIZER_FORMAT_SECTIONS'];
//
// add sections
	foreach($schematic_tabs as $key => $val) {
	// ======
	$priority = 35 + array_search($key, array_keys($schematic_tabs));
	//
	$section_name = $schematic_tabs[$key]['section'];
	$title_ref = $schematic_tabs[$key]['title'];
	$title_ref_desc = $schematic_tabs[$key]['desc'];
	$option_name = $schematic_tabs[$key]['option'];
	$textarea_name = $schematic_tabs[$key]['textarea'];
	$label = $schematic_tabs[$key]['label'];
	//
		$wp_customize->add_section(
				$section_name,
				array(
						'title' => $title_ref,
						'description' => $title_ref_desc,
						'priority' => $priority
				)
		);
		//
		$wp_customize->add_setting(
			$option_name,
			array(
				'default' => '',
				'type' => 'option',
				'capability' => 'edit_theme_options',
				'transport' => 'refresh',
				'sanitize_callback' => 'pm_customizer_sanitize_style_textarea'
			)
		);
		$wp_customize->add_control(
			new Polimorf_Customize_Textarea_Control_Long(
					$wp_customize,
					$textarea_name,
					array(
				'type' => 'textarea',
				'label' => $label,
				'section' => $section_name,
				'settings' => $option_name,
				'priority' => 1
				)
			)
		);
	//
	}
//
//
// --
}
//
//
add_action( 'customize_register', 'pm_customizer' );
// sanitize functions - if used
function pm_customizer_sanitize_checkbox( $input ) {
    if ( $input == 1 ) {
        return 1;
    } else {
        return '';
    }
}
function pm_customizer_sanitize_style_textarea( $input ) {
	$allowed_html = array();
	return wp_kses( $input,$allowed_html );
}
