<?php
add_action( 'add_meta_boxes', 'pm_custom_meta_add' );
function pm_custom_meta_add()
{
    // add a meta box for each of the wordpress page types: posts and pages
    foreach (array('post','page') as $type)
    {
        $description = $GLOBALS['PM_META_TITLE_CUSTOM_POST'];
        if ($type == 'page') {
          $description = $GLOBALS['PM_META_TITLE_CUSTOM_PAGE'];
        }
        add_meta_box( 'pm-custom-meta-adder', $description, 'pm_custom_meta_box', $type, 'normal', 'high' );
    }
}
function pm_custom_meta_box()
{
    // $post is already set, and contains an object: the WordPress post
    global $post;
    $main_img = get_post_meta($post->ID, '_pm_main_img_meta', TRUE);
    $inpage_format = get_post_meta($post->ID,'_pm_inpage_format', TRUE);
    // We'll use this nonce field later on when saving.
    wp_nonce_field( 'pm_custom_meta_add_nonce', 'meta_box_nonce' );
	//
	//
    ?>
	<div id="meta-container-meta">
	<p class="input-header">&nbsp;</p>
  <p><?php echo esc_attr($GLOBALS['PM_META_IMAGE_THUMB_DESCRIPTION']); ?></p>
  <p class="input-container">
  <label for="_pm_main_img_meta" id="input-container-label"><?php echo esc_attr($GLOBALS['PM_META_MAIN_IMAGE']); ?></label>
  <input type="text" name="_pm_main_img_meta" id="pm-main-img-id" value="<?php echo esc_attr( $main_img );  ?>" />
  </p>
  <!-- ***************** -->
  <p class="input-header">&nbsp;</p>
	<p><?php echo esc_attr($GLOBALS['PM_META_INPAGE_FORMAT_DESCRIPTION']); ?></p>
  <p><?php if ( $post->post_type == 'page' ) {
    echo esc_attr($GLOBALS['PM_PAGE_SCHEMATIC_HTML']);
  } else {
    echo esc_attr($GLOBALS['PM_POST_SCHEMATIC_HTML']);
  } ?></p>
  <p class="input-container">
  <label for="_pm_inpage_format" id="input-container-label"><?php echo esc_attr($GLOBALS['PM_META_INPAGE_FORMAT']); ?></label>
  <textarea class='textarea' name='_pm_inpage_format' id='pm-textarea-fields' type='text'><?php echo $inpage_format ; ?></textarea>
  </p>
  <!-- ***************** -->
	</div>
  <?php
}
add_action( 'save_post', 'pm_custom_meta_add_save' );
function pm_custom_meta_add_save( $post_id )
{
    // Bail if we're doing an auto save
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    // if our nonce isn't there, or we can't verify it, bail
    if( !isset( $_POST['meta_box_nonce'] ) || !wp_verify_nonce( $_POST['meta_box_nonce'], 'pm_custom_meta_add_nonce' ) ) return;
    // if our current user can't edit this post, bail
    if ($_POST['post_type'] == 'page')
    {
        if (!current_user_can('edit_page', $post_id)) return $post_id;
    }
    else
    {
        if (!current_user_can('edit_post', $post_id)) return $post_id;
    }
    // Save data
   if( isset( $_POST['_pm_main_img_meta'] ) )
     update_post_meta( $post_id, '_pm_main_img_meta', esc_attr( strip_tags( $_POST['_pm_main_img_meta'] ) ) );
   // allowed for text area
   $allowed_format = array();
   if (isset( $_POST['_pm_inpage_format'] ) )
     update_post_meta( $post_id, '_pm_inpage_format', wp_kses_data($_POST['_pm_inpage_format'], $allowed_format ) ) ;
   //
}
// end of the custom meta data box
