( function( $ ) {
			//
			// *******************************************
			// ** MANUAL STYLING **
			// *******************************************
			// add manual styling
			wp.customize('polimorf_styling_options[manual_styling]',function( value ) {
          value.bind(function( manualStyle) {
					//
					$('style').filter('#manualstyling').html('<!-- ' + manualStyle + '-->');
					});
      });
			// add manual styling resp
			wp.customize('polimorf_styling_options[manual_styling_resp]',function( value ) {
					value.bind(function( manualStyleResp) {
					//
					$('style').filter('#manualstylingresp').html('<!-- ' + manualStyleResp + '-->');
					});
			});
//
} )( jQuery );
