( function( $ ) {
// when responsive icon is clicked - show menu
var currWidth;
    //
  $( '.pm-responsive-icon' ).on('click' ,function () {
      $( '.pm-nav-menu-search' ).slideToggle();
  });
  // show non responsive menu when window has resized above 850px and hide
  // otherwise
  //
  $( window ).resize(function() {
    currWidth = $( window ).width();
    if ( currWidth > 850 ) {
      $( '.pm-nav-menu-search' ).css('display','block');
    } else {
      $( '.pm-nav-menu-search' ).css('display','none');
    }
  });
//
} )( jQuery );
