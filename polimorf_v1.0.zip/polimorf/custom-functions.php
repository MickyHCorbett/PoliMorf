<?php
// ----------------
// CUSTOM FUNCTIONS
// ----------------
// See PoliMorf_User_Guide.
// Define any GLOBALS here as well
// --------------------------------
// DISCLAIMER: The theme author (Micky H Corbett) and any associated entities are not responsible
// for functions that you produce that may cause erroneous or dangerous behaviour to your
// website. Please code using standard WordPress practices e.g. sanitize data going into the
// database and escape/limit its use when printing to screen.
//
