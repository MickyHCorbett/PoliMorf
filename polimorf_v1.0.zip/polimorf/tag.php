<?php  
polimorf_tag_template();
?>
