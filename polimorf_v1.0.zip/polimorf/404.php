<?php
polimorf_404_template();
