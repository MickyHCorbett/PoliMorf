<?php
//
// ----- LANGUAGE CONSTANTS FILE -------------
//
//
// GLOBALS
//
// ------------
// ------------
// GENERIC
// ------------
$GLOBALS['PM_COMMENT_MODERATION'] = __( 'Your comment is awaiting moderation.' , 'polimorf' );
$GLOBALS['PM_TRACKBACK_MODERATION'] = __( 'Your trackback is awaiting moderation.' , 'polimorf' );
$GLOBALS['PM_REPLY'] = __( 'Reply' , 'polimorf' );
$GLOBALS['PM_LOGIN_REPLY'] = __( 'Log in to reply' , 'polimorf' );
$GLOBALS['PM_POSTED_BY'] = __( 'Posted by ' , 'polimorf' );
$GLOBALS['PM_POSTED_IN'] = __( 'Posted in ' , 'polimorf' );
$GLOBALS['PM_COMMENTS '] = __( 'Comments' , 'polimorf' );
$GLOBALS['PM_404_NOT_FOUND'] = __( 'Not found' , 'polimorf' );
$GLOBALS['PM_404_APOLOGIES'] = __( 'Apologies, but we were unable to find what you were looking for. Perhaps searching will help.' , 'polimorf' );
$GLOBALS['PM_DAILY_ARCHIVES'] = __( 'Daily Archives' , 'polimorf' );
$GLOBALS['PM_MONTHLY_ARCHIVES'] = __( 'Monthly Archives' , 'polimorf' );
$GLOBALS['PM_YEARLY_ARCHIVES'] = __( 'Yearly Archives' , 'polimorf' );
$GLOBALS['PM_BLOG_ARCHIVES'] = __( 'Blog Archives' , 'polimorf' );
$GLOBALS['PM_NOTHING_HERE'] = __( 'Nothing found here' , 'polimorf' );
$GLOBALS['PM_NOTHING_FOUND'] = __( 'Nothing found' , 'polimorf' );
$GLOBALS['PM_SORRY_LOOKING_FOR'] = __( 'Sorry, but what you are looking for is not here.' , 'polimorf' );
$GLOBALS['PM_SORRY_SEARCH'] = __( 'Sorry, but nothing matched your search criteria. Please try again with some different keywords.' , 'polimorf' );
$GLOBALS['PM_BACK_TO_HOME'] = __( 'Back to the home page' , 'polimorf' );
$GLOBALS['PM_POSTS_FOR'] = __( 'Posts for' , 'polimorf' );
$GLOBALS['PM_AUTHOR_ARCHIVES'] = __( 'Author Archives' , 'polimorf' );
$GLOBALS['PM_TAG_ARCHIVES'] = __( 'Tag Archives' , 'polimorf' );
$GLOBALS['PM_DIE_LOAD'] = __( 'Please do not load this page directly. Thanks!' , 'polimorf' );
$GLOBALS['PM_LEAVE_COMMENT'] = __( 'Leave a comment' , 'polimorf' );
$GLOBALS['PM_POST_COMMENT'] = __( 'Post comment' , 'polimorf' );
$GLOBALS['PM_NAME'] = __( 'Name' , 'polimorf' );
$GLOBALS['PM_EMAIL'] = __( 'Email' , 'polimorf' );
$GLOBALS['PM_WEBSITE'] = __( 'Website' , 'polimorf' );
$GLOBALS['PM_OLDER_COMMENTS'] = __( 'Older comments' , 'polimorf' );
$GLOBALS['PM_NEWER_COMMENTS'] = __( 'Newer comments' , 'polimorf' );
$GLOBALS['PM_CANCEL_REPLY'] = __( 'Cancel Reply' , 'polimorf' );
$GLOBALS['PM_COMMENTS_PASSWORD_PROTECTED'] = __( 'This post is password protected. Enter the password to view comments.' , 'polimorf' );
$GLOBALS['PM_THEME'] = __( 'Theme' , 'polimorf' );
$GLOBALS['PM_POWERED_BY'] = __( 'Powered by' , 'polimorf' );
$GLOBALS['PM_SEARCH_RESULTS'] = __( 'Search results for' , 'polimorf' );
$GLOBALS['PM_ALL_RIGHTS_RESERVED'] = __( 'All rights reserved' , 'polimorf' );
//
// ------------
// POLIMORF
//
// Main names
$GLOBALS['PM_THEME_NAME'] = __( 'PoliMorf' , 'polimorf' );
$GLOBALS['PM_WORDPRESS'] = __( 'WordPress' , 'polimorf' );
$GLOBALS['PM_WIDGET_AREA_ROOT'] = __( 'Widget Area' , 'polimorf' );
$GLOBALS['PM_ADDED_MENU'] = __( 'Default Menu' , 'polimorf' );
// -------------------------
// -------------------------
// SETTINGS PAGE - TITLES AND OTHER
//
$GLOBALS['PM_POLIMORF_PAGE_SETTINGS_TITLE'] = __( 'PoliMorf Settings' , 'polimorf' );
//
$GLOBALS['PM_POLIMORF_PAGE_SETTINGS_SIGNUP_OPTIONS'] = __( 'Signup' , 'polimorf' );
$GLOBALS['PM_POLIMORF_PAGE_SETTINGS_SIGNUP_OPTIONS_SLUG'] = __( 'signup_options' , 'polimorf' );
$GLOBALS['PM_POLIMORF_PAGE_SETTINGS_CLOUD_OPTIONS'] = __( 'Cloud' , 'polimorf' );
$GLOBALS['PM_POLIMORF_PAGE_SETTINGS_CLOUD_OPTIONS_SLUG'] = __( 'cloud_options' , 'polimorf' );
$GLOBALS['PM_POLIMORF_PAGE_SETTINGS_STYLING_OPTIONS'] = __( 'Styling' , 'polimorf' );
$GLOBALS['PM_POLIMORF_PAGE_SETTINGS_STYLING_OPTIONS_SLUG'] = __( 'styling_options' , 'polimorf' );
$GLOBALS['PM_POLIMORF_PAGE_SETTINGS_INFO_OPTIONS'] = __( 'Info' , 'polimorf' );
$GLOBALS['PM_POLIMORF_PAGE_SETTINGS_INFO_OPTIONS_SLUG'] = __( 'info_options' , 'polimorf' );
//
// Styling settings
//
$GLOBALS['PM_STYLING_HEADER_FORMAT'] = __( 'Header Format' , 'polimorf' );
$GLOBALS['PM_STYLING_HEADER_FORMAT_DESCRIPTION'] = __( 'Enter a header format schematic.' , 'polimorf' );
$GLOBALS['PM_STYLING_FOOTER_FORMAT'] = __( 'Footer Format' , 'polimorf' );
$GLOBALS['PM_STYLING_FOOTER_FORMAT_DESCRIPTION'] = __( 'Enter a footer format schematic.' , 'polimorf' );
$GLOBALS['PM_STYLING_BEFORE_MAIN_FORMAT'] = __( 'Before Main Schematic' , 'polimorf' );
$GLOBALS['PM_STYLING_BEFORE_MAIN_FORMAT_DESCRIPTION'] = __( 'Enter a schematic for the content you want before a post list (e.g. blog) or if you are using a sidebar.' , 'polimorf' );
$GLOBALS['PM_STYLING_AFTER_MAIN_FORMAT'] = __( 'After Main Schematic' , 'polimorf' );
$GLOBALS['PM_STYLING_AFTER_MAIN_FORMAT_DESCRIPTION'] = __( 'Enter a schematic for the content you want after a post list (e.g. blog) or if you are using a sidebar.' , 'polimorf' );
$GLOBALS['PM_STYLING_POST_FORMAT'] = __( 'Post Format' , 'polimorf' );
$GLOBALS['PM_STYLING_POST_FORMAT_DESCRIPTION'] = __( 'Enter a format schematic for how you want a blog post to look.' , 'polimorf' );
$GLOBALS['PM_STYLING_PAGE_FORMAT'] = __( 'Page Format' , 'polimorf' );
$GLOBALS['PM_STYLING_PAGE_FORMAT_DESCRIPTION'] = __( 'Enter a format schematic for how you want a page to look.' , 'polimorf' );
$GLOBALS['PM_STYLING_SIDEBAR_FORMAT'] = __( 'Sidebar Format' , 'polimorf' );
$GLOBALS['PM_STYLING_SIDEBAR_FORMAT_DESCRIPTION'] = __( 'Enter a format schematic here if you wish to have a sidebar on all pages and posts unless otherwise specified with an inpage schematic.' , 'polimorf' );
//
// Cloud Settings
//
$GLOBALS['PM_CLOUD_DESCRIPTION'] = __( 'Add your public and private keys for your cloud account here. Currently PoliMorf is compatible with Amazon AWS.' , 'polimorf' );
$GLOBALS['PM_CLOUD_PUBLIC_KEY'] = __( 'Public Key' , 'polimorf' );
$GLOBALS['PM_CLOUD_PUBLIC_KEY_DESCRIPTION'] = __( '' , 'polimorf' );
$GLOBALS['PM_CLOUD_PRIVATE_KEY'] = __( 'Private Key' , 'polimorf' );
$GLOBALS['PM_CLOUD_PRIVATE_KEY_DESCRIPTION'] = __( 'This will automatically hide itself.' , 'polimorf' );
//
// Info settings tab
//
$GLOBALS['PM_HOW_TO_USE'] = __( 'How to use PoliMorf' , 'polimorf' );
$GLOBALS['PM_INFO_PARAGRAPH_1'] = __( 'The key elements to Polimorf are that it allows you to fully control how each post and page look by using a format schematic language. It also allows you to store this schematic in the cloud so that you reduce your database footprint on your hosting service.' , 'polimorf' );
$GLOBALS['PM_INFO_PARAGRAPH_2'] = __( 'The best description of how to use the theme can be found here' , 'polimorf' );
$GLOBALS['PM_INFO_PARAGRAPH_3'] = __( 'Note: the theme is still compatible with standard WordPress plugins and functionality.' , 'polimorf' );
// //
// -----------
// META FIELDS
// -----------
//
$GLOBALS['PM_META_TITLE_CUSTOM_POST'] = __( 'Custom Post Settings' , 'polimorf' );
$GLOBALS['PM_META_TITLE_CUSTOM_PAGE'] = __( 'Custom Page Settings' , 'polimorf' );
//
$GLOBALS['PM_META_IMAGE_THUMB_DESCRIPTION'] = __( 'Enter an alternative Featured Image url to be used when this entry is listed. You can also enter a schematic command to create link to an image stored on the cloud.' , 'polimorf' );
$GLOBALS['PM_META_MAIN_IMAGE'] = __( 'Alternative Featured Image Url' , 'polimorf' );
$GLOBALS['PM_META_INPAGE_FORMAT_DESCRIPTION'] = __( 'Enter a different format schematic if needed. You can copy the default format below as a starting point.' , 'polimorf' );
$GLOBALS['PM_META_INPAGE_FORMAT'] = __( 'Format Schematic' , 'polimorf' );
//
// -------------------
//
// Customizer settings
//
$GLOBALS['PM_CUSTOMIZER_HEADER_FORMAT'] = __( 'Header Format' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_HEADER_FORMAT_DESCRIPTION'] = __( 'Add some schematic formating for the header. To quickly use WordPress Menus, try the following schematic:' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_BEFORE_FORMAT'] = __( 'Before Content Format' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_BEFORE_FORMAT_DESCRIPTION'] = __( 'Add some schematic formating for before the main content.' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_POST_FORMAT'] = __( 'Post Format' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_POST_FORMAT_DESCRIPTION'] = __( 'Add some schematic formating for the main post content.' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_PAGE_FORMAT'] = __( 'Page Format' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_PAGE_FORMAT_DESCRIPTION'] = __( 'Add some schematic formating for the main page content.' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_SIDEBAR_FORMAT'] = __( 'Sidebar Format' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_SIDEBAR_FORMAT_DESCRIPTION'] = __( 'Add some schematic formating for the sidebar.' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_AFTER_FORMAT'] = __( 'After Content Format' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_AFTER_FORMAT_DESCRIPTION'] = __( 'Add some schematic formating for after the main content.' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_FOOTER_FORMAT'] = __( 'Footer Format' , 'polimorf' );
$GLOBALS['PM_CUSTOMIZER_FOOTER_FORMAT_DESCRIPTION'] = __( 'Add some schematic formating for the footer. To quickly use WordPress widgets, try the following schematic:' , 'polimorf' );
//
