<?php
polimorf_page_template();
?>
