<?php
polimorf_attachment_template();
