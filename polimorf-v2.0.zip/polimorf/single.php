<?php
polimorf_single_template();
?>
