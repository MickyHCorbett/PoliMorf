<?php
// FUNCTIONS CALL
//
// !important! -- do not modify this file
// If you wish to add functions add them to the custom_functions file
//
//
// Get language constants
get_template_part('languages/polimorf-language-constants');
// load pcom and polimorf functions
get_template_part('theme/theme_dev/main/functions/polimorf-load-functions');
// call core functions
get_template_part('theme/theme_dev/main/core-functions');
// load custom functions
get_template_part('custom-functions');
// load globals and syntax
get_template_part('theme/theme_dev/main/functions/pcom/pcom-globals');
//
