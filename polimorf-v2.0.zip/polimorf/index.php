<?php
/*
Index page
*/
polimorf_index_template();
//
