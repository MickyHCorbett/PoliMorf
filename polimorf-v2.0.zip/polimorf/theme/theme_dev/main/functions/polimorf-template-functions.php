<?php
// Template Functions
// ---
// Collective functions for templates
// =======
// HEADER MAIN FUNCTIONS
// ======
/**
 * Adds header data including schematic parser
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_header_main()
 {
	//
	// add social scripts
	// polimorf_social_media_prescripts();
	echo constant('pmschematics::PM_HEADER_WRAP_OPEN');
	//
	// reset search header
	if (is_search()) {
		$styling_options = get_option('polimorf_styling_options');
		$GLOBALS['header_schematic'] = $styling_options['header_format'];
	}
	polimorf_header_schematic_parser();
	//
	echo constant('pmschematics::PM_HEADER_WRAP_CLOSE');
	//
 }
//
// =======
// FOOTER
// =======
/**
 * Adds footer data including schematic parser
 * Reapplies search check as format can be overwritten
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_footer_main()
 {
	//
	echo constant('pmschematics::PM_FOOTER_WRAP_OPEN');
	//
	// reset search footer
	if (is_search()) {
		$styling_options = get_option('polimorf_styling_options');
		$GLOBALS['footer_schematic'] = $styling_options['footer_format'];
	}
	polimorf_footer_schematic_parser();
	//
	echo constant('pmschematics::PM_FOOTER_WRAP_CLOSE');
	wp_footer();
	//
 }
// =======
// ARCHIVE
// =======
/**
 * Archive template for daily, monthly and yearly archives
 * GLOBAL query_active is set to prevent post meta being read
 * in the loop
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_archive_template()
 {
	// prevent reading formats of posts/pages in loop
	$GLOBALS['query_active'] = 1;
	//
	$styling_options = get_option('polimorf_styling_options');
	$sidebar_schematic = $styling_options['sidebar_format'];
	$before_schematic = $styling_options['before_main_format'];
	$after_schematic = $styling_options['after_main_format'];
	//
	$sidebar_found = false;
	if ( !empty( trim($sidebar_schematic) ) ) $sidebar_found = true;
	//
	get_header();
	polimorf_header_main();
	//
	polimorf_open_main_wrap();
	polimorf_process_schematic($before_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
	polimorf_open_main_inner_outer();
	//
	if ($sidebar_found == true) {
		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
	}
	echo constant('pmschematics::PM_POST_LIST_OPEN');
	//
		if (have_posts()) {
			the_post();
	//
			polimorf_insert_archive_title();
	//
			polimorf_present_posts(null);
	//
	} else {
		polimorf_nothing_found_here();
	}
	//
	polimorf_get_calendar_for_archive();
	//
	echo constant('pmschematics::PM_POST_LIST_CLOSE');
	if ($sidebar_found == true) {
		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE');
	}
	// process sidebar
	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_OPEN');
	polimorf_process_schematic($sidebar_schematic,constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT'));
	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_CLOSE');
	//
	polimorf_close_main_inner_outer();
	polimorf_process_schematic($after_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
	polimorf_close_main_wrap();
	get_footer();
	// reset query active flag
	$GLOBALS['query_active'] = 0;
	//
 }
// ==============
// ATTACHMENT
// ==============
/**
 * Displays attachments in posts
 * GLOBAL query_active is set to prevent post meta being read
 * in the loop
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_attachment_template()
 {
	// prevent reading formats of posts/pages in loop
	$GLOBALS['query_active'] = 1;
	//
	$styling_options = get_option('polimorf_styling_options');
	$sidebar_schematic = $styling_options['sidebar_format'];
	$before_schematic = $styling_options['before_main_format'];
	$after_schematic = $styling_options['after_main_format'];
	//
	$sidebar_found = false;
	if ( !empty( trim($sidebar_schematic) ) ) $sidebar_found = true;
	//
	get_header();
	polimorf_header_main();
	//
	polimorf_open_main_wrap();
	polimorf_process_schematic($before_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
	polimorf_open_main_inner_outer();
	//
	if ($sidebar_found == true) {
		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
	}
	echo constant('pmschematics::PM_POST_LIST_OPEN');
	//
	the_post();
	//
	polimorf_display_attachment();
	//
	echo constant('pmschematics::PM_POST_LIST_CLOSE');
	if ($sidebar_found == true) {
		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE');
	}
	// process sidebar
	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_OPEN');
	polimorf_process_schematic($sidebar_schematic,constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT'));
	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_CLOSE');
	//
	polimorf_close_main_inner_outer();
	polimorf_process_schematic($after_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
	polimorf_close_main_wrap();
	get_footer();
	// reset query active flag
	$GLOBALS['query_active'] = 0;
	//
 }
// ==============
// AUTHOR
// ==============
// ==============
// ATTACHMENT
// ==============
/**
 * Displays posts by author
 * GLOBAL query_active is set to prevent post meta being read
 * in the loop
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_author_template()
 {
	//
	// prevent reading formats of posts/pages in loop
	$GLOBALS['query_active'] = 1;
	//
	$styling_options = get_option('polimorf_styling_options');
	$sidebar_schematic = $styling_options['sidebar_format'];
	$before_schematic = $styling_options['before_main_format'];
	$after_schematic = $styling_options['after_main_format'];
	//
	$sidebar_found = false;
	if ( !empty( trim($sidebar_schematic) ) ) $sidebar_found = true;
	//
	get_header();
	polimorf_header_main();
	//
	polimorf_open_main_wrap();
	polimorf_process_schematic($before_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
	polimorf_open_main_inner_outer();
	//
	if ($sidebar_found == true) {
		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
	}
	echo constant('pmschematics::PM_POST_LIST_OPEN');
	//
		if (have_posts()) {
			the_post();
			//
			polimorf_insert_author_archive_meta();
			//
			polimorf_present_posts(null);
			// if no posts do the next thing
		} else {
			polimorf_nothing_found_here();
		}
	//
	echo constant('pmschematics::PM_POST_LIST_CLOSE');
	if ($sidebar_found == true) {
		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE');
	}
	// process sidebar
	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_OPEN');
	polimorf_process_schematic($sidebar_schematic,constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT'));
	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_CLOSE');
	//
	polimorf_close_main_inner_outer();
	polimorf_process_schematic($after_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
	polimorf_close_main_wrap();
	get_footer();
	// reset query active flag
	$GLOBALS['query_active'] = 0;
	//
 }
// ===============
// CATEGORY
// ===============
/**
 * Displays posts by category
 * GLOBAL query_active is set to prevent post meta being read
 * in the loop
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_category_template()
 {
	//
	// prevent reading formats of posts/pages in loop
	$GLOBALS['query_active'] = 1;
	//
	$styling_options = get_option('polimorf_styling_options');
	$sidebar_schematic = $styling_options['sidebar_format'];
	$before_schematic = $styling_options['before_main_format'];
	$after_schematic = $styling_options['after_main_format'];
	//
	$sidebar_found = false;
	if ( !empty( trim($sidebar_schematic) ) ) $sidebar_found = true;
	//
	get_header();
	polimorf_header_main();
	//
	polimorf_open_main_wrap();
	polimorf_process_schematic($before_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
	polimorf_open_main_inner_outer();
	//
	if ($sidebar_found == true) {
		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
	}
	echo constant('pmschematics::PM_POST_LIST_OPEN');
	//
		if (have_posts()) {
			the_post();
	//
			polimorf_insert_category_title();
	//
			polimorf_present_posts(null);
			// if no posts do the next thing
		} else {
			polimorf_nothing_found_here();
		}
	//
	echo constant('pmschematics::PM_POST_LIST_CLOSE');
	if ($sidebar_found == true) {
		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE');
	}
	//
	// process sidebar
	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_OPEN');
	polimorf_process_schematic($sidebar_schematic,constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT'));
	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_CLOSE');
	//
	polimorf_close_main_inner_outer();
	polimorf_process_schematic($after_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
	polimorf_close_main_wrap();
	get_footer();
	// reset query active flag
	$GLOBALS['query_active'] = 0;
	//
 }
// ===============
// INDEX
// ===============
/**
 * The main blog roll
 * GLOBAL query_active is set to prevent post meta being read
 * in the loop
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_index_template(){
	//
	// prevent reading formats of posts/pages in loop
	$GLOBALS['query_active'] = 1;
	//
	$styling_options = get_option('polimorf_styling_options');
	$sidebar_schematic = $styling_options['sidebar_format'];
	$before_schematic = $styling_options['before_main_format'];
	$after_schematic = $styling_options['after_main_format'];
	$sidebar_found = false;
	if ( !empty( trim($sidebar_schematic) ) ) $sidebar_found = true;
	//
	get_header();
	polimorf_header_main();
	//
	polimorf_open_main_wrap();
	polimorf_process_schematic($before_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
	polimorf_open_main_inner_outer();
	//
	if ($sidebar_found == true) {
		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
	}
	echo constant('pmschematics::PM_POST_LIST_OPEN');
		//
		if (have_posts()) {
			the_post();
			//
			polimorf_present_posts('index');
			// if no posts do the next thing
		} else {
			polimorf_nothing_found_here();
		}
		//
	echo constant('pmschematics::PM_POST_LIST_CLOSE');
	if ($sidebar_found == true) {
		echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE');
	}
	//
	// process sidebar
	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_OPEN');
	polimorf_process_schematic($sidebar_schematic,constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT'));
	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_CLOSE');
	//
	polimorf_close_main_inner_outer();
	polimorf_process_schematic($after_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
	polimorf_close_main_wrap();
	get_footer();
	// reset query active flag
	$GLOBALS['query_active'] = 0;
	//
 }
// ===============
// PAGE
// ===============
/**
 * Page template
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_page_template()
 {
  //
  get_header();
  polimorf_header_main();
  //
  polimorf_open_main_wrap();
  polimorf_before_main_schematic_parser();
  //
  //
  if (have_posts()) :
        the_post();
        // add article tags for reader
  			?><article><?php
  			polimorf_main_schematic_parser();
  			?></article><?php
        //
        else :
        polimorf_nothing_found_here();
      endif;
  //
  //
  polimorf_after_main_schematic_parser();
  polimorf_close_main_wrap();
  get_footer();
  //
 }
//
// ===============
// SEARCH
// ===============
/**
 * Search template
 * GLOBAL query_active is set to prevent post meta being read
 * in the loop
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_search_template()
 {
  // testing has found that schematic elements need to be reasserted for full
  // format to be recognised
  //
  // prevent reading formats of posts/pages in loop
  $GLOBALS['query_active'] = 1;
  //
  $styling_options = get_option('polimorf_styling_options');
  $sidebar_schematic = $styling_options['sidebar_format'];
  $before_schematic = $styling_options['before_main_format'];
  $after_schematic = $styling_options['after_main_format'];
  //
  $sidebar_found = false;
  if ( !empty( trim($sidebar_schematic) ) ) $sidebar_found = true;
  //
  get_header();
  polimorf_header_main();
  //
  polimorf_open_main_wrap();
  polimorf_process_schematic($before_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
  polimorf_open_main_inner_outer();
  //
  if ($sidebar_found == true) {
  	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
  }
  echo constant('pmschematics::PM_POST_LIST_OPEN');
  //
  polimorf_search_query();
  //
  echo constant('pmschematics::PM_POST_LIST_CLOSE');
  if ($sidebar_found == true) {
  	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE');
  }
  // process sidebar
  echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_OPEN');
  polimorf_process_schematic($sidebar_schematic,constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT'));
  echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_CLOSE');
  //
  polimorf_close_main_inner_outer();
  polimorf_process_schematic($after_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
  polimorf_close_main_wrap();
  get_footer();
  // reset query active flag
  $GLOBALS['query_active'] = 0;
  //
 }
// ===============
// SINGLE
// ===============
/**
 * Post template
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_single_template()
 {
  //
  get_header();
  polimorf_header_main();
  //
  polimorf_open_main_wrap();
  polimorf_before_main_schematic_parser();
  //
  //
  	if (have_posts()) {
  		while (have_posts()) {
  			the_post();
  			//
  			?><article><?php
  			polimorf_main_schematic_parser();
  			?></article><?php
  			//
  		}
  //
  	} else {
  			polimorf_nothing_found_here();
  	}
  //
  polimorf_after_main_schematic_parser();
  polimorf_close_main_wrap();
  get_footer();
  //
 }
// ===============
// TAG
// ===============
/**
 * Displays posts by tag
 * GLOBAL query_active is set to prevent post meta being read
 * in the loop
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_tag_template()
 {
  //
  // prevent reading formats of posts/pages in loop
  $GLOBALS['query_active'] = 1;
  //
  $styling_options = get_option('polimorf_styling_options');
  $sidebar_schematic = $styling_options['sidebar_format'];
  $before_schematic = $styling_options['before_main_format'];
  $after_schematic = $styling_options['after_main_format'];
  //
  $sidebar_found = false;
  if ( !empty( trim($sidebar_schematic) ) ) $sidebar_found = true;
  //
  get_header();
  polimorf_header_main();
  //
  polimorf_open_main_wrap();
  polimorf_process_schematic($before_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
  polimorf_open_main_inner_outer();
  //
  if ($sidebar_found == true) {
  	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
  }
  echo constant('pmschematics::PM_POST_LIST_OPEN');
  //
  	if (have_posts()) {
  		the_post();
  		//
  		polimorf_insert_tag_title();
  		//
  		polimorf_present_posts(null);
  		// if no posts do the next thing
  	} else {
  		polimorf_nothing_found_here();
  	}
  //
  echo constant('pmschematics::PM_POST_LIST_CLOSE');
  if ($sidebar_found == true) {
  	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE');
  }
  // process sidebar
  echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_OPEN');
  polimorf_process_schematic($sidebar_schematic,constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT'));
  echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_CLOSE');
  //
  polimorf_close_main_inner_outer();
  polimorf_process_schematic($after_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
  polimorf_close_main_wrap();
  get_footer();
  // reset query active flag
  $GLOBALS['query_active'] = 0;
  //
 }
//
// ===============
// 404
// ===============
/**
 * Displays 404 page
 * GLOBAL query_active is set to prevent post meta being read
 * in the loop
 *
 * @param none
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_404_template()
 {
  //
  // prevent reading formats of posts/pages in loop
  $GLOBALS['query_active'] = 1;
  //
  $styling_options = get_option('polimorf_styling_options');
  $sidebar_schematic = $styling_options['sidebar_format'];
  $before_schematic = $styling_options['before_main_format'];
  $after_schematic = $styling_options['after_main_format'];
  //
  $sidebar_found = false;
  if ( !empty( trim($sidebar_schematic) ) ) $sidebar_found = true;
  //
  get_header();
  polimorf_header_main();
  //
  polimorf_open_main_wrap();
  polimorf_process_schematic($before_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
  polimorf_open_main_inner_outer();
  //
  if ($sidebar_found == true) {
  	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_OPEN');
  }
  echo constant('pmschematics::PM_POST_LIST_OPEN');
  //
  polimorf_404_message();
  //
  echo constant('pmschematics::PM_POST_LIST_CLOSE');
  if ($sidebar_found == true) {
  	echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_MAIN_CLOSE');
  }
  // process sidebar
  echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_OPEN');
  polimorf_process_schematic($sidebar_schematic,constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT'));
  echo constant('pmschematics::PM_MAIN_WITH_SIDEBAR_SIDEBAR_CLOSE');
  //
  polimorf_close_main_inner_outer();
  polimorf_process_schematic($after_schematic,constant('pcom_commands::PCOM_MAIN_PLACEMENT'));
  polimorf_close_main_wrap();
  get_footer();
  // reset query active flag
  $GLOBALS['query_active'] = 0;
 }
// ----
// end of file
