<?php
//
//
// ============
// PLACEMENT CLASSES
// ============
/**
 * Outputs wrapper divs with custom class included
 * Outputs to screen
 *
 * @param string $custom_class
 * @param string $placement - section identifier
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_open_placement_class($custom_class,$placement)
 {
  //
    switch($placement) {
  //
    case constant('pcom_commands::PCOM_HEADER_PLACEMENT') :
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_HEADER_OUTER_OPEN'));
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_HEADER_INNER_OPEN'));
    break;
  //
    case constant('pcom_commands::PCOM_MAIN_PLACEMENT') :
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_MAIN_OUTER_OPEN'));
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_MAIN_INNER_OPEN'));
    break;
  //
    case constant('pcom_commands::PCOM_FOOTER_PLACEMENT') :
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_FOOTER_OUTER_OPEN'));
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_FOOTER_INNER_OPEN'));
    break;
  //
    }
  //
 }
//
//
//
//
/**
 * Outputs closed wrapper divs
 * Outputs to screen
 *
 * @param string $placement - section identifier
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_close_placement_class($placement)
 {
  //
    switch($placement) {
  //
    case constant('pcom_commands::PCOM_HEADER_PLACEMENT') :
      echo constant('pmschematics::PM_HEADER_INNER_CLOSE');
      echo constant('pmschematics::PM_HEADER_OUTER_CLOSE');
    break;
  //
    case constant('pcom_commands::PCOM_MAIN_PLACEMENT') :
      echo constant('pmschematics::PM_MAIN_INNER_CLOSE');
      echo constant('pmschematics::PM_MAIN_OUTER_CLOSE');
    break;
  //
    case constant('pcom_commands::PCOM_FOOTER_PLACEMENT') :
      echo constant('pmschematics::PM_FOOTER_INNER_CLOSE');
      echo constant('pmschematics::PM_FOOTER_OUTER_CLOSE');
    break;
  //
    }
  //
 }
//
/**
 * Outputs wrapper divs with custom class included
 * Returns as html
 *
 * @param string $custom_class
 * @param string $placement - section identifier
 *
 * @return string $out - html
 *
 * @since 1.0.0
 */
 function pcom_return_open_placement_class($custom_class,$placement)
 {
  //
  $out = '';
  //
    switch($placement) {
  //
    case constant('pcom_commands::PCOM_HEADER_PLACEMENT') :
      $out = pcom_return_open_custom_class_div($custom_class,constant('pmschematics::PM_HEADER_OUTER_OPEN')) .
      pcom_return_open_custom_class_div($custom_class,constant('pmschematics::PM_HEADER_INNER_OPEN'));
    break;
  //
    case constant('pcom_commands::PCOM_MAIN_PLACEMENT') :
      $out = pcom_return_open_custom_class_div($custom_class,constant('pmschematics::PM_MAIN_OUTER_OPEN')) .
      pcom_return_open_custom_class_div($custom_class,constant('pmschematics::PM_MAIN_INNER_OPEN'));
    break;
  //
    case constant('pcom_commands::PCOM_FOOTER_PLACEMENT') :
      $out = pcom_return_open_custom_class_div($custom_class,constant('pmschematics::PM_FOOTER_OUTER_OPEN')) .
      pcom_return_open_custom_class_div($custom_class,constant('pmschematics::PM_FOOTER_INNER_OPEN'));
    break;
  //
    }
  //
  return $out;
  //
 }
//
//
//
/**
 * Outputs closed wrapper divs
 * Returns as html
 *
 * @param string $placement - section identifier
 *
 * @return string $out - html
 *
 * @since 1.0.0
 */
 function pcom_return_close_placement_class($placement)
 {
  //
  $out = '';
  //
    switch($placement) {
  //
    case constant('pcom_commands::PCOM_HEADER_PLACEMENT') :
      $out = constant('pmschematics::PM_HEADER_INNER_CLOSE') .
      constant('pmschematics::PM_HEADER_OUTER_CLOSE');
    break;
  //
    case constant('pcom_commands::PCOM_MAIN_PLACEMENT') :
      $out = constant('pmschematics::PM_MAIN_INNER_CLOSE') .
      constant('pmschematics::PM_MAIN_OUTER_CLOSE');
    break;
  //
    case constant('pcom_commands::PCOM_FOOTER_PLACEMENT') :
      $out = constant('pmschematics::PM_FOOTER_INNER_CLOSE') .
      constant('pmschematics::PM_FOOTER_OUTER_CLOSE');
    break;
  //
    }
  //
  return $out;
  //
 }
//
//
// ----- -----
// NAV command
//
/**
 * Process nav schematic command
 * Top level calling function
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_process_nav_command($syntax,$custom_class,$placement)
 {
    //
    pcom_open_placement_class($custom_class,$placement);
    //
    pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_NAV_OPEN'));
    // process commands
    pcom_process_menu_command_syntax($syntax,$placement,$GLOBALS['PM_NAV_COMMAND']);
    // close div
    echo constant('pmschematics::PM_NAV_CLOSE');
    //
    pcom_close_placement_class($placement);
    //
 }
// ----- -----
// MENU command
//
/**
 * Process menu schematic command
 * Top level calling function
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_process_menu_command($syntax,$custom_class,$placement)
 {
    //
    pcom_open_placement_class($custom_class,$placement);
    //
    pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_NAV_OPEN'));
    // process commands
    pcom_process_menu_command_syntax($syntax,$placement,$GLOBALS['PM_MENU_COMMAND']);
    // close div
    echo constant('pmschematics::PM_NAV_CLOSE');
    //
    pcom_close_placement_class($placement);
    //
 }
//
// ----- -----
// MENU command for N_BOX
/**
 * Process menu subcommand when called in n_box command
 *
 * @param string $syntax - command syntax
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_process_n_box_menu_command($syntax)
 {
    //
    pcom_open_custom_class_div(null,constant('pmschematics::PM_NAV_OPEN'));
    // process commands
    pcom_process_menu_command_syntax($syntax,'n-box',$GLOBALS['PM_MENU_COMMAND']);
    // close div
    echo constant('pmschematics::PM_NAV_CLOSE');
    //
 }
//
//
//
//
/**
 * Function processes individual commands - NAV or MENU
 * allowable keywords are:
 * mlk for a link - this is mlk={}: - with url and name
 * logo - logo={}: - for inserting a logo in the menu - url, src and name
 * searchbar={}: (brackets empty) - for inserting a search bar
 *
 * @param string $syntax - command syntax
 * @param string $placement - section identifier
 * @param string $type - either NAV or MENU
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_process_menu_command_syntax($syntax,$placement,$type)
 {
  // ---- -----
  // keywords all start with KEYWORD={
  // search for ={ in command
  //
  $first_menu_link = false;
  $no_logo = constant('pcom_commands::PCOM_NO_LOGO');
  $logo_present = false;
  $logo_html_string = $no_logo;
  $menu_html_string = "";
  $title_string = "";
  $add_wp_menu = false;
  $menu_name = null;
  $insert_searchbar = false;
  $args = array(
    'open' => constant('pcom_commands::PCOM_KEYWORD_OPEN'),
    'close' => constant('pcom_commands::PCOM_KEYWORD_CLOSE')
  );
  // placements
  $header_placement = constant('pcom_commands::PCOM_HEADER_PLACEMENT');
  $main_placement  = constant('pcom_commands::PCOM_MAIN_PLACEMENT');
  $main_sidebar_placement  = constant('pcom_commands::PCOM_MAIN_WITH_SIDEBAR_PLACEMENT');
  $footer_placement  = constant('pcom_commands::PCOM_FOOTER_PLACEMENT');
  $sidebar_placement  = constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT');
  //
  // loop over keywords
    while ( $commands['command'] != constant('pcom_commands::PCOM_NO_ENTRY')) {
    //
      $commands = pcom_process_command_open_close_syntax($syntax,$args);
      // update elements present
      switch ($commands['command']) {
        //
        case $GLOBALS['PM_NAV_MENU_LINK_KEYWORD'] :
          // check to see if first menu link
          if ($first_menu_link == false) {
            $string = pcom_process_menu_command_mlk_keyword($commands['command_syntax']);
            // latch first_menu_link
            $first_menu_link = true;
            $menu_html_string = $string;
          } else {
            $string = pcom_process_menu_command_mlk_keyword($commands['command_syntax']);
            $menu_html_string = $menu_html_string . $string;
          }
  //
        break;
  //
        //
        case $GLOBALS['PM_NAV_LOGO_KEYWORD'] :
          $logo_html_string = pcom_process_logo_for_nav($commands['command_syntax']);
        break;
        //
        case $GLOBALS['PM_TITLE_KEYWORD'] :
          $title_string = pcom_add_title($commands['command_syntax']);
        break;
        //
        case $GLOBALS['PM_NAV_SEARCHBAR_KEYWORD'] :
          $insert_searchbar = true;
        break;
        //
        case $GLOBALS['PM_WP_MENU_KEYWORD'] :
          $add_wp_menu = true;
          $menu_syntax = $commands['command_syntax'];
        break;
      }
      // update syntax
      $syntax = $commands['syntax_after'];
  //
    }
    // check strings
    //
    if ($first_menu_link == true) {
      // add open and close html to menu
      if ( $logo_html_string != $no_logo ) {
        $with_logo = constant('pmschematics::PM_NAV_MENU_OPEN_WITH_LOGO');
      } else {
        $with_logo = constant('pmschematics::PM_NAV_MENU_OPEN');
      }
      //
      $menu_html_string =  $with_logo . $menu_html_string . constant('pmschematics::PM_NAV_MENU_CLOSE');
    }
  //
  // ----------
  //
    switch ($type) {
  //
      case $GLOBALS['PM_NAV_COMMAND'] :
      //NAV - only active in the header
      //
      if ( $placement == $header_placement ) {
        // icon
        polimorf_insert_responsive_icon();
        //
        if ( $logo_html_string != $no_logo ) {
          echo $logo_html_string;
          echo constant('pmschematics::PM_NAV_MENU_SEARCH_WITH_LOGO_OPEN');
          $logo_present = true;
        } else {
          echo constant('pmschematics::PM_NAV_MENU_SEARCH_OPEN');
        }
        //
        if ($add_wp_menu == true) {
          pcom_add_wordpress_menu($menu_syntax,$logo_present);
        } else {
          echo $menu_html_string;
        }
        //
        if ( $insert_searchbar ) {
          $search_out = polimorf_nav_search_bar();
          echo $search_out;
        }
        echo constant('pmschematics::PM_NAV_MENU_SEARCH_CLOSE');

      }
  //
      break;
  //
  //  MENU - for general menus
      default :
      // if menu is not in the header
      if ( $placement != $header_placement ) {
  //
      // add extra menu wrapper for after, main, before, or footer
      // which is covered by main, main with sidebar and footer placement
        if ( ( $placement == $main_placement ) || ( $placement == $main_sidebar_placement ) ||
        ( $placement == $footer_placement ) ) {
          pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_GENERAL_MENU_OPEN'));
        } elseif ( $placement == $sidebar_placement ) {
          // add sidebar div
          pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_SIDEBAR_CONTENT_OPEN'));
        }
  //
        echo $title_string;
        //
        if ($add_wp_menu == true) {
          pcom_add_wordpress_menu($menu_syntax,$logo_present);// $logo_present default is false
        } else {
          echo $menu_html_string;
        }
  //
        if ( ( $placement == $main_placement ) || ( $placement == $main_sidebar_placement ) ||
        ( $placement == $footer_placement ) ) {
          echo constant('pmschematics::PM_GENERAL_MENU_CLOSE');
        } elseif ( $placement == $sidebar_placement )  {
          echo constant('pmschematics::PM_SIDEBAR_CONTENT_CLOSE');
        }
  //
      }
        //
      break;
  //
    }
  // -----------
 }
//
//
//
//
/**
 * Function outputs a WordPress menu to screen
 *
 * @param string $syntax - command syntax
 * @param boolean $with_logo - boolean - adds class to modify
 * menu width when a logo is present in the nav bar
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_wordpress_menu($syntax,$with_logo)
 {
  // add named wordpress menu
    $custom_keys = $GLOBALS['PM_CUSTOM_WPMENU_COMMAND_ATTRIBUTES'];
    $syntax = pcom_replace_custom_attributes($syntax,$custom_keys);
    //
    $args = $GLOBALS['PM_WPMENU_COMMAND_ATTRIBUTES'];
    $nav_class = constant('pmschematics::PM_NAV_MENU_CLASS');
    if ($with_logo == true) {
      $nav_class = constant('pmschematics::PM_NAV_MENU_CLASS_WITH_LOGO');
    }
    //
    $args = pcom_process_keyword_args($syntax,$args);
    // create custom class if present
    if ( $args['class'] != constant('pcom_commands::PCOM_NO_ENTRY') ) {
      $nav_class = $nav_class . ' ' . $args['class'];
    }
  //
    wp_nav_menu( array(
      'menu' => $args['name'],
      'container_class' => $nav_class
      ) );
 }
// ------------
//
//
/**
 * Add logo to nav
 * Accommodates for custom attributes
 *
 * @param string $syntax - command syntax
 *
 * @return string $out_html - the logo html
 *
 * @since 1.0.0
 */
 function pcom_process_logo_for_nav($syntax){
  //
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $out_html = "";
  $blogname = get_bloginfo('name');
  //
  $img_attributes = $GLOBALS['PM_LOGO_ATTRIBUTES']; // src only
  $remote_attributes = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
  //
  $custom_img_attributes = $GLOBALS['PM_CUSTOM_LOGO_ATTRIBUTES'];
  $custom_remote_attributes = $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES'];
  // replace custom keys
  $syntax = pcom_replace_custom_attributes($syntax,$custom_img_attributes);
  $syntax = pcom_replace_custom_attributes($syntax,$custom_remote_attributes);
  //
    if (!empty($syntax)) {
      // process standard src and remote attributes
      $img_attributes = pcom_process_keyword_args($syntax,$img_attributes);
      $remote_attributes = pcom_process_keyword_args($syntax,$remote_attributes);
      // process for remote attributes - if not present process shortcuts
      // url is sanitized (esc) in the function
      $src = pcom_process_remote_url_syntax($img_attributes['src'],$remote_attributes);
      // if header image is set in options use this instead
      if ( !empty(get_header_image()) ) $src = get_header_image();
      // create logo html
      if ($src != $no_entry){
        $out_html = constant('pmschematics::PM_NAV_LOGO_DIV_OPEN') .
        '<a href="' . $GLOBALS['$blog_url'] . '" name="' . $blogname . '">' .
        '<img src="' . $src . '" alt="' . $blogname . '" /></a>' .
        constant('pmschematics::PM_NAV_LOGO_DIV_CLOSE');
      }
    }
  //
  return $out_html;
  // -
 }
//
//
//
// -----------
/**
 * Creates a menu list entry for a menu
 * In the nav bar or anywhere else
 *
 * @param string $command_string - command syntax
 *
 * @return string $html_string_start . $html_string_end
 *
 * @since 1.0.0
 */
 function pcom_process_menu_command_mlk_keyword($command_string)
 {
    // menu link must have href and name otherwise return empty string
    $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
    $allowed_args = $GLOBALS['PM_MENU_COMMAND_MLK_KEYWORD_ATTRIBUTES'];
    $html_string = "";
    $src_found = false;
    $list_open_with_class = '<li>' . "\r\n";
    //
    // replace custom attributes
    $custom_keys = $GLOBALS['PM_CUSTOM_MENU_COMMAND_MLK_KEYWORD_ATTRIBUTES'];
    $command_string = pcom_replace_custom_attributes($command_string,$custom_keys);
    //
    $allowed_args = pcom_process_keyword_args($command_string,$allowed_args);
    //
    // check href and name are not NONE
    $mlk_args_valid = ( ( $allowed_args['href'] != $no_entry ) && ( $allowed_args['name'] != $no_entry ) );
    //
    if ( $mlk_args_valid == true ) {
      // process constants
      $href = pcom_site_constants_replacement($allowed_args['href']);
      // sanitize
      $href = pcom_esc_output_functions($href,'href');
      $name = pcom_esc_output_functions($allowed_args['name'],'name');
      // if src found - link is an image
      if ( $allowed_args['src'] != $no_entry ) {
        $src = pcom_site_constants_replacement($allowed_args['src']);
        $src = pcom_esc_output_functions($src,'src');
        $src_found = true;
      }
      // additional class
      if ( $allowed_args['class'] != $no_entry ) {
        $class = pcom_esc_output_functions($allowed_args['class'],'class');
        $list_open_with_class = '<li class="' . $class . '">' . "\r\n";
      }
      // Font Awesome icon - adds to or replaces image src
      if ( $allowed_args['fa'] != $no_entry ) {
        $fa = pcom_esc_output_functions($allowed_args['fa'],'fa');
        // set image src true - icon may be only image
        $src_found = true;
        // create icon - append to src
        $src = $src . constant('pmschematics::PM_FA_ICON_OPEN') . $fa .
        constant('pmschematics::PM_FA_ICON_CLOSE');
      }
      //
      $html_string_start = $list_open_with_class .
      constant('pmschematics::PM_NAV_MENU_LINK_HTML_1') .
      $href .
      constant('pmschematics::PM_NAV_MENU_LINK_HTML_2') .
      $name .
      constant('pmschematics::PM_NAV_MENU_LINK_HTML_3');
      // add img or text
      if ( $src_found == true ) {
        $html_string_end =
        constant('pmschematics::PM_NAV_MENU_IMG_LINK_HTML_1') .
        $src .
        constant('pmschematics::PM_NAV_MENU_IMG_LINK_HTML_2') .
        $name .
        constant('pmschematics::PM_NAV_MENU_IMG_LINK_HTML_3') .
        constant('pmschematics::PM_NAV_MENU_LINK_HTML_4') ;
      } else {
        $html_string_end = $name .
        constant('pmschematics::PM_NAV_MENU_LINK_HTML_4') ;
      }
    // ---
    }
    //
    return $html_string_start . $html_string_end;
 }
// END -- NAV and MENU COMMAND
// ***** *****
// ---- ------
//
// N BOX COMMANDS
//
/**
 * Top level function to add box (or grid) elements
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 * @param string $no_boxes - no of boxes (columns) in row.
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_process_n_box_command($syntax,$custom_class,$placement,$no_boxes)
 {
    // --- add starting wrap element
    $box_max = $GLOBALS['PM_MAX_NO_BOXES'];
    //
    pcom_open_placement_class($custom_class,$placement);
    //
    pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_N_BOX_OPEN'));
    // limit no of boxes
    if ($no_boxes < 2) $no_boxes = 2;
    if ($no_boxes > $box_max) $no_boxes = $box_max;
    //
    pcom_parse_box_arguments($syntax,$no_boxes,$placement);
    // close div
    echo constant('pmschematics::PM_N_BOX_CLOSE');
    //
    pcom_close_placement_class($placement);
 }
//
// --------------
// BOX PROCESSING
//
/**
 * Examine syntax string and allocate entries to each box
 *
 * @param string $syntax - command syntax
 * @param string $placement - section identifier
 * @param string $no_boxes - no of boxes (columns) in row.
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_parse_box_arguments($syntax,$no_boxes,$placement)
 {
  // only called if BOX commands exist
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $sub_schem_end = constant('pcom_commands::PCOM_SUB_SCHEMATIC_CLOSE');
  $no_boxes_int = (int) $no_boxes; // cast to integer
  //
  $i = 1;
  //
    while ($i <= $no_boxes_int) {
      // create box marker
      $class1 = $GLOBALS['PM_BOX_BOX'] . $i;
      $class2 = $GLOBALS['PM_BOX_BOX'] . ($i+1);
      $marker1 = $class1 . $sub_schem_end;
      $marker2 = $class2 . $sub_schem_end;
      //
      $split_strings1 = pcom_get_strings_syntax_separator($syntax,$marker1,true);
      if ($split_strings1['command_found'] == true) {
        //
        $split_strings2 = pcom_get_strings_syntax_separator($split_strings1['syntax_after'],$marker2,true);
        //
        if ($split_strings2['command_found'] == true) {
          // check i - if $i is $no_boxes_int then type is box box-end
          // default type is box
          // also add in box number
          if ($i == 1) {
            $type = $GLOBALS['PM_BOX_BOX'] . ' ' . strtolower($class1) . ' ' . constant('pcom_commands::PCOM_BOX_BOX_START');
          } else {
            $type = $GLOBALS['PM_BOX_BOX'] . ' ' . strtolower($class1);
          }
          //
          pcom_add_box_for_n_box($split_strings2['syntax_before'],$no_boxes,$type,$placement);
        } else {
          $last_box = $GLOBALS['PM_BOX_BOX'] . ' ' . strtolower($class1) . ' ' . constant('pcom_commands::PCOM_BOX_BOX_END');
          pcom_add_box_for_n_box($split_strings1['syntax_after'],$no_boxes,$last_box,$placement);
        }
        //
      }
      // increment i and set syntax for next pass
      $i = $i + 1;
      //
      $syntax = $marker2 . $split_strings2['syntax_after'];
      //
      //
    }
  //
  //
  // no return - end function
 }
// ==========
//
//
//
/**
 * Processes box data and outputs to screen
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $type - class of box, i.e. box-end, box-start
 * @param string $placement - section identifier
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_box_for_n_box($syntax,$no_boxes,$type,$placement)
 {
  // adds three box - depends on box type i.e. number
    $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
    //
    $open_html = constant('pmschematics::PM_N_BOX_BOX_OPEN') . trim($no_boxes);
    //
    // echo to screen
    echo $open_html . ' ' . strtolower($type) . constant('pmschematics::PM_CLOSE_DIV_WITH_COMMAS');
    //
    if ( !empty($syntax) ){
    //
      while ( $commands['command'] != $no_entry ) {
        //
        $commands = pcom_process_command_open_close_syntax($syntax,null); // default sub commands
  //
        // filter out any custom classes - these should be applied to the top level
        $command_custom = pcom_process_custom_command($commands['command']);
        //
        pcom_process_n_box_subcommands($commands['command'],$commands['command_syntax']);
        // update syntax
        $syntax = $commands['syntax_after'];
  //
      } // end of while
  //
    } // if syntax not empty
    //
    echo constant('pmschematics::PM_BOX_BOX_CLOSE');
  //
 }
//
//
// ---
/**
 * Processes box subcommands
 *
 * @param string $command - subcommand
 * @param string $syntax - command syntax
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_process_n_box_subcommands($command,$syntax)
 {
  // process subcommands for n-box formats
  if ( !empty($syntax) ) {
    //
    switch ($command) {
      //
      case $GLOBALS['PM_MENU_COMMAND'] :
        pcom_process_n_box_menu_command($syntax);
      break;
      //
      case $GLOBALS['PM_TITLE_COMMAND'] :
        $html_out = pcom_add_title($syntax);
        echo $html_out;
      break;
      //
      case $GLOBALS['PM_TEXT_COMMAND'] :
        $html_out = pcom_process_text_command($syntax);
        echo $html_out;
      break;
      //
      case $GLOBALS['PM_INSERT_SEARCHBAR_COMMAND'] :
        $html_out = polimorf_insert_searchbar();
        echo $html_out;
      break;
      //
      case $GLOBALS['PM_INSERT_WIDGET_COMMAND'] :
        pcom_insert_widgets_for_n_box($syntax);
      break;
      //
      case $GLOBALS['PM_QUOTE_COMMAND'] :
        $html_out = pcom_return_quote_box($syntax,null,constant('pcom_commands::PCOM_BOX_PLACEMENT'));
        echo $html_out;
      break;
      //
      case $GLOBALS['PM_POST_LIST_COMMAND'] :
        pcom_add_post_list($syntax,null,constant('pcom_commands::PCOM_BOX_PLACEMENT'));
      break;
      //
      default:
      // do nothing
      break;
    }
  //
  } // end if
  // ==
 }
//
// ================
// TITLE
/**
 * Processes title syntax
 *
 * @param string $syntax - command syntax
 *
 * @return string $title_string - the title html
 *
 * @since 1.0.0
 */
 function pcom_add_title($syntax)
 {
  // no attribute - text itself - trim for spaces and esc
  $syntax = trim($syntax);
  //
  $title_string = constant('pmschematics::PM_TITLE_NAV_DIV_OPEN') .
  esc_attr($syntax) . constant('pmschematics::PM_TITLE_NAV_DIV_CLOSE');
  //
  return $title_string;
 }
//
//
/**
 * Processes title syntax for a post list
 *
 * @param string $syntax - command syntax
 *
 * @return string $title_string - the title html
 *
 * @since 1.0.0
 */
 function pcom_add_list_title($syntax)
 {
  // no attribute - text itself - trim for spaces and esc
  $syntax = trim($syntax);
  //
  $title_string = constant('pmschematics::PM_TITLE_LIST_DIV_OPEN') .
  esc_attr($syntax) . constant('pmschematics::PM_TITLE_LIST_DIV_CLOSE');
  //
  return $title_string;
 }
//
// ================
//
//
//
// CONTENT DEFAULT
/**
 * Adds the default Wordpress content with extra custom
 * classes if relevant.
 * Only adds content to the main area
 *
 * @param string $syntax - command syntax - not used
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_content($syntax,$custom_class,$placement)
 {
    //called within the loop
    //syntax not used
    //
    if ( ( $placement == constant('pcom_commands::PCOM_MAIN_PLACEMENT') ) ||
    ( $placement == constant('pcom_commands::PCOM_MAIN_WITH_SIDEBAR_PLACEMENT') ) ){
      pcom_open_placement_class($custom_class,$placement);
      // use post_class, post and add extra classes
      if ($custom_class != constant('pcom_commands::PCOM_NO_ENTRY') ) {
        $custom_class = 'post ' . $custom_class;
      } else {
        $custom_class = 'post';
      }
      $classes = array( $custom_class );
      //
      ?><div <?php post_class($classes); ?>>
      <?php
      //
      the_content();
      echo constant('pmschematics::PM_POST_CLOSE');
      pcom_close_placement_class($placement);
    }
 }
//
// CONTENT - ADDED
/**
 * Adds content to any part of the site structure
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_customised_content($syntax,$custom_class,$placement)
 {
  // ALL PROCESSING except SIDEBAR
  // -----
  // placements
  // -----
  global $post;
  //
  $header_placement = constant('pcom_commands::PCOM_HEADER_PLACEMENT');
  $footer_placement = constant('pcom_commands::PCOM_FOOTER_PLACEMENT');
  $sidebar_placement = constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT');
  //
  //
    if ( ( !empty($syntax) ) && ( $placement != $sidebar_placement) ) {
  //
      $added = pcom_process_command_open_close_syntax($syntax,null); // processes text command
    //
      if ( $added['command'] == $GLOBALS['PM_TEXT_COMMAND'] ) {
  //
        $content_out = pcom_process_text_command($added['command_syntax']);
  //
        pcom_open_placement_class($custom_class,$placement);
        // add general content class for header and footer
        if ( ( $placement == $header_placement ) || ( $placement == $footer_placement ) ) {
          pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_GENERAL_CONTENT_WRAP_OPEN'));
        } else {
          // use post_class, post and add extra classes
          if ($custom_class != constant('pcom_commands::PCOM_NO_ENTRY') ) {
            $custom_class = 'post ' . $custom_class;
          } else {
            $custom_class = 'post';
          }
          $classes = array( $custom_class );
          //
          ?><div <?php post_class($classes); ?>>
          <?php
        }
        //
        echo $content_out;
        //
        if ( ( $placement == $header_placement ) || ( $placement == $footer_placement ) ) {
          echo constant('pmschematics::PM_GENERAL_CONTENT_WRAP_CLOSE');
        } else {
          echo constant('pmschematics::PM_POST_CLOSE');
        }
        pcom_close_placement_class($placement);
      }
    //
    }
    // SIDEBAR PROCESSING
    //
    if ( ( $placement == $sidebar_placement ) && !empty($syntax) ) {
  //
      $added = pcom_process_command_open_close_syntax($syntax,null); // processes text command
    //
      if ( $added['command'] == $GLOBALS['PM_TEXT_COMMAND'] ) {
  //
        $content_out = pcom_process_text_command($added['command_syntax']);
  //
        pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_SIDEBAR_CONTENT_OPEN'));
        //
        echo $content_out;
        //
        echo constant('pmschematics::PM_SIDEBAR_CONTENT_CLOSE');
      }
    //
    }
 }
//
// CONTENT META DEFAULT
/**
 * Adds content meta (title, author etc) to post or page
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_content_meta($syntax,$custom_class,$placement)
 {
    //called within the loop
    //
    $title = $GLOBALS['PM_CONTENT_META_TITLE_KEYWORD'];
    $author = $GLOBALS['PM_CONTENT_META_AUTHOR_KEYWORD'];
    $date = $GLOBALS['PM_CONTENT_META_DATE_KEYWORD'];
    $cat = $GLOBALS['PM_CONTENT_META_CATEGORY_KEYWORD'];
    $tag = $GLOBALS['PM_CONTENT_META_TAG_KEYWORD'];
    // set up default keyword settings
    $args_display = $GLOBALS['PM_CONTENT_META_DISPLAY_DEFAULTS'];
    //
    global $post;
    if ( ( $placement == constant('pcom_commands::PCOM_MAIN_PLACEMENT') ) ||
    ( $placement == constant('pcom_commands::PCOM_MAIN_WITH_SIDEBAR_PLACEMENT') ) ) {
      // process syntax
      $args_display = pcom_process_content_meta_syntax($syntax,$args_display);
      //
      pcom_open_placement_class($custom_class,$placement);
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_META_OPEN'));
      //
      polimorf_post_title_insert($post,$args_display[$title]);
      polimorf_post_author_date_insert($args_display[$author],$args_display[$date]);
      if ( is_single() ) {
        polimorf_post_category_insert($args_display[$cat]);
        polimorf_post_tag_insert($post,$args_display[$tag]);
      }
      //
      echo constant('pmschematics::PM_META_CLOSE');
      pcom_close_placement_class($placement);
    }
 }
//
//
//
//
/**
 * Processes content meta (title, author etc)
 *
 * @param string $syntax - command syntax
 * @param array - $args_display -
 * booleans for each element: title, author, date, category and tag
 *
 * @return array - $args_display
 *
 * @since 1.0.0
 */
 function pcom_process_content_meta_syntax($syntax,$args_display)
 {
  // uses $args_display array from pcom_add_content_meta
  $args =  array(
    'open' => constant('pcom_commands::PCOM_KEYWORD_OPEN'),
    'close' => constant('pcom_commands::PCOM_KEYWORD_CLOSE')
  );
  //
  $title = $GLOBALS['PM_CONTENT_META_TITLE_KEYWORD'];
  $author = $GLOBALS['PM_CONTENT_META_AUTHOR_KEYWORD'];
  $date = $GLOBALS['PM_CONTENT_META_DATE_KEYWORD'];
  $cat = $GLOBALS['PM_CONTENT_META_CATEGORY_KEYWORD'];
  $tag = $GLOBALS['PM_CONTENT_META_TAG_KEYWORD'];
  //
  if ( !empty(trim($syntax)) ) {
  // set all $args_display to false
  $args_display = $GLOBALS['PM_CONTENT_META_DISPLAY_FALSE'];
  // --
    while ($command['syntax_after'] != constant('pcom_commands::PCOM_NO_ENTRY')) {
      $command = pcom_process_command_open_close_syntax($syntax,$args);
      //
      switch ($command['command']) {
      //
      case $title :
        $args_display[$title] = true;
      break;
      //
      case $author :
        $args_display[$author] = true;
      break;
      //
      case $date :
        $args_display[$date] = true;
      break;
      //
      case $cat :
        $args_display[$cat] = true;
      break;
      //
      case $tag :
        $args_display[$tag] = true;
      break;
      //
      }
  //
    $syntax = $command['syntax_after'];
    }
  //
  }
  // return $args_display
  return $args_display;
 }
// ===============
//
/**
 * REPLACE INSERT [[]] commands in content with schematic elements
 * e.g. useful when putting text in between videos, audio, or forms
 *
 * Processes content inserts and feeds them to a global
 * A content filter registers this and adds them to content which is then
 * displayed once the_content() is called
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_process_content_with_inserts($syntax,$custom_class,$placement)
 {
    //called within the loop
    global $post;
    // process content
    $GLOBALS['content_with_inserts'] = pcom_process_content_inserts($syntax);
    $GLOBALS['content_insert'] = true;
    //
    if ( ( $placement == constant('pcom_commands::PCOM_MAIN_PLACEMENT') ) ||
    ( $placement == constant('pcom_commands::PCOM_MAIN_WITH_SIDEBAR_PLACEMENT') )
    && !empty($syntax) ) {
      pcom_open_placement_class($custom_class,$placement);
      // use post_class, post and add extra classes
      if ($custom_class != constant('pcom_commands::PCOM_NO_ENTRY') ) {
        $custom_class = 'post ' . $custom_class;
      } else {
        $custom_class = 'post';
      }
      $classes = array( $custom_class );
      //
      ?><div <?php post_class($classes); ?>>
      <?php
      //
      the_content();
              //
      echo constant('pmschematics::PM_POST_CLOSE');
      pcom_close_placement_class($placement);
    }
 }
//
//
// filter content where appropriate
add_filter('the_content','pcom_content_insert_filter');
//
/**
 * Filter the content with inserts
 *
 * @param string $content
 *
 * @return string $content
 *
 * @since 1.0.0
 */
 function pcom_content_insert_filter($content){
    //
    $insert_content = $GLOBALS['content_with_inserts'];
    //
    if ( in_the_loop() && ( $GLOBALS['content_insert'] == true ) ) {
      // replace inserts with schematic data
      $content = str_replace(array_keys($insert_content), $insert_content, $content);
      //
      $GLOBALS['content_insert'] == false;
    }
    //
  return $content;
  //
 }
//
//
// *********
//
// POST LIST
// ---------
/**
 * Using the function get_page_from_post(), any post or page can be selected
 * and added to a post list.
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs entries to screen
 *
 * @since 1.0.0
 */
 function pcom_add_post_list($syntax,$custom_class,$placement)
 {
  // -------------
  // process non-empty syntax
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $args = array(
    'open' => constant('pcom_commands::PCOM_KEYWORD_OPEN'),
    'close' => constant('pcom_commands::PCOM_KEYWORD_CLOSE')
  );
  //
    if (!empty($syntax)) {
      //
      //
  		pcom_open_placement_class($custom_class,$placement);
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_POST_LIST_CUSTOM_OPEN'));
      //
        while ( $commands['command'] != $no_entry ) {
          //
          $commands = pcom_process_command_open_close_syntax($syntax,$args); // list uses keyword level commands
          // filter out any custom classes - these should be applied to the top level
          $command_custom = pcom_process_custom_command($commands['command']);
          // process post or page as entry
          if ($command_custom['command'] == $GLOBALS['PM_POST_LIST_ENTRY_KEYWORD'] ) {
            pcom_process_post_list_command($commands['command_syntax']);
          }
          // add title if keyword present
          if ($command_custom['command'] == $GLOBALS['PM_POST_LIST_TITLE_KEYWORD'] ) {
            $html_out = pcom_add_list_title($commands['command_syntax']);
            echo $html_out;
          }
          // update syntax
          $syntax = $commands['syntax_after'];
      //
        } // end of while
    //
      // close post list
      echo constant('pmschematics::PM_POST_LIST_CLOSE');
      pcom_close_placement_class($placement);
    //
    } // end of main if
  // ----
 }
//
/**
 * Outputs post or page to screen as an entry
 * Uses slug name to locate entries
 *
 * @param string $syntax - the slug name
 *
 * @return none - outputs entries to screen
 *
 * @since 1.0.0
 */
 function pcom_process_post_list_command($syntax)
 {
  // outputs post or page to screen as an entry
    $default_image = polimorf_get_default_post_thumb();
  // process syntax for local constants
    $syntax = pcom_site_constants_replacement($syntax);
  //
  // POSTS
    $post_search = get_posts();
    $page_search = get_pages();
    //
    foreach($post_search as $post) {
      if ($syntax == basename(get_permalink($post)) ) {
        //
        $temp = $wp_query;
      	$wp_query = null;
      	$wp_query = new WP_Query(array(
          'name' => $syntax
        ));
      	//
      	if ($wp_query->have_posts()) {
      		while ($wp_query->have_posts()) : $wp_query->the_post();
      			polimorf_post_list_entry($post, $default_image );
      		endwhile;
      	}
      	// reset post query
        $wp_query = null;
    		$wp_query = $temp;
        //
        wp_reset_query();
      }
    }
  //
  // PAGES
    //
    foreach($page_search as $page) {
      if ($syntax == basename(get_permalink($page)) ) {
        $post = get_post($page);
      	polimorf_post_list_entry($post, $default_image );
      }
    }
  //
 }
//
// ********
//
//
//
// SECTION
// -------
/**
 * Sections work by having a name in {{ NAME }} which is used as the id
 * and calling nested schematic commands as [[ ]] inserts
 * --
 * If a section has no name it won't be processed.
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs entries to screen
 *
 * @since 1.0.0
 */
 function pcom_process_section($syntax,$custom_class,$placement)
 {
  // sections work by having a name in {{ NAME }} which is used as the id
  // and calling nested schematic commands as [[ ]] inserts
  // --
  // if a section has no name it won't be processed.
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $section_command = $GLOBALS['PM_SECTION_COMMAND'];
  //
  $name_args = array(
    'open' => constant('pcom_commands::PCOM_SECTION_NAME_OPEN'),
    'close' => constant('pcom_commands::PCOM_SECTION_NAME_CLOSE')
  );
  $command_args = array(
    'open' => constant('pcom_commands::PCOM_SECTION_SCHEMATIC_COMMAND_OPEN'),
    'close' => constant('pcom_commands::PCOM_SECTION_SCHEMATIC_COMMAND_CLOSE')
  );
  // condition custom_class
  if ($custom_class == $no_entry) {
    $custom_class = '';
  } else {
    // add space
    $custom_class = ' ' . $custom_class;
  }
  // ---
  // process schematic data for name
    $section_data = pcom_process_command_open_close_syntax($syntax,$name_args);
    if ($section_data['command_found'] == true){
      // open div
      $section_name = esc_attr($section_data['command_syntax']);
      echo '<div id="' . $section_name . '"' .
      constant('pmschematics::PM_ADD_SECTION_CLASS') . $custom_class . '">' . "\r\n";
      // remove name from syntax and continue
      $syntax = $section_data['command'] . $section_data['syntax_after'];
      //
      while ( $schematic_commands['command'] != $no_entry) {
        $schematic_commands = pcom_get_first_command($syntax,$command_args); // $args is null here
        pcom_command_selection($schematic_commands['command'],$schematic_commands['command_syntax'],$placement);
        $syntax = $schematic_commands['next_command'];
      }
      // close div
      echo '</div><!-- end of section -->'. "\r\n";
    }
  //
 }
// ----------
//
// ===========
// QUOTE
// ===========
//
/**
 * Adds a quote to the screen in the format of
 * QUOTE SYMBOL - QUOTE - QUOTE LINK
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs entries to screen
 *
 * @since 1.0.0
 */
 function pcom_insert_quote_box($syntax,$custom_class,$placement){
  //
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $no_url = constant('pcom_commands::PCOM_NO_URL');
  $body_text = "";
  $ref_text = "";
  $ref_link = $no_url;
  //
  $args = array(
    'open' => constant('pcom_commands::PCOM_KEYWORD_OPEN'),
    'close' => constant('pcom_commands::PCOM_KEYWORD_CLOSE')
  );
  // set to keywords instead of commands
  $body_command = $GLOBALS['PM_QUOTE_BODY_KEYWORD'];
  $ref_command = $GLOBALS['PM_QUOTE_REF_KEYWORD'];
  $ref_link_command = $GLOBALS['PM_QUOTE_LINK_KEYWORD'];
  //
    if (!empty($syntax)) {
  //
  // process syntax for body and reference (ref)
      while ( $commands['command'] != $no_entry ) {
      //
        $commands = pcom_process_command_open_close_syntax($syntax,$args);
        // filter out any custom classes - these should be applied to the top level
        $command_custom = pcom_process_custom_command($commands['command']);
        // process for text and reference
        if ($command_custom['command'] == $body_command) {
          // only processes html tags - no links or images
          $body_text = pcom_process_post_text($commands['command_syntax']);
        }
        if ($command_custom['command'] == $ref_command) {
          // only processes html tags - no links or images
          $ref_text = pcom_process_post_text($commands['command_syntax']);
        }
        if ($command_custom['command'] == $ref_link_command) {
          // process link attributes
          $ref_link = pcom_process_quote_link($commands['command_syntax']);
        }
        //
        // update syntax
        $syntax = $commands['syntax_after'];
      }
    //
      // append quote wrap class
      $custom_class_wrap = constant('pcom_commands::PCOM_QUOTE_WRAP_CLASS') . ' ' . $custom_class;
      //
      // output quote
      pcom_open_placement_class($custom_class_wrap,$placement);
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_QUOTE_OPEN'));
      //
      echo constant('pmschematics::PM_QUOTATION_MARKS');
      //
      echo $body_text;
      //
      echo constant('pmschematics::PM_QUOTE_REF_OPEN');
      // add in quote link if present
      if ($ref_link != $no_url ) {
        echo $ref_link . $ref_text . '</a>' . "\r\n";
      } else {
        echo $ref_text;
      }
      //
      echo constant('pmschematics::PM_QUOTE_REF_CLOSE');
      //
      echo constant('pmschematics::PM_QUOTE_CLOSE');
      //
      pcom_close_placement_class($placement);
    } // - end if
  //--
 }
//
//
// QUOTE with return data
/**
 * Adds a quote to the screen in the format of
 * QUOTE SYMBOL - QUOTE - QUOTE LINK
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return string $out  - quote html
 *
 * @since 1.0.0
 */
 function pcom_return_quote_box($syntax,$custom_class,$placement){
  //
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $no_url = constant('pcom_commands::PCOM_NO_URL');
  $body_text = "";
  $ref_text = "";
  $ref_link = $no_url;
  //
  $out = '';
  //
  $args = array(
    'open' => constant('pcom_commands::PCOM_KEYWORD_OPEN'),
    'close' => constant('pcom_commands::PCOM_KEYWORD_CLOSE')
  );
  // set to keywords instead of commands
  $body_command = $GLOBALS['PM_QUOTE_BODY_KEYWORD'];
  $ref_command = $GLOBALS['PM_QUOTE_REF_KEYWORD'];
  $ref_link_command = $GLOBALS['PM_QUOTE_LINK_KEYWORD'];
  //
    if (!empty($syntax)) {
  //
  // process syntax for body and reference (ref)
      while ( $commands['command'] != $no_entry ) {
      //
        $commands = pcom_process_command_open_close_syntax($syntax,$args);
        // filter out any custom classes - these should be applied to the top level
        $command_custom = pcom_process_custom_command($commands['command']);
        // process for text and reference
        if ($command_custom['command'] == $body_command) {
          // only processes html tags - no links or images
          $body_text = pcom_process_post_text($commands['command_syntax']);
        }
        if ($command_custom['command'] == $ref_command) {
          // only processes html tags - no links or images
          $ref_text = pcom_process_post_text($commands['command_syntax']);
        }
        if ($command_custom['command'] == $ref_link_command) {
          // process link attributes
          $ref_link = pcom_process_quote_link($commands['command_syntax']);
        }
        //
        // update syntax
        $syntax = $commands['syntax_after'];
      }
    //
      // append quote wrap class
      $custom_class_wrap = constant('pcom_commands::PCOM_QUOTE_WRAP_CLASS') . ' ' . $custom_class;
      //
      // output quote
      $out = pcom_return_open_placement_class($custom_class_wrap,$placement) .
      pcom_return_open_custom_class_div($custom_class,constant('pmschematics::PM_QUOTE_OPEN'));
      //
      $out = $out . constant('pmschematics::PM_QUOTATION_MARKS') . $body_text .
      constant('pmschematics::PM_QUOTE_REF_OPEN');
      // add in quote link if present
      if ($ref_link != $no_url ) {
        $out = $out . '<a href="' . $ref_link . '">' . $ref_text . '</a>' . "\r\n";
      } else {
        $out = $out . $ref_text;
      }
      //
      $out = $out . constant('pmschematics::PM_QUOTE_REF_CLOSE') .
      constant('pmschematics::PM_QUOTE_CLOSE') .
      pcom_return_close_placement_class($placement);
    } // - end if
  //--
  return $out;
 }
//
//
//
/**
 * Process the link for the quote
 * Accommodates custom attributes
 *
 * @param string $syntax - command syntax
 *
 * @return string $out_strong  - quote link html
 *
 * @since 1.0.0
 */
 function pcom_process_quote_link($syntax)
 {
  //
  // set link array
  $link_attributes = $GLOBALS['PM_LINK_ATTRIBUTES'];
  $general_attributes = $GLOBALS['PM_HTML_GLOBAL_ATTRIBUTES'];
  //
  $custom_link_attributes = $GLOBALS['PM_CUSTOM_LINK_ATTRIBUTES'];
  $custom_general_attributes = $GLOBALS['PM_CUSTOM_HTML_ATTRIBUTES'];
  // replace custom keys
  $syntax = pcom_replace_custom_attributes($syntax,$custom_link_attributes);
  $syntax = pcom_replace_custom_attributes($syntax,$custom_general_attributes);
  //
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  $arg_start = constant('pcom_commands::PCOM_ATTRIBUTE_OPEN');
  $arg_end = constant('pcom_commands::PCOM_ATTRIBUTE_CLOSE');
  // get attribute allocations
  $link_attributes = pcom_process_keyword_args($syntax,$link_attributes);
  $general_attributes = pcom_process_keyword_args($syntax,$general_attributes);
  // process shortcuts
  $link_attributes['href'] = pcom_site_constants_replacement($link_attributes['href']);
  //
  $link_string = "";
  // process general attributes first
    foreach($general_attributes as $key => $val){
      if ( $val != $no_entry ) {
        // sanitize value
        $val = pcom_esc_output_functions($val,$key);
        $link_string = $link_string . $key . $arg_start . $val . $arg_end . ' ';
      }
    }
    // trim last space if any
    $link_string = trim($link_string);
    //
    // process link attributes - apart from text
    foreach($link_attributes as $key => $val){
      if ( ( $val != $no_entry ) && ( $val != $GLOBALS['PM_TEXT_ATTRIBUTE'] ) ) {
        $val = pcom_esc_output_functions($val,$key);
        $link_string = $link_string . $key . $arg_start . $val . $arg_end . ' ';
      }
    }
    // trim last space if any
    $link_string = trim($link_string);
    //
    $out_string = '<a ' . $link_string . '>'. "\r\n";
  // ----
  return $out_string;
  //
 }
// ===========
// ----
// ===========
// WIDGETS
// ===========
//
/**
 * Adds a Wordpress widget area
 * Syntax is simply the widget number
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return string $out  - quote html
 *
 * @since 1.0.0
 */
 function pcom_insert_widgets($syntax,$custom_class,$placement){
  // added to area after content and pagination
  $main = constant('pcom_commands::PCOM_MAIN_PLACEMENT');
  $main_sidebar = constant('pcom_commands::PCOM_MAIN_WITH_SIDEBAR_PLACEMENT');
  $sidebar = constant('pcom_commands::PCOM_WITH_SIDEBAR_PLACEMENT');
  $footer = constant('pcom_commands::PCOM_FOOTER_PLACEMENT');
  // process syntax
  // default is 1
  // limits no to max number of widget global value
  $widget_data = pcom_process_widget_syntax($syntax);
  // =============
  // CONTENT AREA
  // --------------
  if ( ( $placement == $main ) || ( $placement == $main_sidebar ) ) {
  //
    if ( is_active_sidebar($widget_data['number']) ) {
  	//
      switch ($placement) {
        case $main :
          pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_MAIN_OUTER_OPEN'));
          pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_MAIN_INNER_OPEN'));
          //
          pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_WIDGET_DIV_OPEN'));
    			dynamic_sidebar($widget_data['name']);
    			echo constant('pmschematics::PM_WIDGET_DIV_CLOSE');
          //
          echo constant('pmschematics::PM_MAIN_DIVS_CLOSE');
          //
        break;
        //
        case $main_sidebar :
          //
          pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_WIDGET_DIV_OPEN'));
    			dynamic_sidebar($widget_data['name']);
    			echo constant('pmschematics::PM_WIDGET_DIV_CLOSE');
          //
        break;
      }
  //
    } // end if
  //
  }
  //
  // =============
  // SIDEBAR AREA
  // --------------
  if ( $placement == $sidebar ) {
    if ( is_active_sidebar($widget_data['number']) ) {
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_SIDEBAR_CONTENT_OPEN'));
      dynamic_sidebar($widget_data['name']);
      echo constant('pmschematics::PM_SIDEBAR_CONTENT_CLOSE');
    }
  }
  // =============
  // FOOTER AREA
  // --------------
  if ( $placement == $footer ) {
    if ( is_active_sidebar($widget_data['number']) ) {
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_FOOTER_OUTER_OPEN'));
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_FOOTER_INNER_OPEN'));
      //
      pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_FOOTER_WIDGET_DIV_OPEN'));
      dynamic_sidebar($widget_data['name']);
      echo constant('pmschematics::PM_FOOTER_WIDGET_DIV_CLOSE');
      //
      echo constant('pmschematics::PM_FOOTER_DIVS_CLOSE');
    }
  }
  // -- end
 }
// -----
// -----
/**
 * Processes widget if within range of number of widgets
 *
 * @param string $syntax - command syntax
 *
 * @return array $out_array - widget_number (int), name (string)
 *
 * @since 1.0.0
 */
 function pcom_process_widget_syntax($syntax)
 {
  // conditions widget syntax and returns number and name of widget
  $root_ref = esc_attr($GLOBALS['PM_WIDGET_AREA_ROOT']);
  $default_widget_name = $root_ref . ' 1';
  $out_array = array(
    'number' => 1,
    'name' => $default_widget_name
  );
  // convert to integer
  $syntax = trim($syntax);
  $widget_number = (int) $syntax;
  if ( $syntax <= $GLOBALS['PM_NO_OF_WIDGETS'] ) {
  //
    $out_array['number'] = $widget_number;
    $out_array['name'] = $root_ref . ' ' . $syntax;
  }
  //
  return $out_array;
 }
//
// ------------
//
/**
 * Adds widget in a box element
 *
 * @param string $syntax - command syntax
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_insert_widgets_for_n_box($syntax)
 {
  // no placement needed - only content widget
  //
  // process syntax
  // default is 1
  $widget_data = pcom_process_widget_syntax($syntax);
  //
  if ( is_active_sidebar($widget_data['number']) ) {
    //
    pcom_open_custom_class_div(null,constant('pmschematics::PM_WIDGET_DIV_N_BOX_OPEN'));
    dynamic_sidebar($widget_data['name']);
    echo constant('pmschematics::PM_WIDGET_DIV_N_BOX_CLOSE');
  }
  // --
 }
//
// --------
// =============
// PAGINATION
// =============
/**
 * Adds nextpage to a post/page
 * Adds next/prev pagination to a post
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_insert_pagination()
 {
  // adds pagination if single or page
  $sidebar_found = $GLOBALS['sidebar_found'];
  //
    if ( ( is_single()) || ( is_page()) ){
    //
      if ($sidebar_found != true) {
        echo constant('pmschematics::PM_MAIN_DIVS_OPEN');
      }
      // internal post/page (nextpage first)
      wp_link_pages( $GLOBALS['LINK_PAGE_PAGINATION_DEFAULTS']);
      //
      echo constant('pmschematics::PM_AFTER_POST_OPEN');
      // insert next/prev posts links for posts only
      if (is_single()) polimorf_insert_post_pagination();
      //
      echo constant('pmschematics::PM_AFTER_POST_CLOSE');
      if ($sidebar_found != true) {
        echo constant('pmschematics::PM_MAIN_DIVS_CLOSE');
      }
    }
  //
 }
//
// ===========
// COMMENTS
// ===========
//
/**
 * Adds the comment section to the main area
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs to screen
 *
 * @since 1.0.0
 */
 function polimorf_insert_comments($syntax,$custom_class,$placement)
 {
  // adds comments for both
  $args = array();
  $sidebar_found = $GLOBALS['sidebar_found'];
  // only add comments if placement is main or main with sidebar
    if ( ($placement == constant('pcom_commands::PCOM_MAIN_PLACEMENT')) || ($placement == constant('pcom_commands::PCOM_MAIN_WITH_SIDEBAR_PLACEMENT')) ) {
    //
      if ( (is_single()) || ( is_page()) ){
      //
        if ($sidebar_found != true) {
          echo constant('pmschematics::PM_MAIN_DIVS_OPEN');
        }
        echo constant('pmschematics::PM_AFTER_POST_OPEN');
        //
        comments_template( $GLOBALS['$comments_path']);
      //
        echo constant('pmschematics::PM_AFTER_POST_CLOSE');
        if ($sidebar_found != true) {
          echo constant('pmschematics::PM_MAIN_DIVS_CLOSE');
        }
      }
    }
  //
 }
// ===========
// SEARCHBAR
// ===========
//
/**
 * Inserts searchbar as standalone unit
 * Called by direct command
 *
 * @param string $syntax - command syntax
 * @param string $custom_class - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs to screen
 *
 * @since 1.0.0
 */
 function pcom_insert_searchbar($syntax,$custom_class,$placement)
 {
  //
  pcom_open_placement_class($custom_class,$placement);
  pcom_open_custom_class_div($custom_class,constant('pmschematics::PM_GENERAL_CONTENT_WRAP_OPEN'));
  $search_out = polimorf_insert_searchbar();
  echo $search_out;
  echo constant('pmschematics::PM_GENERAL_CONTENT_WRAP_CLOSE');
  pcom_close_placement_class($placement);
  //
 }
// ===========
// PROCESS CUSTOM META FOR POSTS and PAGES
// ===========
/**
 * Processes custom meta image field and excerpt if filled in
 *
 * @param string $syntax - command syntax
 * @param string $type - excerpt or image
 *
 * @return array $out_array -  data_valid (boolean), data (string)
 *
 * @since 1.0.0
 */
 function pcom_process_custom_meta_for_commands($data,$type)
 {
  // fill in default - out array set up with data passthrough
  //
  $out_array = array(
    'data_valid' => false,
    'data' => $data
  );
  //
  $custom_remote_attributes = $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES'];
  // replace custom keys
  $data = pcom_replace_custom_attributes($data,$custom_remote_attributes);
  //
  $remote_args_in = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
  // check for sub command i.e. =[]:
  $command = pcom_process_command_open_close_syntax($data,null); // default is sub command
  //
  switch ($type) {
  // --------------
  //
    case constant('pcom_commands::PCOM_CUSTOM_META_EXCERPT') :
  //
      switch ( $command['command'] ) {
        //
        case $GLOBALS['PM_REMOTE_SCHEMATIC_AWS_COMMAND'] :
        // process syntax
        $remote_args_in = pcom_process_keyword_args($command['command_syntax'],$remote_args_in);
        // use SCHEMATIC keyword as it retrives data
        $data_retrieved = pcom_get_object_aws($remote_args_in,$GLOBALS['PM_REMOTE_SCHEMATIC_AWS_SUBCOMMAND']);
        // expected data should be a text command
        $remote_data = pcom_process_command_open_close_syntax($data_retrieved,null); // default is sub command
        //
        if ( $remote_data['command'] == $GLOBALS['PM_TEXT_COMMAND'] ) {
          $out_array['data_valid'] = true;
          $out_array['data'] = pcom_process_text_command($command['command_syntax']);
        }
      //
        break;
      //
        case $GLOBALS['PM_TEXT_COMMAND'] :
          $out_array['data_valid'] = true;
          $out_array['data'] = pcom_process_text_command($command['command_syntax']);
        break;
      //
      }
    //
    break;
  ///
  /// ---
  ///
    case constant('pcom_commands::PCOM_CUSTOM_META_IMAGE') :
  //
      switch ( $command['command'] ) {
  //
        case $GLOBALS['PM_REMOTE_IMAGE_AWS_SUBCOMMAND'] :
        // process syntax
        $remote_args_in = pcom_process_keyword_args($command['command_syntax'],$remote_args_in);
        // use IMAGE keyword to retrieve image src
        $out_array['data'] = pcom_get_object_aws($remote_args_in,constant('pcom_commands::PCOM_REMOTE_IMAGE_SUBCOMMAND'));
        $out_array['data_valid'] = true;
        //
        break;
  //
      }
  //
    break;
  //
  }
  //
  return $out_array;
 }
// ---
// ========
// STYLE command - add extra css within schematic of by remote
// ========
/**
 * Adds an inline style statement anywhere the structure (except head)
 *
 * @param string $syntax - command syntax
 * @param string $type - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs to screen
 *
 * @since 1.0.0
 */
 function pcom_insert_styling($syntax,$custom_class,$placement) {
  //
  $allowed_css = array(); // empty styling - gets rid of html
  $nasties = constant('pcom_commands::PCOM_NASTY_REPLACE');
  // clean html and any query commands
  $syntax = wp_kses($syntax,$allowed_css);
  $syntax = pcom_denasty_string($syntax);
  // replace site constants
  $syntax = pcom_site_constants_replacement($syntax);
  // if not empty echo to screen within style tags
    if (!empty($syntax)) {
      echo '<style><!-- ' . $syntax . ' --></style>' . "\r\n";
    }
  //
 }
//
// ========
// FONTS
// ========
/**
 * Adds a font reference to wp_head
 *
 * @param string $syntax - command syntax
 * @param string $type - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs to wp_head
 *
 * @since 1.0.0
 */
 function pcom_insert_font_reference($syntax,$custom_class,$placement)
 {
  // only called in header
    if ($placement == constant('pcom_commands::PCOM_HEADER_PLACEMENT')) {
    // if not empty set global
      if (!empty($syntax)) {
        // increment count
        $GLOBALS['pm_header_font_reference_count'] = $GLOBALS['pm_header_font_reference_count'] + 1;
        // add to array
        $GLOBALS['pm_header_font_references'][$GLOBALS['pm_header_font_reference_count'] - 1 ] = $syntax;
        //
        add_action('wp_head', 'pcom_add_font_ref_to_header', $GLOBALS['PM_FONT_ADD_PRIORITY']);
      }
    //
    }
  // func end
 }
//
//
//
/**
 * Adds a font reference to wp_head
 * Called through an add action in pcom_insert_font_reference
 *
 * @param none
 *
 * @return none - outputs to wp_head
 *
 * @since 1.0.0
 */
 function pcom_add_font_ref_to_header()
 {
  // if font ref count is not 0 add references
  $data = $GLOBALS['pm_header_font_references'];
  $count = $GLOBALS['pm_header_font_reference_count'];
    if ($count > 0) {
      foreach($data as $ref) {
        ?><link href="<?php echo esc_url($ref); ?>" rel="stylesheet"><?php
      }
    }
    // reset globals
  $GLOBALS['pm_header_font_references'] = array();
  $GLOBALS['pm_header_font_reference_count'] = 0;
  // func end
 }
//
// ========
// STYLESHEETS
// ========
/**
 * Adds a stylesheet reference to wp_head
 *
 * @param string $syntax - command syntax
 * @param string $type - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs to wp_head
 *
 * @since 1.0.0
 */
 function pcom_insert_stylesheet_reference($syntax,$custom_class,$placement)
 {
  // only called in header
  // custom class is not processed
  // syntax uses keywords
  //
  $args = array(
    'open' => constant('pcom_commands::PCOM_KEYWORD_OPEN'),
    'close' => constant('pcom_commands::PCOM_KEYWORD_CLOSE'),
  );
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  //
    if ($placement == constant('pcom_commands::PCOM_HEADER_PLACEMENT')) {
      // loop over syntax entries
        while ($commands['syntax_after'] != $no_entry) {
          $commands = pcom_process_command_open_close_syntax($syntax,$args);
      //
          if ($commands['command_found'] == true){
      //
            switch($commands['command']) {
      //
            case $GLOBALS['PM_INSERT_STYLESHEET_REF_KEYWORD'] :
              pcom_process_stylesheet_ref($commands['command_syntax']);
            break;
      //
            }
          // - end if
          }
          $syntax = $commands['syntax_after'];
        // - end while
        }
      // - end $placement
    }
  // --------
  // end func
 }
//
/**
 * Processes stylesheet reference syntax
 * Accommodates for custom attributes and remote linking
 *
 * @param string $syntax - command syntax
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_process_stylesheet_ref($syntax)
 {
  // looks for url or remote attributes
      if (!empty($syntax)) {
        // replace custom attributes
        $syntax = pcom_replace_custom_attributes($syntax,$GLOBALS['PM_CUSTOM_INSERT_STYLESHEET_REF_ATTRIBUTES']);
        $syntax = pcom_replace_custom_attributes($syntax,$GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES']);
        //
        $stylesheet_attributes = $GLOBALS['PM_INSERT_STYLESHEET_REF_ATTRIBUTES'];
        $remote_attributes = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
        // process attributes
        $stylesheet_attributes = pcom_process_keyword_args($syntax,$stylesheet_attributes);
        $remote_attributes = pcom_process_keyword_args($syntax,$remote_attributes);
        // process for remote attributes - if not present process shortcuts
        // url is sanitized (esc) in the function
        $processed = pcom_process_remote_url_syntax($stylesheet_attributes['url'],$remote_attributes);
        //
        // increment count
        $GLOBALS['pm_header_stylesheet_reference_count'] = $GLOBALS['pm_header_stylesheet_reference_count'] + 1;
        // add to array
        $GLOBALS['pm_header_stylesheet_references'][$GLOBALS['pm_header_stylesheet_reference_count'] - 1 ] = $processed;
        //
        add_action('wp_head', 'pcom_add_stylesheet_ref_to_header', $GLOBALS['PM_STYLESHEET_ADD_PRIORITY']);
      }
  //
 }
//
/**
 * Echoes stylesheet reference to wp_head using global data
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_stylesheet_ref_to_header()
 {
  // if stylesheet ref is not no entry add reference
  $data = $GLOBALS['pm_header_stylesheet_references'];
  $count = $GLOBALS['pm_header_stylesheet_reference_count'];
  if($count > 0) {
    foreach($data as $ref) {
      ?><link href="<?php echo esc_url($ref); ?>" rel="stylesheet" type="text/css" media="screen"><?php
    }
  }
  // reset global
  $GLOBALS['pm_header_stylesheet_references'] = array();
  $GLOBALS['pm_header_stylesheet_reference_count'] = 0;
  //
  // func end
 }
//
// ============
// BACKGROUND - section and command
// ============
/**
 * Adds a background style statement to wp_head
 *
 * @param string $syntax - command syntax
 * @param string $type - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs to wp_head
 *
 * @since 1.0.0
 */
 function pcom_insert_background_image_reference($syntax,$custom_class,$placement)
 {
  // only called in header
  // custom class is not processed
  // syntax uses keywords
  //
  $args = array(
    'open' => constant('pcom_commands::PCOM_KEYWORD_OPEN'),
    'close' => constant('pcom_commands::PCOM_KEYWORD_CLOSE'),
  );
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  //
    if ($placement == constant('pcom_commands::PCOM_HEADER_PLACEMENT')) {
      // loop over syntax entries
        while ($commands['syntax_after'] != $no_entry) {
          $commands = pcom_process_command_open_close_syntax($syntax,$args);
      //
          if ($commands['command_found'] == true){
      //
            switch($commands['command']) {
      //
            case $GLOBALS['PM_INSERT_BACKGROUND_IMAGE_KEYWORD'] :
            pcom_process_background_image_ref_syntax($commands['command_syntax']);
            break;
      //
            }
          // - end if
          }
          $syntax = $commands['syntax_after'];
        // - end while
        }
      // - end $placement
    }
  // --------
  // end func
 }
//
/**
 * Processes background image syntax
 * Accommodates for custom attributes and remote linking
 *
 * @param string $syntax - command syntax
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_process_background_image_ref_syntax($syntax)
 {
  // looks for url or remote attributes
      if (!empty($syntax)) {
        // replace custom attributes
        $syntax = pcom_replace_custom_attributes($syntax,$GLOBALS['PM_CUSTOM_INSERT_BACKGROUND_IMAGE_ATTRIBUTES']);
        $syntax = pcom_replace_custom_attributes($syntax,$GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES']);
        //
        $background_attributes = $GLOBALS['PM_INSERT_BACKGROUND_IMAGE_ATTRIBUTES'];
        $remote_attributes = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
        // process attributes
        $background_attributes = pcom_process_keyword_args($syntax,$background_attributes);
        $remote_attributes = pcom_process_keyword_args($syntax,$remote_attributes);
        // process for remote attributes - if not present process shortcuts
        // url is sanitized (esc) in the function
        $processed = pcom_process_remote_url_syntax($background_attributes['url'],$remote_attributes);
        // increment count
        $GLOBALS['pm_background_image_reference_count'] = $GLOBALS['pm_background_image_reference_count'] + 1;
        // add to array
        $GLOBALS['pm_background_image_references'][$GLOBALS['pm_background_image_reference_count'] - 1] = $processed;
        $GLOBALS['pm_background_image_names'][$GLOBALS['pm_background_image_reference_count'] - 1] = esc_attr($background_attributes['name']);
        //
        add_action('wp_head', 'pcom_add_background_image_ref_to_header', $GLOBALS['PM_BACKGROUND_IMAGE_ADD_PRIORITY']);
      }
  //
 }
//
/**
 * Echoes css background reference to screen
 * using global data
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_background_image_ref_to_header()
 {
  // if stylesheet ref is not no entry add reference
  $count = $GLOBALS['pm_background_image_reference_count'];
  $data_image = $GLOBALS['pm_background_image_references'];
  $data_name = $GLOBALS['pm_background_image_names'];
  if ($count > 0) {
    for($i = 0; $i < $count; $i++) {
      if ( $data_name[$i] != constant('pcom_commands::PCOM_NO_ENTRY') ) {
        // background reference already sanitized - DO NOT ESC - will affect hash
       ?><style><?php echo $data_name[$i]; ?> { background-image: url('<?php echo $data_image[$i]; ?>'); } </style>
       <?php
      }
    }
  }
  // reset globals
  $GLOBALS['pm_background_image_references'] = array();
  $GLOBALS['pm_background_image_names']  = array();
  $GLOBALS['pm_background_image_reference_count'] = 0;
  //
  // func end
 }
//
// HEADER CONTENT
// -----------------
/**
 * Adds specific header content to wp_head
 * This is typically script text added using text replacement
 * in TEXT=[ ]: subcommands
 *
 * @param string $syntax - command syntax
 * @param string $type - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs to wp_head
 *
 * @since 1.0.0
 */
 function pcom_add_header_content_to_wp_head($syntax,$custom_class,$placement)
 {
  // only called in header
  // custom class is not processed
  // syntax uses subcommand TEXT
  //
  // clean syntax of html tags - includes < and > used in calculations
  $clean_array = array('<' => '', '>' => '');
  $syntax = str_replace(array_keys($clean_array),$clean_array,$syntax);
  $html_out = '';
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  //
    if ($placement == constant('pcom_commands::PCOM_HEADER_PLACEMENT')) {
      // loop over syntax entries
        while ($commands['syntax_after'] != $no_entry) {
          $commands = pcom_process_command_open_close_syntax($syntax,null); // default is subcommand
      //
          if ($commands['command_found'] == true){
      //
            switch($commands['command']) {
      //
            case $GLOBALS['PM_HEADER_CONTENT_TEXT_SUBCOMMAND'] :
              $html_out = $html_out . pcom_process_post_text($commands['command_syntax']);
            break;
      //
            case $GLOBALS['PM_HEADER_CONTENT_SCRIPT_SUBCOMMAND'] :
              $html_out = $html_out . pcom_process_header_src($commands['command_syntax']);
            break;
      //
            }
          // - end if
          }
          $syntax = $commands['syntax_after'];
        // - end while
        }
      // - end $placement
    }
  // set global
  $GLOBALS['pm_header_content_data'] = $html_out;
  // call header hook
  add_action('wp_head','pcom_add_header_content',$GLOBALS['PM_HEADER_CONTENT_ADD_PRIORITY']);
  // --------
  // end func
 }
//
//
//
/**
 * Echoes global header content
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_header_content()
 {
  // adds header content and resets global
    if ( !empty($GLOBALS['pm_header_content_data']) ) {
      echo $GLOBALS['pm_header_content_data'] . "\r\n";
    }
    // reset
    $GLOBALS['pm_header_content_data'] = '';
 }
// ---
//
// FOOTER CONTENT
// -----------------
/**
 * Adds specific footer content to wp_footer
 * This is typically script text added using text replacement
 * in TEXT=[ ]: subcommands
 *
 * @param string $syntax - command syntax
 * @param string $type - extra custom class
 * @param string $placement - section identifier
 *
 * @return none - outputs to wp_head
 *
 * @since 1.0.0
 */
 function pcom_add_footer_content_to_wp_footer($syntax,$custom_class,$placement)
 {
  // only called in header
  // custom class is not processed
  // syntax uses subcommand TEXT
  //
  // clean syntax of html tags - includes < and > used in calculations
  $clean_array = array('<' => '', '>' => '');
  $syntax = str_replace(array_keys($clean_array),$clean_array,$syntax);
  $html_out = '';
  $no_entry = constant('pcom_commands::PCOM_NO_ENTRY');
  //
    if ($placement == constant('pcom_commands::PCOM_HEADER_PLACEMENT')) {
      // loop over syntax entries
        while ($commands['syntax_after'] != $no_entry) {
          $commands = pcom_process_command_open_close_syntax($syntax,null); // default is subcommand
      //
          if ($commands['command_found'] == true){
      //
            switch($commands['command']) {

            case $GLOBALS['PM_FOOTER_CONTENT_TEXT_SUBCOMMAND'] :
              $html_out = $html_out . pcom_process_post_text($commands['command_syntax']);
            break;

            case $GLOBALS['PM_FOOTER_CONTENT_SCRIPT_SUBCOMMAND'] :
              $html_out = $html_out . pcom_process_footer_src($commands['command_syntax']);
            break;
      //
            }
          // - end if
          }
          $syntax = $commands['syntax_after'];
        // - end while
        }
      // - end $placement
    }
  // set global
  $GLOBALS['pm_footer_content_data'] = $html_out;
  // call footer hook
  add_action('wp_footer','pcom_add_footer_content',$GLOBALS['PM_FOOTER_CONTENT_ADD_PRIORITY']);
  // --------
  // end func
 }
//
/**
 * Echoes global footer content
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function pcom_add_footer_content()
 {
  // adds header content and resets global
    if ( !empty($GLOBALS['pm_footer_content_data']) ) {
      echo $GLOBALS['pm_footer_content_data'] . "\r\n";
    }
    // reset
    $GLOBALS['pm_footer_content_data'] = '';
 }
// ---
/**
 * Processes url link for header to be placed in wp_head
 * Accommodates custom attributes and remote linking
 *
 * @param string $syntax - command syntax
 *
 * @return string $html_out - link
 *
 * @since 1.0.0
 */
 function pcom_process_header_src($syntax)
 {
  // if syntax not empty
  $html_out = '';
  //
    if (!empty($syntax)) {
      // replace custom attributes
      $syntax = pcom_replace_custom_attributes($syntax,$GLOBALS['PM_CUSTOM_HEADER_CONTENT_ATTRIBUTES']);
      $syntax = pcom_replace_custom_attributes($syntax,$GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES']);
      //
      $script_attributes = $GLOBALS['PM_HEADER_CONTENT_ATTRIBUTES'];
      $remote_attributes = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
      // process attributes
      $script_attributes = pcom_process_keyword_args($syntax,$script_attributes);
      $remote_attributes = pcom_process_keyword_args($syntax,$remote_attributes);
      // process for remote attributes - if not present process shortcuts
      // src is sanitized (esc) in the function
      $processed = pcom_process_remote_url_syntax($script_attributes['src'],$remote_attributes);
      $html_out = '<script src="' . $processed . '"></script>' . "\r\n";
    }
  //
  return $html_out;
 }
//
/**
 * Processes url link for footer to be placed in wp_footer
 * Accommodates custom attributes and remote linking
 *
 * @param string $syntax - command syntax
 *
 * @return string $html_out - link
 *
 * @since 1.0.0
 */
 function pcom_process_footer_src($syntax)
 {
  // if syntax not empty
  $html_out = '';
  //
    if (!empty($syntax)) {
      // replace custom attributes
      $syntax = pcom_replace_custom_attributes($syntax,$GLOBALS['PM_CUSTOM_FOOTER_CONTENT_ATTRIBUTES']);
      $syntax = pcom_replace_custom_attributes($syntax,$GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES']);
      //
      $script_attributes = $GLOBALS['PM_FOOTER_CONTENT_ATTRIBUTES'];
      $remote_attributes = $GLOBALS['PM_REMOTE_ATTRIBUTES'];
      // process attributes
      $script_attributes = pcom_process_keyword_args($syntax,$script_attributes);
      $remote_attributes = pcom_process_keyword_args($syntax,$remote_attributes);
      // process for remote attributes - if not present process shortcuts
      // src is sanitized (esc) in the function
      $processed = pcom_process_remote_url_syntax($script_attributes['src'],$remote_attributes);
      $html_out = '<script src="' . $processed . '"></script>' . "\r\n";
    }
  //
  return $html_out;
 }
//
// ======== END ==========
//
