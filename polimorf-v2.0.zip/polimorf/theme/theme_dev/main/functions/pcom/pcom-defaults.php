<?php
// ---- -----
// PCOM allowable commands, keywords and associated constants
class pcom_commands {
//
const PCOM_NO_ENTRY = 'NONE';
const PCOM_NO_URL = 'NO_URL';
const PCOM_NOT_USED = 'NOT_USED';
const PCOM_NO_LOGO = 'NO_LOGO';
const PCOM_SPACE = " ";
const PCOM_SITE_HOME = 'SITE_HOME'; // short cut command for home links
const PCOM_SITE_BASE = 'SITE_BASE'; // theme level
const PCOM_UPLOADS = 'UPLOADS'; // media folder for theme - downloads go here
const PCOM_IMAGES = 'IMAGES'; // short cut command for images folder
const PCOM_CUSTOM_CLASS_DECLARATION = '_CUSTOM:';
const PCOM_SCHEMATIC_COMMAND_OPEN = '%%';
const PCOM_SCHEMATIC_COMMAND_CLOSE = '::';
const PCOM_SUB_SCHEMATIC_CLOSE = ':';
const PCOM_SUB_COMMAND_OPEN = '=[';
const PCOM_SUB_COMMAND_CLOSE = ']:';
const PCOM_KEYWORD_OPEN = '={';
const PCOM_KEYWORD_CLOSE = '}:';
const PCOM_ATTRIBUTE_OPEN = '="';
const PCOM_ATTRIBUTE_CLOSE = '"'; // commas
const PCOM_INSERTS_OPEN = '[[';
const PCOM_INSERTS_CLOSE = ']]';
const PCOM_SECTION_NAME_OPEN = '{{';
const PCOM_SECTION_NAME_CLOSE = '}}';
const PCOM_SECTION_SCHEMATIC_COMMAND_OPEN = '[%';
const PCOM_SECTION_SCHEMATIC_COMMAND_CLOSE = ':]';
//
const PCOM_HEADER_PLACEMENT = 'HEADER';
const PCOM_MAIN_PLACEMENT = 'MAIN';
const PCOM_MAIN_WITH_SIDEBAR_PLACEMENT = 'MAIN_WITH_SIDEBAR'; // process main with a sidebar
const PCOM_WITH_SIDEBAR_PLACEMENT = 'WITH_SIDEBAR'; // process the sidebar elements
const PCOM_FOOTER_PLACEMENT = 'FOOTER';
//
// SCHEMATIC SEPARATORS
const PCOM_HEADER_SCHEMATIC_TAG = '///HEADER:';
const PCOM_MAIN_SCHEMATIC_TAG = '///MAIN:';
const PCOM_BEFORE_MAIN_SCHEMATIC_TAG = '///BEFORE:';
const PCOM_AFTER_MAIN_SCHEMATIC_TAG = '///AFTER:';
const PCOM_FOOTER_SCHEMATIC_TAG = '///FOOTER:';
const PCOM_REMOTE_SCHEMATIC_TAG = '///REMOTE:';
const PCOM_SIDEBAR_SCHEMATIC_TAG = '///SIDEBAR:';
//
const PCOM_DEFAULT_COMMAND = 'DEFAULT'; // use system schematic settings
//
// NAV
const PCOM_NAV_COMMAND = 'NAV';
// MENU - uses the same commands as NAV
const PCOM_MENU_COMMAND = 'MENU';
//
const PCOM_NAV_MENU_LINK_KEYWORD = 'mlk';
const PCOM_NAV_LOGO_KEYWORD = 'logo';
const PCOM_NAV_SEARCHBAR_KEYWORD = 'searchbar';
const PCOM_WP_MENU_KEYWORD = 'wpmenu'; // add wordpress menu
//
// BOXES
const PCOM_BOX_COMMAND_ROOT = '_BOX';
const PCOM_BOX_BOX = 'BOX';
const PCOM_BOX_BOX_START = 'box-start';
const PCOM_BOX_BOX_END = 'box-end';
const PCOM_BOX_PLACEMENT = "N_BOX";
const PCOM_MAX_NO_BOXES = 4; // min is hardcoded as 2
//
const PCOM_TEXT_COMMAND = 'TEXT'; // used within boxes or content
const PCOM_TEXT_ATTRIBUTE = 'text'; //used as a filter in img, img_link and lnk
const PCOM_TEXT_IMG_KEYWORD = 'img';
const PCOM_TEXT_IMG_LINK_KEYWORD = 'img_link';
const PCOM_TEXT_LINK_KEYWORD = 'link';
//
// Font Awesome FA
const PCOM_FA_ATTRIBUTE = 'fa'; //used as a filter in img, img_link and lnk
//
// QUOTE
const PCOM_QUOTE_COMMAND = 'QUOTE';
const PCOM_QUOTE_BODY_KEYWORD = 'body';
const PCOM_QUOTE_REF_KEYWORD = 'ref';
const PCOM_QUOTE_LINK_KEYWORD = 'link';
const PCOM_QUOTE_WRAP_CLASS = 'pm-quote-wrap';
//
const PCOM_TITLE_COMMAND = 'TITLE'; //
const PCOM_TITLE_KEYWORD = 'title'; //
// CONTENT
const PCOM_CONTENT_COMMAND = 'CONTENT';
// CONTENT DEFAULT
const PCOM_CONTENT_DEFAULT_COMMAND = 'CONTENT_DEFAULT';
// CONTENT META
const PCOM_CONTENT_META_COMMAND = 'CONTENT_META'; // title, author etc
const PCOM_CONTENT_META_TITLE_KEYWORD = 'title';
const PCOM_CONTENT_META_AUTHOR_KEYWORD = 'author';
const PCOM_CONTENT_META_DATE_KEYWORD = 'date';
const PCOM_CONTENT_META_CATEGORY_KEYWORD = 'cat';
const PCOM_CONTENT_META_TAG_KEYWORD = 'tag';
// CONTENT WITH INSERT
const PCOM_CONTENT_WITH_INSERT_COMMAND = 'CONTENT_INSERT'; // title, author etc
//
// POST LIST
const PCOM_POST_LIST_COMMAND = 'POST_LIST';
const PCOM_POST_LIST_ENTRY_KEYWORD = 'entry';
const PCOM_POST_LIST_TITLE_KEYWORD = 'title';
// SECTION COMMAND
const PCOM_SECTION_COMMAND = 'SECTION';
//
// insert widgets
const PCOM_INSERT_WIDGET_COMMAND = 'WIDGETS';
const PCOM_NO_OF_WIDGETS = 5;
// remote get command
const PCOM_REMOTE_SCHEMATIC_AWS_COMMAND = 'REMOTE_SCHEMATIC_AWS';
const PCOM_REMOTE_ADDITION_AWS_COMMAND = 'REMOTE_ADDITION_AWS';
const PCOM_REMOTE_SCHEMATIC_SUBCOMMAND = 'SCHEMATIC';
const PCOM_REMOTE_IMAGE_AWS_SUBCOMMAND = 'REMOTE_IMAGE_AWS'; // used for processing of alternative custom image
const PCOM_REMOTE_IMAGE_SUBCOMMAND = 'IMAGE'; // used for processing in general
//
const PCOM_REMOTE_IMAGE_LINK_TYPE_IMAGE = 'image'; // for processing image link src
const PCOM_REMOTE_IMAGE_LINK_TYPE_LINK = 'link'; // for processing image link href
//
const PCOM_REMOTE_TIMEOUT_MIN = 5; // 5 seconds
const PCOM_REMOTE_TIMEOUT_MAX = 86400; // 1 day
const PCOM_REMOTE_DEFAULT_EXPIRY = 300; // 5 seconds
//
const PCOM_FOOTER_ATTRIBUTION_COMMAND = 'FOOTER_ATT';
//
// insert comments
const PCOM_INSERT_COMMENTS_COMMAND = 'COMMENTS';
// insert pagination
const PCOM_INSERT_PAGINATION_COMMAND = 'PAGINATION';
// insert search bar
const PCOM_INSERT_SEARCHBAR_COMMAND = 'SEARCHBAR';
// insert copyright element
const PCOM_INSERT_COPYRIGHT_STATEMENT_COMMAND = 'COPYRIGHT';
// insert styling
const PCOM_INSERT_STYLING_COMMAND = 'STYLE';
// custom meta processing
const PCOM_CUSTOM_META_EXCERPT = 'EXCERPT';
const PCOM_CUSTOM_META_IMAGE = 'IMAGE';
//
//
// --------
// POST to HTML conversions for TEXT=() commands
const PCOM_POST_HTML_CONVERSIONS = array(
  '[a_open]' => '<a ',
  '[a_close]' => '</a>',
  '[span_open]' => '<span ',
  '[span_close]' => '</span>',
  '[p]' => '<p>',
  '[/p]' => '</p>',
  '[i]' => '<em>',
  '[/i]' => '</em>',
  '[b]' => '<strong>',
  '[/b]' => '</strong>',
  '[strike]' => '<span style="text-decoration: line-through;">',
  '[/strike]' => '</span>',
  '[u]' => '<span style="text-decoration: underline;">',
  '[/u]' => '</span>',
  '[h1]' => '<h1>',
  '[/h1]' => '</h1>',
  '[h2]' => '<h2>',
  '[/h2]' => '</h2>',
  '[h3]' => '<h3>',
  '[/h3]' => '</h3>',
  '[h4]' => '<h4>',
  '[/h4]' => '</h4>',
  '[h5]' => '<h5>',
  '[/h5]' => '</h5>',
  '[ol]' => '<ol>',
  '[/ol]' => '</ol>',
  '[ul]' => '<ul>',
  '[/ul]' => '</ul>',
  '[li]' => '<li>',
  '[/li]' => '</li>',
  '[\n]' => '<br/>',
  '[\2n]' => '<br/><br/>',
  '[\3n]' => '<br/><br/><br/>',
  '[quote]' => '<blockquote>',
  '[/quote]' => '</blockquote>',
  '[code]' => '<code>',
  '[/code]' => '</code>',
  '[pre]' => '<pre>',
  '[/pre]' => '</pre>',
  '[samp]' => '<samp>',
  '[/samp]' => '</samp>',
  '[style]' => '<style><!-- ',
  '[/style]' => ' --></style>',
  '[caption]' => '<div class="wp-caption-pm alignnone"><p class="wp-caption-text">',
  '[/caption]' => '</p></div>',
  '[sch_cmd]' => '%%',
  '[/sch_cmd]' => '::',
  '[sub_cmd]' => '=[',
  '[/sub_cmd]' => ']:',
  '[keyword]' => '={',
  '[/keyword]' => '}:',
  '[tag]' => '<',
  '[/tag]' => '>',
  '[fs]' => '/',
  '[fa]' => '<i ',
  '[/fa]' => '></i>',
  '[pm-para]' => '[p]',
  '[/pm-para]' => '[/p]',
  '[UP-LOADS]' => 'UPLOADS',
  '[SITE-HOME]' => 'SITE_HOME',
  '[pm-tag]' => '[',
  '[/pm-tag]' => ']',
  '[script_open]' => '<script ',
  '[/script]' => '</script>',
  '[html_comment]' => '<!--',
  '[/html_comment]' => '-->'
);
//
// FONTS
// ==========
const PCOM_FONT_ADD_PRIORITY = 505;
const PCOM_INSERT_FONT_COMMAND = 'FONT';
//
// STYLESHEETS
// ==========
const PCOM_STYLESHEET_ADD_PRIORITY = 506;
const PCOM_INSERT_STYLESHEET_REF_COMMAND = 'STYLESHEET';
const PCOM_INSERT_STYLESHEET_REF_KEYWORD = 'ref';
//
// EFFECTS
// ==========
//
const PCOM_EFFECT_PRIORITY = 500;
const PCOM_INSERT_EFFECT_COMMAND = 'EFFECTS';
const PCOM_REVEAL_EFFECT_KEYWORD = 'reveal';
//
// BACKGROUND IMAGE
const PCOM_BACKGROUND_IMAGE_ADD_PRIORITY = 500;
const PCOM_INSERT_BACKGROUND_IMAGE_COMMAND = 'BACKGROUND_IMAGE';
const PCOM_INSERT_BACKGROUND_IMAGE_KEYWORD = 'element';
//
// HEADER_CONTENT - scripts and stuff at end
const PCOM_HEADER_CONTENT_COMMAND = 'HEADER_CONTENT';
const PCOM_HEADER_CONTENT_TEXT_SUBCOMMAND = 'TEXT'; // uses same settings as content text
const PCOM_HEADER_CONTENT_SCRIPT_SUBCOMMAND = 'SCRIPT'; //
const PCOM_HEADER_CONTENT_ADD_PRIORITY = 510;
//
// FOOTER_CONTENT - scripts and stuff at end
const PCOM_FOOTER_CONTENT_COMMAND = 'FOOTER_CONTENT';
const PCOM_FOOTER_CONTENT_TEXT_SUBCOMMAND = 'TEXT'; // uses same settings as content text
const PCOM_FOOTER_CONTENT_SCRIPT_SUBCOMMAND = 'SCRIPT';
const PCOM_FOOTER_CONTENT_ADD_PRIORITY = 510;
// ----------
// CUSTOMISED ATTRIBUTES
// ----------
// array is key => value
// key is the customised value that is used in a schematic
// value is the attribute that is processed
// e.g.
// 'charset' => 'charset' can be changed to
// 'my_charset' => 'charset'
//
// the value should remain the same but the key can be changed.
//
const PCOM_CUSTOM_LINK_ATTRIBUTES = array(
  'text' => 'text',
  'charset' => 'charset',
  'coords' => 'coords',
  'download' => 'download',
  'href' => 'href',
  'hreflang' => 'hreflang',
  'media' => 'media',
  'name' => 'name',
  'rel' => 'rel',
  'rev' => 'rev',
  'shape' => 'shape',
  'target' => 'target',
  'type' => 'type'
);
//
const PCOM_CUSTOM_HTML_ATTRIBUTES = array(
  'accesskey' => 'accesskey',
  'class' => 'class',
  'contenteditable' => 'contenteditable',
  'contextmenu' => 'contextmenu',
  'dir' => 'dir',
  'draggable' => 'draggable',
  'dropzone' => 'dropzone',
  'hidden' => 'hidden',
  'id' => 'id',
  'lang' => 'lang',
  'spellcheck' => 'spellcheck',
  'style' => 'style',
  'tabindex' => 'tabindex',
  'title' => 'title',
  'translate' => 'translate'
);
//
const PCOM_CUSTOM_IMAGE_ATTRIBUTES = array(
'alt' => 'alt',
'crossorigin' => 'crossorigin',
'fa' => 'fa',
'height' => 'height',
'ismap' => 'ismap',
'longdesc' => 'longdesc',
'sizes' => 'sizes',
'src' => 'src',
'srcset' => 'srcset',
'usemap' => 'usemap',
'width' => 'width'
);
//
const PCOM_CUSTOM_REMOTE_ATTRIBUTES = array(
'filename' => 'filename',
'region' => 'region',
'timeout' => 'timeout',
'bucketname' => 'bucketname'
);
//
const PCOM_CUSTOM_REMOTE_ATTRIBUTES_REMOTE_LINK = array(
'link_filename' => 'link_filename',
'link_region' => 'link_region',
'link_timeout' => 'link_timeout',
'link_bucketname' => 'link_bucketname'
);
//
const PCOM_CUSTOM_REMOTE_ATTRIBUTES_REMOTE_IMAGE = array(
'image_filename' => 'image_filename',
'image_region' => 'image_region',
'image_timeout' => 'image_timeout',
'image_bucketname' => 'image_bucketname'
);
//
const PCOM_CUSTOM_MENU_COMMAND_MLK_KEYWORD_ATTRIBUTES = array(
'href' => 'href',
'name' => 'name',
'src' => 'src',
'class' => 'class',
'fa' => 'fa'
);
//
const PCOM_CUSTOM_WPMENU_COMMAND_ATTRIBUTES = array(
'name' => 'name',
'class' => 'class'
);
//
const PCOM_CUSTOM_LOGO_ATTRIBUTES = array(
'src' => 'src'
);
//
const PCOM_CUSTOM_SITE_REPLACEMENTS = array(
'SITE_HOME' => 'SITE_HOME',
'IMAGES' => 'IMAGES',
'UPLOADS' => 'UPLOADS'
);
//
const PCOM_CUSTOM_REVEAL_EFFECTS_ATTRIBUTES = array(
'class' => 'class',
'settings' => 'settings'
);
//
const PCOM_CUSTOM_INSERT_STYLESHEET_REF_ATTRIBUTES = array(
'url' => 'url'
);
//
const PCOM_CUSTOM_INSERT_BACKGROUND_IMAGE_ATTRIBUTES = array(
'url' => 'url',
'name' => 'name'
);
//
const PCOM_CUSTOM_HEADER_CONTENT_ATTRIBUTES = array(
'src' => 'src'
);
//
const PCOM_CUSTOM_FOOTER_CONTENT_ATTRIBUTES = array(
'src' => 'src'
);
//
// ==========
// ==========
// replace nasty stuff with dashes
// --
// used for remote requests which should then fail
const PCOM_NASTY_REPLACE = array(
  'SELECT' => '--',
  'UNION' => '--',
  'DROP' => '--',
  'DROP TABLE' => '--'
);
// end of constant class
}
// =====================
//
// define command and addition function list for later
$GLOBALS['command_functions_list'] = array();
$GLOBALS['addition_functions_list'] =  array();
//
