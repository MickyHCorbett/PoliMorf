<?php
//
//
// SCHEMATIC TAGS
if (!isset($GLOBALS['PM_HEADER_SCHEMATIC_TAG'])) $GLOBALS['PM_HEADER_SCHEMATIC_TAG'] = constant('pcom_commands::PCOM_HEADER_SCHEMATIC_TAG');
if (!isset($GLOBALS['PM_MAIN_SCHEMATIC_TAG'])) $GLOBALS['PM_MAIN_SCHEMATIC_TAG'] = constant('pcom_commands::PCOM_MAIN_SCHEMATIC_TAG');
if (!isset($GLOBALS['PM_BEFORE_MAIN_SCHEMATIC_TAG'])) $GLOBALS['PM_BEFORE_MAIN_SCHEMATIC_TAG'] = constant('pcom_commands::PCOM_BEFORE_MAIN_SCHEMATIC_TAG');
if (!isset($GLOBALS['PM_AFTER_MAIN_SCHEMATIC_TAG'])) $GLOBALS['PM_AFTER_MAIN_SCHEMATIC_TAG'] = constant('pcom_commands::PCOM_AFTER_MAIN_SCHEMATIC_TAG');
if (!isset($GLOBALS['PM_FOOTER_SCHEMATIC_TAG'])) $GLOBALS['PM_FOOTER_SCHEMATIC_TAG'] = constant('pcom_commands::PCOM_FOOTER_SCHEMATIC_TAG');
if (!isset($GLOBALS['PM_REMOTE_SCHEMATIC_TAG'])) $GLOBALS['PM_REMOTE_SCHEMATIC_TAG'] = constant('pcom_commands::PCOM_REMOTE_SCHEMATIC_TAG');
if (!isset($GLOBALS['PM_SIDEBAR_SCHEMATIC_TAG'])) $GLOBALS['PM_SIDEBAR_SCHEMATIC_TAG'] = constant('pcom_commands::PCOM_SIDEBAR_SCHEMATIC_TAG');
//
// CUSTOM CLASS
if (!isset($GLOBALS['PM_CUSTOM_CLASS_DECLARATION'])) $GLOBALS['PM_CUSTOM_CLASS_DECLARATION'] = constant('pcom_commands::PCOM_CUSTOM_CLASS_DECLARATION');
//
// COMMANDS
// ========
// Define global variables with constants from class
// helps with redefining if necessary
//
// DEFAULT
if (!isset($GLOBALS['PM_DEFAULT_COMMAND'])) $GLOBALS['PM_DEFAULT_COMMAND'] = constant('pcom_commands::PCOM_DEFAULT_COMMAND');
// NAV and MENU
if (!isset($GLOBALS['PM_NAV_COMMAND'])) $GLOBALS['PM_NAV_COMMAND'] = constant('pcom_commands::PCOM_NAV_COMMAND');
if (!isset($GLOBALS['PM_MENU_COMMAND'])) $GLOBALS['PM_MENU_COMMAND'] = constant('pcom_commands::PCOM_MENU_COMMAND');
if (!isset($GLOBALS['PM_NAV_MENU_LINK_KEYWORD'])) $GLOBALS['PM_NAV_MENU_LINK_KEYWORD'] = constant('pcom_commands::PCOM_NAV_MENU_LINK_KEYWORD');
if (!isset($GLOBALS['PM_NAV_LOGO_KEYWORD'])) $GLOBALS['PM_NAV_LOGO_KEYWORD'] = constant('pcom_commands::PCOM_NAV_LOGO_KEYWORD');
if (!isset($GLOBALS['PM_NAV_SEARCHBAR_KEYWORD'])) $GLOBALS['PM_NAV_SEARCHBAR_KEYWORD'] = constant('pcom_commands::PCOM_NAV_SEARCHBAR_KEYWORD');
if (!isset($GLOBALS['PM_WP_MENU_KEYWORD'])) $GLOBALS['PM_WP_MENU_KEYWORD'] = constant('pcom_commands::PCOM_WP_MENU_KEYWORD');
// BOXES
if (!isset($GLOBALS['PM_BOX_COMMAND_ROOT'])) $GLOBALS['PM_BOX_COMMAND_ROOT'] = constant('pcom_commands::PCOM_BOX_COMMAND_ROOT');
if (!isset($GLOBALS['PM_BOX_BOX'])) $GLOBALS['PM_BOX_BOX'] = constant('pcom_commands::PCOM_BOX_BOX');
if (!isset($GLOBALS['PM_MAX_NO_BOXES'])) $GLOBALS['PM_MAX_NO_BOXES'] = constant('pcom_commands::PCOM_MAX_NO_BOXES');
// TEXT
if (!isset($GLOBALS['PM_TEXT_COMMAND'])) $GLOBALS['PM_TEXT_COMMAND'] = constant('pcom_commands::PCOM_TEXT_COMMAND');
if (!isset($GLOBALS['PM_TEXT_ATTRIBUTE'])) $GLOBALS['PM_TEXT_ATTRIBUTE'] = constant('pcom_commands::PCOM_TEXT_ATTRIBUTE');
if (!isset($GLOBALS['PM_TEXT_IMG_KEYWORD'])) $GLOBALS['PM_TEXT_IMG_KEYWORD'] = constant('pcom_commands::PCOM_TEXT_IMG_KEYWORD');
if (!isset($GLOBALS['PM_TEXT_IMG_LINK_KEYWORD'])) $GLOBALS['PM_TEXT_IMG_LINK_KEYWORD'] = constant('pcom_commands::PCOM_TEXT_IMG_LINK_KEYWORD');
if (!isset($GLOBALS['PM_TEXT_LINK_KEYWORD'])) $GLOBALS['PM_TEXT_LINK_KEYWORD'] = constant('pcom_commands::PCOM_TEXT_LINK_KEYWORD');
// Font Awesome FA
if (!isset($GLOBALS['PM_FA_ATTRIBUTE'])) $GLOBALS['PM_FA_ATTRIBUTE'] = constant('pcom_commands::PCOM_FA_ATTRIBUTE');
// QUOTE
if (!isset($GLOBALS['PM_QUOTE_COMMAND'])) $GLOBALS['PM_QUOTE_COMMAND'] = constant('pcom_commands::PCOM_QUOTE_COMMAND');
if (!isset($GLOBALS['PM_QUOTE_BODY_KEYWORD'])) $GLOBALS['PM_QUOTE_BODY_KEYWORD'] = constant('pcom_commands::PCOM_QUOTE_BODY_KEYWORD');
if (!isset($GLOBALS['PM_QUOTE_REF_KEYWORD'])) $GLOBALS['PM_QUOTE_REF_KEYWORD'] = constant('pcom_commands::PCOM_QUOTE_REF_KEYWORD');
if (!isset($GLOBALS['PM_QUOTE_LINK_KEYWORD'])) $GLOBALS['PM_QUOTE_LINK_KEYWORD'] = constant('pcom_commands::PCOM_QUOTE_LINK_KEYWORD');
// TITLE
if (!isset($GLOBALS['PM_TITLE_COMMAND'])) $GLOBALS['PM_TITLE_COMMAND'] = constant('pcom_commands::PCOM_TITLE_COMMAND');
if (!isset($GLOBALS['PM_TITLE_KEYWORD'])) $GLOBALS['PM_TITLE_KEYWORD'] = constant('pcom_commands::PCOM_TITLE_KEYWORD');
// CONTENT
if (!isset($GLOBALS['PM_CONTENT_COMMAND'])) $GLOBALS['PM_CONTENT_COMMAND'] = constant('pcom_commands::PCOM_CONTENT_COMMAND');
// CONTENT DEFAULT
if (!isset($GLOBALS['PM_CONTENT_DEFAULT_COMMAND'])) $GLOBALS['PM_CONTENT_DEFAULT_COMMAND'] = constant('pcom_commands::PCOM_CONTENT_DEFAULT_COMMAND');
// CONTENT META
if (!isset($GLOBALS['PM_CONTENT_META_COMMAND'])) $GLOBALS['PM_CONTENT_META_COMMAND'] = constant('pcom_commands::PCOM_CONTENT_META_COMMAND');
if (!isset($GLOBALS['PM_CONTENT_META_TITLE_KEYWORD'])) $GLOBALS['PM_CONTENT_META_TITLE_KEYWORD'] = constant('pcom_commands::PCOM_CONTENT_META_TITLE_KEYWORD');
if (!isset($GLOBALS['PM_CONTENT_META_AUTHOR_KEYWORD'])) $GLOBALS['PM_CONTENT_META_AUTHOR_KEYWORD'] = constant('pcom_commands::PCOM_CONTENT_META_AUTHOR_KEYWORD');
if (!isset($GLOBALS['PM_CONTENT_META_DATE_KEYWORD'])) $GLOBALS['PM_CONTENT_META_DATE_KEYWORD'] = constant('pcom_commands::PCOM_CONTENT_META_DATE_KEYWORD');
if (!isset($GLOBALS['PM_CONTENT_META_CATEGORY_KEYWORD'])) $GLOBALS['PM_CONTENT_META_CATEGORY_KEYWORD'] = constant('pcom_commands::PCOM_CONTENT_META_CATEGORY_KEYWORD');
if (!isset($GLOBALS['PM_CONTENT_META_TAG_KEYWORD'])) $GLOBALS['PM_CONTENT_META_TAG_KEYWORD'] = constant('pcom_commands::PCOM_CONTENT_META_TAG_KEYWORD');
// CONTENT WITH INSERT
if (!isset($GLOBALS['PM_CONTENT_WITH_INSERT_COMMAND'])) $GLOBALS['PM_CONTENT_WITH_INSERT_COMMAND'] = constant('pcom_commands::PCOM_CONTENT_WITH_INSERT_COMMAND');
// POST LIST
if (!isset($GLOBALS['PM_POST_LIST_COMMAND'])) $GLOBALS['PM_POST_LIST_COMMAND'] = constant('pcom_commands::PCOM_POST_LIST_COMMAND');
if (!isset($GLOBALS['PM_POST_LIST_ENTRY_KEYWORD'])) $GLOBALS['PM_POST_LIST_ENTRY_KEYWORD'] = constant('pcom_commands::PCOM_POST_LIST_ENTRY_KEYWORD');
if (!isset($GLOBALS['PM_POST_LIST_TITLE_KEYWORD'])) $GLOBALS['PM_POST_LIST_TITLE_KEYWORD'] = constant('pcom_commands::PCOM_POST_LIST_TITLE_KEYWORD');
// SECTION COMMAND
if (!isset($GLOBALS['PM_SECTION_COMMAND'])) $GLOBALS['PM_SECTION_COMMAND'] = constant('pcom_commands::PCOM_SECTION_COMMAND');
// REMOTE
if (!isset($GLOBALS['PM_REMOTE_SCHEMATIC_AWS_COMMAND'])) $GLOBALS['PM_REMOTE_SCHEMATIC_AWS_COMMAND'] = constant('pcom_commands::PCOM_REMOTE_SCHEMATIC_AWS_COMMAND');
if (!isset($GLOBALS['PM_REMOTE_ADDITION_AWS_COMMAND'])) $GLOBALS['PM_REMOTE_ADDITION_AWS_COMMAND'] = constant('pcom_commands::PCOM_REMOTE_ADDITION_AWS_COMMAND');
if (!isset($GLOBALS['PM_REMOTE_IMAGE_AWS_SUBCOMMAND'])) $GLOBALS['PM_REMOTE_IMAGE_AWS_SUBCOMMAND'] = constant('pcom_commands::PCOM_REMOTE_IMAGE_AWS_SUBCOMMAND');
if (!isset($GLOBALS['PM_REMOTE_SCHEMATIC_AWS_SUBCOMMAND'])) $GLOBALS['PM_REMOTE_SCHEMATIC_AWS_SUBCOMMAND'] = constant('pcom_commands::PCOM_REMOTE_SCHEMATIC_SUBCOMMAND');
if (!isset($GLOBALS['PM_REMOTE_TIMEOUT_MIN'])) $GLOBALS['PM_REMOTE_TIMEOUT_MIN'] = constant('pcom_commands::PCOM_REMOTE_TIMEOUT_MIN');
if (!isset($GLOBALS['PM_REMOTE_TIMEOUT_MAX'])) $GLOBALS['PM_REMOTE_TIMEOUT_MAX'] = constant('pcom_commands::PCOM_REMOTE_TIMEOUT_MAX');
if (!isset($GLOBALS['PM_REMOTE_DEFAULT_EXPIRY'])) $GLOBALS['PM_REMOTE_DEFAULT_EXPIRY'] = constant('pcom_commands::PCOM_REMOTE_DEFAULT_EXPIRY');
// EFFECTS
if (!isset($GLOBALS['PM_INSERT_EFFECT_COMMAND'])) $GLOBALS['PM_INSERT_EFFECT_COMMAND'] = constant('pcom_commands::PCOM_INSERT_EFFECT_COMMAND');
if (!isset($GLOBALS['PM_REVEAL_EFFECT_KEYWORD'])) $GLOBALS['PM_REVEAL_EFFECT_KEYWORD'] = constant('pcom_commands::PCOM_REVEAL_EFFECT_KEYWORD');
if (!isset($GLOBALS['PM_EFFECT_PRIORITY'])) $GLOBALS['PM_EFFECT_PRIORITY'] = constant('pcom_commands::PCOM_EFFECT_PRIORITY');
// FONT
if (!isset($GLOBALS['PM_INSERT_FONT_COMMAND'])) $GLOBALS['PM_INSERT_FONT_COMMAND'] = constant('pcom_commands::PCOM_INSERT_FONT_COMMAND');
if (!isset($GLOBALS['PM_FONT_ADD_PRIORITY'])) $GLOBALS['PM_FONT_ADD_PRIORITY'] = constant('pcom_commands::PCOM_FONT_ADD_PRIORITY');
// STYLESHEET REF
if (!isset($GLOBALS['PM_INSERT_STYLESHEET_REF_COMMAND'])) $GLOBALS['PM_INSERT_STYLESHEET_REF_COMMAND'] = constant('pcom_commands::PCOM_INSERT_STYLESHEET_REF_COMMAND');
if (!isset($GLOBALS['PM_INSERT_STYLESHEET_REF_KEYWORD'])) $GLOBALS['PM_INSERT_STYLESHEET_REF_KEYWORD'] = constant('pcom_commands::PCOM_INSERT_STYLESHEET_REF_KEYWORD');
if (!isset($GLOBALS['PM_STYLESHEET_ADD_PRIORITY'])) $GLOBALS['PM_STYLESHEET_ADD_PRIORITY'] = constant('pcom_commands::PCOM_STYLESHEET_ADD_PRIORITY');
// BACKGROUND STYLE COMMAND
if (!isset($GLOBALS['PM_INSERT_BACKGROUND_IMAGE_COMMAND'])) $GLOBALS['PM_INSERT_BACKGROUND_IMAGE_COMMAND'] = constant('pcom_commands::PCOM_INSERT_BACKGROUND_IMAGE_COMMAND');
if (!isset($GLOBALS['PM_INSERT_BACKGROUND_IMAGE_KEYWORD'])) $GLOBALS['PM_INSERT_BACKGROUND_IMAGE_KEYWORD'] = constant('pcom_commands::PCOM_INSERT_BACKGROUND_IMAGE_KEYWORD');
if (!isset($GLOBALS['PM_BACKGROUND_IMAGE_ADD_PRIORITY'])) $GLOBALS['PM_BACKGROUND_IMAGE_ADD_PRIORITY'] = constant('pcom_commands::PCOM_BACKGROUND_IMAGE_ADD_PRIORITY');
// HEADER CONTENT COMMAND
if (!isset($GLOBALS['PM_HEADER_CONTENT_COMMAND'])) $GLOBALS['PM_HEADER_CONTENT_COMMAND'] = constant('pcom_commands::PCOM_HEADER_CONTENT_COMMAND');
if (!isset($GLOBALS['PM_HEADER_CONTENT_TEXT_SUBCOMMAND'])) $GLOBALS['PM_HEADER_CONTENT_TEXT_SUBCOMMAND'] = constant('pcom_commands::PCOM_HEADER_CONTENT_TEXT_SUBCOMMAND');
if (!isset($GLOBALS['PM_HEADER_CONTENT_SCRIPT_SUBCOMMAND'])) $GLOBALS['PM_HEADER_CONTENT_SCRIPT_SUBCOMMAND'] = constant('pcom_commands::PCOM_HEADER_CONTENT_SCRIPT_SUBCOMMAND');
if (!isset($GLOBALS['PM_HEADER_CONTENT_ADD_PRIORITY'])) $GLOBALS['PM_HEADER_CONTENT_ADD_PRIORITY'] = constant('pcom_commands::PCOM_HEADER_CONTENT_ADD_PRIORITY');
// FOOTER CONTENT COMMAND
if (!isset($GLOBALS['PM_FOOTER_CONTENT_COMMAND'])) $GLOBALS['PM_FOOTER_CONTENT_COMMAND'] = constant('pcom_commands::PCOM_FOOTER_CONTENT_COMMAND');
if (!isset($GLOBALS['PM_FOOTER_CONTENT_TEXT_SUBCOMMAND'])) $GLOBALS['PM_FOOTER_CONTENT_TEXT_SUBCOMMAND'] = constant('pcom_commands::PCOM_FOOTER_CONTENT_TEXT_SUBCOMMAND');
if (!isset($GLOBALS['PM_FOOTER_CONTENT_SCRIPT_SUBCOMMAND'])) $GLOBALS['PM_FOOTER_CONTENT_SCRIPT_SUBCOMMAND'] = constant('pcom_commands::PCOM_FOOTER_CONTENT_SCRIPT_SUBCOMMAND');
if (!isset($GLOBALS['PM_FOOTER_CONTENT_ADD_PRIORITY'])) $GLOBALS['PM_FOOTER_CONTENT_ADD_PRIORITY'] = constant('pcom_commands::PCOM_FOOTER_CONTENT_ADD_PRIORITY');
// COMMENTS
if (!isset($GLOBALS['PM_INSERT_COMMENTS_COMMAND'])) $GLOBALS['PM_INSERT_COMMENTS_COMMAND'] = constant('pcom_commands::PCOM_INSERT_COMMENTS_COMMAND');
// PAGINATION
if (!isset($GLOBALS['PM_INSERT_PAGINATION_COMMAND'])) $GLOBALS['PM_INSERT_PAGINATION_COMMAND'] = constant('pcom_commands::PCOM_INSERT_PAGINATION_COMMAND');
// SEARCH BAR
if (!isset($GLOBALS['PM_INSERT_SEARCHBAR_COMMAND'])) $GLOBALS['PM_INSERT_SEARCHBAR_COMMAND'] = constant('pcom_commands::PCOM_INSERT_SEARCHBAR_COMMAND');
// COPYRIGHT
if (!isset($GLOBALS['PM_INSERT_COPYRIGHT_STATEMENT_COMMAND'])) $GLOBALS['PM_INSERT_COPYRIGHT_STATEMENT_COMMAND'] = constant('pcom_commands::PCOM_INSERT_COPYRIGHT_STATEMENT_COMMAND');
// STYLING
if (!isset($GLOBALS['PM_INSERT_STYLING_COMMAND'])) $GLOBALS['PM_INSERT_STYLING_COMMAND'] = constant('pcom_commands::PCOM_INSERT_STYLING_COMMAND');
// WIDGETS
if (!isset($GLOBALS['PM_INSERT_WIDGET_COMMAND'])) $GLOBALS['PM_INSERT_WIDGET_COMMAND'] = constant('pcom_commands::PCOM_INSERT_WIDGET_COMMAND');
if (!isset($GLOBALS['PM_NO_OF_WIDGETS'])) $GLOBALS['PM_NO_OF_WIDGETS'] = constant('pcom_commands::PCOM_NO_OF_WIDGETS');
//
//
if (!isset($GLOBALS['PM_FOOTER_ATTRIBUTION_COMMAND'])) $GLOBALS['PM_FOOTER_ATTRIBUTION_COMMAND'] = constant('pcom_commands::PCOM_FOOTER_ATTRIBUTION_COMMAND');
//
// ============
// command functions list - global is predefined as empty in pcom_defaults
$GLOBALS['command_functions_list'][$GLOBALS['PM_NAV_COMMAND']] = 'pcom_process_nav_command';
$GLOBALS['command_functions_list'][$GLOBALS['PM_MENU_COMMAND']] = 'pcom_process_menu_command';
$GLOBALS['command_functions_list'][$GLOBALS['PM_QUOTE_COMMAND']] = 'pcom_insert_quote_box';
$GLOBALS['command_functions_list'][$GLOBALS['PM_CONTENT_COMMAND']] = 'pcom_add_customised_content';
$GLOBALS['command_functions_list'][$GLOBALS['PM_CONTENT_DEFAULT_COMMAND']] = 'pcom_add_content';
$GLOBALS['command_functions_list'][$GLOBALS['PM_CONTENT_WITH_INSERT_COMMAND']] = 'pcom_process_content_with_inserts';
$GLOBALS['command_functions_list'][$GLOBALS['PM_CONTENT_META_COMMAND']] = 'pcom_add_content_meta';
$GLOBALS['command_functions_list'][$GLOBALS['PM_POST_LIST_COMMAND']] = 'pcom_add_post_list';
$GLOBALS['command_functions_list'][$GLOBALS['PM_SECTION_COMMAND']] = 'pcom_process_section';
$GLOBALS['command_functions_list'][$GLOBALS['PM_INSERT_WIDGET_COMMAND']] = 'pcom_insert_widgets';
$GLOBALS['command_functions_list'][$GLOBALS['PM_REMOTE_SCHEMATIC_AWS_COMMAND']] = 'pcom_process_remote_schematic_command';
$GLOBALS['command_functions_list'][$GLOBALS['PM_INSERT_COMMENTS_COMMAND']] = 'polimorf_insert_comments';
$GLOBALS['command_functions_list'][$GLOBALS['PM_INSERT_PAGINATION_COMMAND']] = 'polimorf_insert_pagination';
$GLOBALS['command_functions_list'][$GLOBALS['PM_INSERT_SEARCHBAR_COMMAND']] = 'pcom_insert_searchbar';
$GLOBALS['command_functions_list'][$GLOBALS['PM_INSERT_COPYRIGHT_STATEMENT_COMMAND']] = 'polimorf_add_copyright';
$GLOBALS['command_functions_list'][$GLOBALS['PM_INSERT_STYLING_COMMAND']] = 'pcom_insert_styling';
$GLOBALS['command_functions_list'][$GLOBALS['PM_FOOTER_ATTRIBUTION_COMMAND']] = 'polimorf_add_footer_attribution_strip';

// wp head addition functions list - global is predefined as empty in pcom_defaults
$GLOBALS['addition_functions_list'][$GLOBALS['PM_INSERT_EFFECT_COMMAND']] = 'pcom_add_javascript_effect';
$GLOBALS['addition_functions_list'][$GLOBALS['PM_INSERT_FONT_COMMAND']] = 'pcom_insert_font_reference';
$GLOBALS['addition_functions_list'][$GLOBALS['PM_INSERT_STYLESHEET_REF_COMMAND']] = 'pcom_insert_stylesheet_reference';
$GLOBALS['addition_functions_list'][$GLOBALS['PM_INSERT_BACKGROUND_IMAGE_COMMAND']] = 'pcom_insert_background_image_reference';
$GLOBALS['addition_functions_list'][$GLOBALS['PM_HEADER_CONTENT_COMMAND']] = 'pcom_add_header_content_to_wp_head';
$GLOBALS['addition_functions_list'][$GLOBALS['PM_FOOTER_CONTENT_COMMAND']] = 'pcom_add_footer_content_to_wp_footer';
$GLOBALS['addition_functions_list'][$GLOBALS['PM_REMOTE_ADDITION_AWS_COMMAND']] = 'pcom_process_remote_addition_command';
//
$GLOBALS['command_args'] = array(
  'syntax' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'custom_class' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'placement' => constant('pcom_commands::PCOM_NO_ENTRY')
);
// replacements for text
if (!isset($GLOBALS['PM_TEXT_HTML_CONVERSIONS'])) $GLOBALS['PM_TEXT_HTML_CONVERSIONS'] = constant('pcom_commands::PCOM_POST_HTML_CONVERSIONS');
// custom attributes
if (!isset($GLOBALS['PM_CUSTOM_LINK_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_LINK_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_LINK_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_HTML_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_HTML_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_HTML_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_IMAGE_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_IMAGE_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_IMAGE_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_REMOTE_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES_REMOTE_LINK'])) $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES_REMOTE_LINK'] = constant('pcom_commands::PCOM_CUSTOM_REMOTE_ATTRIBUTES_REMOTE_LINK');
//
if (!isset($GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES_REMOTE_IMAGE'])) $GLOBALS['PM_CUSTOM_REMOTE_ATTRIBUTES_REMOTE_IMAGE'] = constant('pcom_commands::PCOM_CUSTOM_REMOTE_ATTRIBUTES_REMOTE_IMAGE');
//
if (!isset($GLOBALS['PM_CUSTOM_MENU_COMMAND_MLK_KEYWORD_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_MENU_COMMAND_MLK_KEYWORD_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_MENU_COMMAND_MLK_KEYWORD_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_WPMENU_COMMAND_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_WPMENU_COMMAND_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_WPMENU_COMMAND_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_LOGO_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_LOGO_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_LOGO_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_SITE_REPLACEMENTS'])) $GLOBALS['PM_CUSTOM_SITE_REPLACEMENTS'] = constant('pcom_commands::PCOM_CUSTOM_SITE_REPLACEMENTS');
//
if (!isset($GLOBALS['PM_CUSTOM_REVEAL_EFFECTS_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_REVEAL_EFFECTS_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_REVEAL_EFFECTS_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_INSERT_STYLESHEET_REF_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_INSERT_STYLESHEET_REF_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_INSERT_STYLESHEET_REF_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_INSERT_BACKGROUND_IMAGE_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_INSERT_BACKGROUND_IMAGE_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_INSERT_BACKGROUND_IMAGE_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_HEADER_CONTENT_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_HEADER_CONTENT_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_HEADER_CONTENT_ATTRIBUTES');
//
if (!isset($GLOBALS['PM_CUSTOM_FOOTER_CONTENT_ATTRIBUTES'])) $GLOBALS['PM_CUSTOM_FOOTER_CONTENT_ATTRIBUTES'] = constant('pcom_commands::PCOM_CUSTOM_FOOTER_CONTENT_ATTRIBUTES');
//
//
// does not include data-*
$GLOBALS['PM_HTML_GLOBAL_ATTRIBUTES'] = array(
'accesskey' => constant('pcom_commands::PCOM_NO_ENTRY'),
'class' => constant('pcom_commands::PCOM_NO_ENTRY'),
'contenteditable' => constant('pcom_commands::PCOM_NO_ENTRY'),
'contextmenu' => constant('pcom_commands::PCOM_NO_ENTRY'),
'dir' => constant('pcom_commands::PCOM_NO_ENTRY'),
'draggable' => constant('pcom_commands::PCOM_NO_ENTRY'),
'dropzone' => constant('pcom_commands::PCOM_NO_ENTRY'),
'hidden' => constant('pcom_commands::PCOM_NO_ENTRY'),
'id' => constant('pcom_commands::PCOM_NO_ENTRY'),
'lang' => constant('pcom_commands::PCOM_NO_ENTRY'),
'spellcheck' => constant('pcom_commands::PCOM_NO_ENTRY'),
'style' => constant('pcom_commands::PCOM_NO_ENTRY'),
'tabindex' => constant('pcom_commands::PCOM_NO_ENTRY'),
'title' => constant('pcom_commands::PCOM_NO_ENTRY'),
'translate' => constant('pcom_commands::PCOM_NO_ENTRY')
);
// text is for <a>text</a>. It will only be applied
// when link={}: is used
$GLOBALS['PM_LINK_ATTRIBUTES'] = array(
$GLOBALS['PM_TEXT_ATTRIBUTE'] => constant('pcom_commands::PCOM_NO_ENTRY'),
'charset' => constant('pcom_commands::PCOM_NO_ENTRY'),
'coords' => constant('pcom_commands::PCOM_NO_ENTRY'),
'download' => constant('pcom_commands::PCOM_NO_ENTRY'),
'href' => constant('pcom_commands::PCOM_NO_ENTRY'),
'hreflang' => constant('pcom_commands::PCOM_NO_ENTRY'),
'media' => constant('pcom_commands::PCOM_NO_ENTRY'),
'name' => constant('pcom_commands::PCOM_NO_ENTRY'),
'rel' => constant('pcom_commands::PCOM_NO_ENTRY'),
'rev' => constant('pcom_commands::PCOM_NO_ENTRY'),
'shape' => constant('pcom_commands::PCOM_NO_ENTRY'),
'target' => constant('pcom_commands::PCOM_NO_ENTRY'),
'type' => constant('pcom_commands::PCOM_NO_ENTRY')
);
//
// when img_link={}: or img={}: are used
$GLOBALS['PM_IMG_ATTRIBUTES'] = array(
'alt' => constant('pcom_commands::PCOM_NO_ENTRY'),
'crossorigin' => constant('pcom_commands::PCOM_NO_ENTRY'),
'fa' => constant('pcom_commands::PCOM_NO_ENTRY'),
'height' => constant('pcom_commands::PCOM_NO_ENTRY'),
'ismap' => constant('pcom_commands::PCOM_NO_ENTRY'),
'longdesc' => constant('pcom_commands::PCOM_NO_ENTRY'),
'sizes' => constant('pcom_commands::PCOM_NO_ENTRY'),
'src' => constant('pcom_commands::PCOM_NO_ENTRY'),
'srcset' => constant('pcom_commands::PCOM_NO_ENTRY'),
'usemap' => constant('pcom_commands::PCOM_NO_ENTRY'),
'width' => constant('pcom_commands::PCOM_NO_ENTRY')
);
// empty array for REMOTE command
$GLOBALS['PM_REMOTE_ATTRIBUTES'] = array(
  'filename' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'region' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'timeout' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'bucketname' => constant('pcom_commands::PCOM_NO_ENTRY')
);
// empty array for remote image and link
$GLOBALS['PM_REMOTE_ATTRIBUTES_REMOTE_IMAGE'] = array(
  'image_filename' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'image_region' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'image_timeout' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'image_bucketname' => constant('pcom_commands::PCOM_NO_ENTRY')
);
//
$GLOBALS['PM_REMOTE_ATTRIBUTES_REMOTE_LINK'] = array(
  'link_filename' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'link_region' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'link_timeout' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'link_bucketname' => constant('pcom_commands::PCOM_NO_ENTRY')
);
//
$GLOBALS['PM_CONTENT_META_DISPLAY_DEFAULTS'] = array(
  constant('pcom_commands::PCOM_CONTENT_META_TITLE_KEYWORD') => true,
  constant('pcom_commands::PCOM_CONTENT_META_AUTHOR_KEYWORD') => true,
  constant('pcom_commands::PCOM_CONTENT_META_DATE_KEYWORD') => true,
  constant('pcom_commands::PCOM_CONTENT_META_CATEGORY_KEYWORD') => true,
  constant('pcom_commands::PCOM_CONTENT_META_TAG_KEYWORD') => true
);
$GLOBALS['PM_CONTENT_META_DISPLAY_FALSE'] = array(
  constant('pcom_commands::PCOM_CONTENT_META_TITLE_KEYWORD') => false,
  constant('pcom_commands::PCOM_CONTENT_META_AUTHOR_KEYWORD') => false,
  constant('pcom_commands::PCOM_CONTENT_META_DATE_KEYWORD') => false,
  constant('pcom_commands::PCOM_CONTENT_META_CATEGORY_KEYWORD') => false,
  constant('pcom_commands::PCOM_CONTENT_META_TAG_KEYWORD') => false
);
$GLOBALS['PM_MENU_COMMAND_MLK_KEYWORD_ATTRIBUTES'] = array(
  'href' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'name' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'src' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'class' => constant('pcom_commands::PCOM_NO_ENTRY'),
  'fa' => constant('pcom_commands::PCOM_NO_ENTRY')
);
$GLOBALS['PM_WPMENU_COMMAND_ATTRIBUTES'] = array(
  'name' => esc_attr($GLOBALS['PM_ADDED_MENU']),
  'class' => constant('pcom_commands::PCOM_NO_ENTRY')
);
$GLOBALS['PM_LOGO_ATTRIBUTES'] = array(
  'src' => constant('pcom_commands::PCOM_NO_ENTRY')
);
$GLOBALS['PM_REVEAL_EFFECT_ATTRIBUTES'] = array(
'class' => constant('pcom_commands::PCOM_NO_ENTRY'),
'settings' => constant('pcom_commands::PCOM_NO_ENTRY')
);
//
$GLOBALS['PM_INSERT_STYLESHEET_REF_ATTRIBUTES'] = array(
'url' => constant('pcom_commands::PCOM_NO_ENTRY')
);
//
$GLOBALS['PM_INSERT_BACKGROUND_IMAGE_ATTRIBUTES'] = array(
'url' => constant('pcom_commands::PCOM_NO_ENTRY'),
'name' => constant('pcom_commands::PCOM_NO_ENTRY')
);
//
$GLOBALS['PM_HEADER_CONTENT_ATTRIBUTES'] = array(
'src' => ''
);
//
$GLOBALS['PM_FOOTER_CONTENT_ATTRIBUTES'] = array(
'src' => ''
);
//
$GLOBALS['pm_footer_script_data'] = array();
$GLOBALS['pm_footer_script_count'] = 0;
//
$GLOBALS['pm_footer_content_data'] = '';
$GLOBALS['pm_header_content_data'] = '';
//
$GLOBALS['pm_header_font_references'] = array();
$GLOBALS['pm_header_font_reference_count'] = 0;
//
$GLOBALS['pm_header_stylesheet_references'] = array();
$GLOBALS['pm_header_stylesheet_reference_count'] = 0;
//
$GLOBALS['pm_background_image_references'] = array();
$GLOBALS['pm_background_image_names'] = array();
$GLOBALS['pm_background_image_reference_count'] = 0;
//
$GLOBALS['query_active'] = 0;
//
// schematic tag removal array for cleaning formats in options
// i.e. don't include tags in individual options
$GLOBALS['schematic_tag_cleaning'] = array(
  $GLOBALS['PM_HEADER_SCHEMATIC_TAG'] => '',
  $GLOBALS['PM_FOOTER_SCHEMATIC_TAG'] => '',
  $GLOBALS['PM_BEFORE_MAIN_SCHEMATIC_TAG'] => '',
  $GLOBALS['PM_AFTER_MAIN_SCHEMATIC_TAG'] => '',
  $GLOBALS['PM_MAIN_SCHEMATIC_TAG'] => '',
  $GLOBALS['PM_REMOTE_SCHEMATIC_TAG'] => '',
  $GLOBALS['PM_SIDEBAR_SCHEMATIC_TAG'] => '',
);
//
