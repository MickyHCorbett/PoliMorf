<?php
/*
* Polimorf Settings
*/
// add the admin options page
add_action('admin_menu','polimorf_admin_add_page');
function polimorf_admin_add_page () {
	add_theme_page('Polimorf Settings Page', $GLOBALS['PM_POLIMORF_PAGE_SETTINGS_TITLE'], 'manage_options', 'polimorf_settings', 'polimorf_options_page');
}
// display the admin options page
function polimorf_options_page () {
	?>
	<div class="wrap">
       <div class="icon32" id="icon-options-general"></div>
	    <h2><?php echo esc_attr($GLOBALS['PM_POLIMORF_PAGE_SETTINGS_TITLE']); ?></h2>
	<?php
    	if( isset( $_GET[ 'tab' ] ) ) {
          $active_tab = $_GET[ 'tab' ];
      } else {
					$active_tab = 'polimorf_settings';
		}
		// end if
  ?>
  <h2 class="nav-tab-wrapper">

			<a href="?page=polimorf_settings&tab=<?php echo esc_attr($GLOBALS['PM_POLIMORF_PAGE_SETTINGS_INFO_OPTIONS_SLUG']); ?>" class="nav-tab
			<?php echo $active_tab == $GLOBALS['PM_POLIMORF_PAGE_SETTINGS_INFO_OPTIONS_SLUG'] ? 'nav-tab-active' : ''; ?>">
			<?php echo esc_attr($GLOBALS['PM_POLIMORF_PAGE_SETTINGS_INFO_OPTIONS']); ?></a>

			<a href="?page=polimorf_settings&tab=<?php echo esc_attr($GLOBALS['PM_POLIMORF_PAGE_SETTINGS_STYLING_OPTIONS_SLUG']); ?>" class="nav-tab
			<?php echo $active_tab == $GLOBALS['PM_POLIMORF_PAGE_SETTINGS_STYLING_OPTIONS_SLUG'] ? 'nav-tab-active' : ''; ?>">
			<?php echo esc_attr($GLOBALS['PM_POLIMORF_PAGE_SETTINGS_STYLING_OPTIONS']); ?></a>

			<a href="?page=polimorf_settings&tab=<?php echo esc_attr($GLOBALS['PM_POLIMORF_PAGE_SETTINGS_CLOUD_OPTIONS_SLUG']); ?>" class="nav-tab
			<?php echo $active_tab == $GLOBALS['PM_POLIMORF_PAGE_SETTINGS_CLOUD_OPTIONS_SLUG'] ? 'nav-tab-active' : ''; ?>">
			<?php echo esc_attr($GLOBALS['PM_POLIMORF_PAGE_SETTINGS_CLOUD_OPTIONS']); ?></a>

		</h2>
	<form action="options.php" method="post">
	<input name="Submit" type="submit" class="button-primary top-button-primary" value="<?php esc_attr_e('Save Changes' , 'polimorf'); ?>" />
	<?php
		switch ($active_tab) {
		case $GLOBALS['PM_POLIMORF_PAGE_SETTINGS_STYLING_OPTIONS_SLUG'] :
					settings_fields( 'polimorf_styling_options' );
					do_settings_sections( 'polimorf_styling_options' );
		break;
		case $GLOBALS['PM_POLIMORF_PAGE_SETTINGS_INFO_OPTIONS_SLUG'] :
					settings_fields( 'polimorf_info_options' );
					do_settings_sections( 'polimorf_info_options' );
		break;
		case $GLOBALS['PM_POLIMORF_PAGE_SETTINGS_CLOUD_OPTIONS_SLUG'] :
					settings_fields( 'polimorf_cloud_options' );
					do_settings_sections( 'polimorf_cloud_options' );
		break;
		default :
        settings_fields( 'polimorf_styling_options' );
				do_settings_sections( 'polimorf_styling_options' );
    break;
  	}
	?>
	<input name="Submit" type="submit" class="button-primary bottom-button-primary" value="<?php esc_attr_e('Save Changes' , 'polimorf'); ?>" />
	</form>
	</div>
	<?php
}
//
// -------------
// STYLING SECTION
// -------------
//
// add the styling settings
add_action('admin_init', 'polimorf_admin_styling_init');
function polimorf_admin_styling_init () {
	register_setting('polimorf_styling_options', 'polimorf_styling_options', 'polimorf_styling_options_validate' );
	// Header settings
	add_settings_section('polimorf_styling_settings', '', 'polimorf_styling_section_text', 'polimorf_styling_options');
	//
	add_settings_field('polimorf_header_format', $GLOBALS['PM_STYLING_HEADER_FORMAT'], 'polimorf_header_format', 'polimorf_styling_options', 'polimorf_styling_settings');
	add_settings_field('polimorf_footer_format', $GLOBALS['PM_STYLING_FOOTER_FORMAT'], 'polimorf_footer_format', 'polimorf_styling_options', 'polimorf_styling_settings');
	add_settings_field('polimorf_before_main_format', $GLOBALS['PM_STYLING_BEFORE_MAIN_FORMAT'], 'polimorf_before_main_format', 'polimorf_styling_options', 'polimorf_styling_settings');
	add_settings_field('polimorf_after_main_format', $GLOBALS['PM_STYLING_AFTER_MAIN_FORMAT'], 'polimorf_after_main_format', 'polimorf_styling_options', 'polimorf_styling_settings');
	add_settings_field('polimorf_post_format', $GLOBALS['PM_STYLING_POST_FORMAT'], 'polimorf_post_format', 'polimorf_styling_options', 'polimorf_styling_settings');
	add_settings_field('polimorf_page_format', $GLOBALS['PM_STYLING_PAGE_FORMAT'], 'polimorf_page_format', 'polimorf_styling_options', 'polimorf_styling_settings');
	add_settings_field('polimorf_sidebar_format', $GLOBALS['PM_STYLING_SIDEBAR_FORMAT'], 'polimorf_sidebar_format', 'polimorf_styling_options', 'polimorf_styling_settings');
}
// settings text
function polimorf_styling_section_text ( ) {
	?>
	<!-- styling for admin page -->
	<style>
	<!--
	.settings-description {
		width: 80%;
	}
	.form-table {
		margin-top: 2em;
		margin-bottom: 2em;
	}
	.form-table p {
		width: 70%;
	}
	-->
	</style>
	<?php
}
function polimorf_header_format() {
	$options = get_option('polimorf_styling_options');
	// use default schematic if empty
	if ( trim($options['header_format']) == "" )
	{ $options['header_format'] = $GLOBALS['PM_HEADER_SCHEMATIC'];}
	echo "<textarea id='styling_textbox' class='textarea' name='polimorf_styling_options[header_format]' type='text' rows='10' cols='80'>" . $options['header_format'] . "</textarea>";
	?>
	<p><span class="description"><?php echo esc_attr($GLOBALS['PM_STYLING_HEADER_FORMAT_DESCRIPTION']); ?></span></p>
	<?php
}
function polimorf_footer_format() {
	$options = get_option('polimorf_styling_options');
	// use default schematic if empty
	if ( trim($options['footer_format']) == "" )
	{ $options['footer_format'] = $GLOBALS['PM_FOOTER_SCHEMATIC'];}
	echo "<textarea id='styling_textbox' class='textarea' name='polimorf_styling_options[footer_format]' type='text' rows='10' cols='80'>" . $options['footer_format'] . "</textarea>";
	?>
	<p><span class="description"><?php echo esc_attr($GLOBALS['PM_STYLING_FOOTER_FORMAT_DESCRIPTION']); ?></span></p>
	<?php
}
function polimorf_before_main_format() {
	$options = get_option('polimorf_styling_options');
	echo "<textarea id='styling_textbox' class='textarea' name='polimorf_styling_options[before_main_format]' type='text' rows='10' cols='80'>" . $options['before_main_format'] . "</textarea>";
	?>
	<p><span class="description"><?php echo esc_attr($GLOBALS['PM_STYLING_BEFORE_MAIN_FORMAT_DESCRIPTION']); ?></span></p>
	<?php
}
function polimorf_after_main_format() {
	$options = get_option('polimorf_styling_options');
	echo "<textarea id='styling_textbox' class='textarea' name='polimorf_styling_options[after_main_format]' type='text' rows='10' cols='80'>" . $options['after_main_format'] . "</textarea>";
	?>
	<p><span class="description"><?php echo esc_attr($GLOBALS['PM_STYLING_AFTER_MAIN_FORMAT_DESCRIPTION']); ?></span></p>
	<?php
}
function polimorf_post_format() {
	$options = get_option('polimorf_styling_options');
	// use default schematic if empty
	if ( trim($options['post_format']) == "" )
	{ $options['post_format'] = $GLOBALS['PM_POST_SCHEMATIC'];}
	echo "<textarea id='styling_textbox' class='textarea' name='polimorf_styling_options[post_format]' type='text' rows='10' cols='80'>" . $options['post_format'] . "</textarea>";
	?>
	<p><span class="description"><?php echo esc_attr($GLOBALS['PM_STYLING_POST_FORMAT_DESCRIPTION']); ?></span></p>
	<?php
}
function polimorf_page_format() {
	$options = get_option('polimorf_styling_options');
	// use default schematic if empty
	if ( trim($options['page_format']) == "" )
	{ $options['page_format'] = $GLOBALS['PM_PAGE_SCHEMATIC'];}
	echo "<textarea id='styling_textbox' class='textarea' name='polimorf_styling_options[page_format]' type='text' rows='10' cols='80'>" . $options['page_format'] . "</textarea>";
	?>
	<p><span class="description"><?php echo esc_attr($GLOBALS['PM_STYLING_PAGE_FORMAT_DESCRIPTION']); ?></span></p>
	<?php
}
function polimorf_sidebar_format() {
	$options = get_option('polimorf_styling_options');
	echo "<textarea id='styling_textbox' class='textarea' name='polimorf_styling_options[sidebar_format]' type='text' rows='10' cols='80'>" . $options['sidebar_format'] . "</textarea>";
	?>
	<p><span class="description"><?php echo esc_attr($GLOBALS['PM_STYLING_SIDEBAR_FORMAT_DESCRIPTION']); ?></span></p>
	<?php
}
// validate our styling options
function polimorf_styling_options_validate($input) {
	// check that all parameters are the correct format
	$options = get_option('polimorf_styling_options');
	// clean inputs of schematic tags
	$tag_removal = $GLOBALS['schematic_tag_cleaning'];
	$input['header_format'] = str_replace(array_keys($tag_removal),$tag_removal,$input['header_format']);
	$input['footer_format'] = str_replace(array_keys($tag_removal),$tag_removal,$input['footer_format']);
	$input['before_main_format'] = str_replace(array_keys($tag_removal),$tag_removal,$input['before_main_format']);
	$input['after_main_format'] = str_replace(array_keys($tag_removal),$tag_removal,$input['after_main_format']);
	$input['post_format'] = str_replace(array_keys($tag_removal),$tag_removal,$input['post_format']);
	$input['page_format'] = str_replace(array_keys($tag_removal),$tag_removal,$input['page_format']);
	$input['sidebar_format'] = str_replace(array_keys($tag_removal),$tag_removal,$input['sidebar_format']);
	//
	$allowed_text = array(); // empty array - just text
	// formats allow straight through
	$options['header_format'] = wp_kses($input['header_format'],$allowed_text);
	$options['footer_format'] = wp_kses($input['footer_format'],$allowed_text);
	$options['before_main_format'] = wp_kses($input['before_main_format'],$allowed_text);
	$options['after_main_format'] = wp_kses($input['after_main_format'],$allowed_text);
	$options['post_format'] = wp_kses($input['post_format'],$allowed_text);
	$options['page_format'] = wp_kses($input['page_format'],$allowed_text);
	$options['sidebar_format'] = wp_kses($input['sidebar_format'],$allowed_text);
	//
	return $options;
}
//
// -------------------
// INFO Settings
// add the information tab settings
// -------------------
//
//
add_action('admin_init', 'polimorf_admin_info_init');
function polimorf_admin_info_init () {
	register_setting('polimorf_info_options', 'polimorf_info_options', 'polimorf_info_options_validate' );
	// Info settings - just one
	add_settings_section('polimorf_info_settings', $GLOBALS['PM_HOW_TO_USE'], 'polimorf_info_section_text', 'polimorf_info_options');
}
function polimorf_info_section_text ( ) {
	?>
	<!-- styling for admin page -->
	<style>
	<!--
	.wp-core-ui .button-primary {
		display: none;
	}
	.settings-description {
		width: 80%;
	}
	.form-table {
		margin-top: 2em;
		margin-bottom: 2em;
	}
	.form-table p {
		width: 70%;
	}
	-->
	</style>
	<p class="settings-description">
	<?php echo esc_attr($GLOBALS['PM_INFO_PARAGRAPH_1']); ?>
	</p>
	<p class="settings-description"><?php echo esc_attr($GLOBALS['PM_INFO_PARAGRAPH_2']); ?>&nbsp;-&nbsp;
	<a href="http://polimorfic.com/polimorf-theme" target="_new">
	<?php echo esc_attr($GLOBALS['PM_THEME_NAME']); ?>
	</a>.
	</p>
	<p class="settings-description"><?php echo esc_attr($GLOBALS['PM_INFO_PARAGRAPH_3']); ?></p>
	<?php
}
function polimorf_info_options_validate($input) {
	$options = get_option('polimorf_info_options');
	// nothing to validate
	return $options;
}
// -------------------
// CLOUD Settings
// -------------------
//
//
add_action('admin_init', 'polimorf_admin_cloud_init');
function polimorf_admin_cloud_init () {
	register_setting('polimorf_cloud_options', 'polimorf_cloud_options', 'polimorf_cloud_options_validate' );
	//
	add_settings_section('polimorf_cloud_settings', '', 'polimorf_cloud_section_text', 'polimorf_cloud_options');
	add_settings_field('polimorf_cloud_public_key', $GLOBALS['PM_CLOUD_PUBLIC_KEY'], 'polimorf_cloud_public_key', 'polimorf_cloud_options', 'polimorf_cloud_settings');
	add_settings_field('polimorf_cloud_private_key', $GLOBALS['PM_CLOUD_PRIVATE_KEY'], 'polimorf_cloud_private_key', 'polimorf_cloud_options', 'polimorf_cloud_settings');
}
function polimorf_cloud_section_text ( ) {
	?>
	<!-- styling for admin page -->
	<style>
	<!--
	.form-table {
		margin-top: 2em;
		margin-bottom: 2em;
	}
	input.button-primary.top-button-primary {
		display: none;
	}
	-->
	</style>
	<p class="settings-description">
	<?php echo esc_attr($GLOBALS['PM_CLOUD_DESCRIPTION']); ?>
	</p>
	<?php
}
// add settings
function polimorf_cloud_public_key() {
	$options = get_option('polimorf_cloud_options');
	echo "<input id='cloud_public' name='polimorf_cloud_options[cloud_public_key]' type='text' value='{$options['cloud_public_key']}' />";
	?>
	<p><span class="description"><?php echo esc_attr($GLOBALS['PM_CLOUD_PUBLIC_KEY_DESCRIPTION']); ?></span></p>
	<?php
}
function polimorf_cloud_private_key() {
	$options = get_option('polimorf_cloud_options');
	// create placeholder
	if ( !empty($options['cloud_private_key']) ) {
		$echo_sub = pcom_create_placeholder($options['cloud_private_key']);
	} else {
		$echo_sub = constant('pmschematics::PM_CLOUD_PRIVATE_KEY_SUB');
	}
	//
	echo "<input id='cloud_private' name='polimorf_cloud_options[cloud_private_key]' type='password' placeholder='{$echo_sub}' />";
	?>
	<p><span class="description"><?php echo esc_attr($GLOBALS['PM_CLOUD_PRIVATE_KEY_DESCRIPTION']);?></span></p>
	<?php
}
//
// validate
function polimorf_cloud_options_validate($input) {
	//
	$options = get_option('polimorf_cloud_options');
	// cloud PUBLIC KEY
	// --------
	$options['cloud_public_key'] = wp_kses($input['cloud_public_key'],$allowed_data);
	// cloud PRIVATE KEY
	// first pass
	if ( !isset($options['cloud_private_key']) ) {
		$options['cloud_private_key'] = pcom_check_cloud_parameter($input['cloud_private_key']);
	}
	// general - only update if input changes
	if ( isset($options['cloud_private_key']) && !empty($input['cloud_private_key']) ) {
		$options['cloud_private_key'] = pcom_check_cloud_parameter($input['cloud_private_key']);
	}
	//
	return $options;
}
//
