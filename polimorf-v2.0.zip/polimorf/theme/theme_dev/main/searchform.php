<?php
// $search_image = $GLOBALS['$blog_template'] . constant('pmschematics::PM_SEARCH_ICON_LINK');
//
$search_bar_html =  '<div class="pm-searchbar clearfix-small">' .
                    '<form method="get" action="' . home_url( '/' ) . '" autocomplete="on">' .
                    '<input id="search" type="text" name="s" />' .
                    '<input id="search-submit" type="submit" name="search-submit" /></form>' .
                    '</div><!-- end of #pm-searchbar -->';
// set global
$GLOBALS['$searchbarhtml'] = $search_bar_html;
//
