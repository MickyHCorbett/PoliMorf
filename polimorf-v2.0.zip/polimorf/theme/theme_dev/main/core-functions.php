<?php
// ****************
// THEME FUNCTIONS
// ****************
//
// ========================
//
// theme support
add_theme_support( 'automatic-feed-links' );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'custom-header' );
add_theme_support( 'custom-background' );
add_theme_support( 'post-thumbnails' );
// page/post support
add_post_type_support( 'page', 'excerpt' );
//
//-----------------
/**
 * Make theme available for translation
 * Translations can be filed in the /languages/ directory
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_theme_load_theme_textdomain() {
	 load_theme_textdomain( 'polimorf', get_template_directory().'/languages' );
 }
 add_action( 'after_setup_theme', 'polimorf_theme_load_theme_textdomain' );
//
// TITLE filter
add_theme_support( 'title-tag' );
//
// Default content width = 1200 px
if ( ! isset( $content_width ) ) {
	$content_width = 1200;
}
//
/**
 * Registers an editor stylesheet for the theme.
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
function wpdocs_theme_add_editor_styles() {
    add_editor_style( 'custom-editor-style.css' );
}
add_action( 'admin_init', 'wpdocs_theme_add_editor_styles' );
//
// Choose schematic defaults
//
get_template_part('theme/theme_dev/main/schematics/polimorf-default-schematics');
//
$template_uri = get_template_directory_uri();
$GLOBALS['$blog_template'] = $template_uri . constant('pmschematics::PM_THEME_ROOT');
$GLOBALS['$blog_url'] = home_url();
$GLOBALS['$theme_url'] = $template_uri;
$GLOBALS['$comments_path'] = constant('pmschematics::PM_THEME_ROOT') . '/comments.php';
// load post meta functions
//
get_template_part('theme/theme_dev/main/functions/polimorf-post-meta-functions');
//
// --------------------
//
/**
 * Register the header menu
 *
 * @param global PM_ADDED_MENU
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_register_wp_menus()
 {
	register_nav_menus( array(
	'wp-header-menu' => esc_attr($GLOBALS['PM_ADDED_MENU']),
	) );
 }
 // add to theme - turn menu options on
 add_action( 'init', 'polimorf_register_wp_menus' );
//
/**
 * Register widgets - default is 5
 *
 * @param global PM_NO_OF_WIDGETS
 * @param global PM_WIDGET_AREA_ROOT
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_theme_widgets_init()
 {
// widgets - number read from constants file
	$no_widgets = (int) $GLOBALS['PM_NO_OF_WIDGETS'];
	// cannot be less than 5
	if ($no_widgets < 5) $no_widgets = 5;
	// ---
	for ($i = 1; $i <= $no_widgets; $i++) {
		$widget_name = esc_attr($GLOBALS['PM_WIDGET_AREA_ROOT']) . ' ' . $i;
		$widget_id = 'pm-widget-area' . $i;
		register_sidebar(array(
		'name'=> $widget_name,
		'id' => $widget_id,
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h4 class="widget-title">',
		'after_title' => '</h4>'
		));
	}
 } // end theme_widgets_init
 add_action( 'widgets_init', 'polimorf_theme_widgets_init' );
//
//
/**
 * Defines path to default post thumbnail image
 *
 * @param global $blog_template
 * @param global class variable pmschematics::PM_DEFAULT_THUMBNAIL_IMAGE_LINK
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_get_default_post_thumb()
 {
	$default_image = $GLOBALS['$blog_template'] . esc_url(constant('pmschematics::PM_DEFAULT_THUMBNAIL_IMAGE_LINK'));
	return $default_image;
 }
//
// ---------------------
//
// excerpt length
//
/**
 * Defines excerpt length from constant
 *
 * @param int $length
 * @param global class variable pmschematics::PM_EXCERPT_LENGTH
 *
 * @return int
 *
 * @since 1.0.0
 */
 function polimorf_custom_excerpt_length( $length )
 {
	return constant('pmschematics::PM_EXCERPT_LENGTH');
 }
 add_filter( 'excerpt_length', 'polimorf_custom_excerpt_length', 999 );
//
//
/**
 * Produces an avatar image with the hCard-compliant photo class
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function commenter_link()
 {
  $commenter = get_comment_author_link();
  if ( ereg( '<a[^>]* class=[^>]+>', $commenter ) ) {
          $commenter = ereg_replace( '(<a[^>]* class=[\'"]?)', '\\1url ' , $commenter );
  } else {
          $commenter = ereg_replace( '(<a )/', '\\1class="url "' , $commenter );
  }
  $avatar_email = get_comment_author_email();
  $avatar = str_replace( "class='avatar", "class='photo avatar", get_avatar( $avatar_email, 80 ) );
  echo $avatar . ' <span class="fn n">' . $commenter . '</span>';
 }
//
// ****************
// ADMIN CSS
// ***************
/**
 * Adds admin-styles link to page
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_admin_custom_fonts()
 {
	if ( is_admin() ){
	?>
	<link id="adminstylesheet" rel="stylesheet" type="text/css" href="<?php echo esc_url($GLOBALS['$blog_template']); ?>/admin-styles.css" media="screen" />
	<?php
	}
 }
 add_action( 'admin_head', 'polimorf_admin_custom_fonts' );
//
//
/**
 * Enable threaded comments
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_enable_threaded_comments()
 {
	if (!is_admin()) {
	//
		if (is_singular() || is_page() && comments_open() && (get_option('thread_comments') == 1)) {
			wp_enqueue_script('comment-reply');
		}
	//
	}
 }
 add_action('get_header', 'polimorf_enable_threaded_comments');
//
// MENU Support
// -------------
add_theme_support( 'menus' );
//
//
//
//
// called when in admin (should load when loading themes)
// -------------------------------
// GLOBAL OPTIONS PAGE
// --------------------------------
//
// DO NOT DELETE!!!!!
//
/**
 * Load jQuery and effects
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
function polimorf_add_frontend_jquery_scripts() {
        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-ui-core');
				wp_enqueue_script('jquery-effects-core');
}
add_action('wp_enqueue_scripts', 'polimorf_add_frontend_jquery_scripts');
//
//
//require only in admin!
if(is_admin()){
    get_template_part('theme/theme_dev/main/settings/theme-settings-tabbed');
}
// CUSTOM FIELDS for Posts, Pages and Admin
if(is_admin()){
    get_template_part('theme/theme_dev/main/settings/custom-meta');
}
//
// customiser call - no admin needed
get_template_part('theme/theme_dev/main/settings/custom-customizer');
//
// ADD SCRIPTS
// ---------
// CUSTOMIZER UPDATES
/**
 * Load customizer javascript
 *
 * @param global $blog_template
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_customizer_live_preview()
 {
		$path = $GLOBALS['$blog_template'] . '/js-libs/theme-customizer.js';
    wp_register_script(
        'pm-theme-customizer',$path,
				array('jquery','jquery-effects-core'),false,true);
		wp_enqueue_script( 'pm-theme-customizer' );
 }
 add_action( 'customize_preview_init', 'polimorf_customizer_live_preview' );
//
// ====
//
//
// RESPONSIVE PORTRAIT LANDSCAPE ZOOM FIX
/**
 * Load iphone landscape/portrait zoom fix
 * Resets zoom when orientation changes in responsive mode
 *
 * @param global $blog_template
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_responsive_portrait_landscape_zoomfix()
 {
		$path = $GLOBALS['$blog_template'] . '/js-libs/width-change-zoom-fix.js';
		wp_register_script(
			'pm-width-change-zoom-fix',$path,
			array('jquery'),false,true);
		wp_enqueue_script( 'pm-width-change-zoom-fix');
 }
 add_action( 'wp_enqueue_scripts', 'polimorf_responsive_portrait_landscape_zoomfix' );
//
// NAV MENU DROP DOWN AND HIDE
/**
 * Adds fixed nav menu responsive drop down
 *
 * @param global $blog_template
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_nav_drop_down()
 {
		$path = $GLOBALS['$blog_template'] . '/js-libs/nav-menu-drop-down.js';
		wp_register_script(
			'pm-nav-menu-drop-down',$path,
			array('jquery-effects-core'),false,true);
		wp_enqueue_script( 'pm-nav-menu-drop-down');
 }
 add_action( 'wp_enqueue_scripts', 'polimorf_nav_drop_down' );
// -------------------------------
//
//
/**
 * Adds stylesheet references to wp_head
 *
 * @param global $theme_url
 * @param global $blog_template
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_site_styling()
 {
	?>
	<meta http-equiv="content-type" content="<?php bloginfo('html_type'); ?>" />
	<link id="mainstylesheet" rel="stylesheet" type="text/css" href="<?php echo esc_url($GLOBALS['$theme_url']); ?>/style.css" media="screen" />
	<link id="mainstylesheetcore" rel="stylesheet" type="text/css" href="<?php echo esc_url($GLOBALS['$blog_template']); ?>/style-core.css" media="screen" />
	<link id="respstylesheet" rel="stylesheet" type="text/css" href="<?php echo esc_url($GLOBALS['$blog_template']); ?>/style-responsive.css" media="screen" />
	<?php
 }
 add_action('wp_head', 'polimorf_site_styling');
//
// -------------------------------
// *******************************
//
// SEARCH REDIRECT
//
/**
 * Creates an alternative url for a search query
 * Removes query parameters to prevent SQLi injection
 *
 * @param none
 *
 * @return none
 *
 * @since 1.0.0
 */
 function polimorf_change_search_url_rewrite()
 {
	global $search_term;
	$search_term = get_query_var( 's' );
	$home_url = "/search/";
	if ( is_search() && ! empty( $_GET['s'] ) ) {
		wp_redirect( home_url( $home_url ) . urlencode( get_query_var( 's' ) ) );
		exit();
	}
 }
 add_action( 'template_redirect', 'polimorf_change_search_url_rewrite', 500 );
//
//
// ==========
// SEARCH FORM
// ==========
//
/**
 * Adds search bar to nav-area
 * set global searchbar first
 *
 * @param global $searchbarhtml
 * @param global class variable pmschematics::PM_NAV_SEARCHBAR_OPEN
 * @param global class variable pmschematics::PM_NAV_SEARCHBAR_CLOSE
 *
 * @return string $html_out - searchbar html
 *
 * @since 1.0.0
 */
 function polimorf_nav_search_bar()
 {
	get_template_part('theme/theme_dev/main/searchform');
//
	$html_out = constant('pmschematics::PM_NAV_SEARCHBAR_OPEN') . $GLOBALS['$searchbarhtml'] .
	constant('pmschematics::PM_NAV_SEARCHBAR_CLOSE');
//
	return $html_out;
 }
//
/**
 * Adds search bar (everywhere else)
 * set global searchbar first
 *
 * @param global $searchbarhtml
 * @param global class variable pmschematics::PM_SEARCHBAR_OPEN
 * @param global class variable pmschematics::PM_SEARCHBAR_CLOSE
 *
 * @return string $html_out - searchbar html
 *
 * @since 1.0.0
 */
 function polimorf_insert_searchbar()
 {
	get_template_part('theme/theme_dev/main/searchform');
//
	$html_out = constant('pmschematics::PM_SEARCHBAR_OPEN') . $GLOBALS['$searchbarhtml'] .
	constant('pmschematics::PM_SEARCHBAR_CLOSE');
//
	return $html_out;
 }
//
// ADD slug to body classes
//
/**
 * Add the post or page name to body class
 * so that it can be referenced easily in additional css
 * Called in header - works on posts and pages (page, single)
 *
 * @param array $classes body classes
 *
 * @return $classes - modified to include slug
 *
 * @since 1.0.0
 */
 function polimorf_add_slug_to_body_classes($classes) {
	 if( is_single() || is_page() ) {
		 global $post;
		 $slug = $post->post_name;
		 $classes[] = $slug;
	 }
	 return $classes;
 }
 // Apply filter
 add_filter('body_class', 'polimorf_add_slug_to_body_classes');
//
//
// end of file
//
