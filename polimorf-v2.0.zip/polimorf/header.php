<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<?php polimorf_header_and_title(); ?>
<body
<?php body_class(); ?>>
