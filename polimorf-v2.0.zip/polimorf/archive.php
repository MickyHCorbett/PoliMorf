<?php
polimorf_archive_template();
